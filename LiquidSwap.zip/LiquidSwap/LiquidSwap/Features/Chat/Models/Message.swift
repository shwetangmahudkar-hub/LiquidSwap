import SwiftUI

struct Message: Identifiable, Codable, Hashable {
    var id: UUID
    var senderId: UUID
    var receiverId: UUID
    var content: String
    var createdAt: Date
    
    // Optional Image URL
    var imageUrl: String?
    
    // Link message to a specific Trade
    var tradeId: UUID?
    
    // ✨ NEW: Link message to a parent message for Replies
    var replyToId: UUID?
    
    enum CodingKeys: String, CodingKey {
        case id
        case senderId = "sender_id"
        case receiverId = "receiver_id"
        case content
        case createdAt = "created_at"
        case imageUrl = "image_url"
        case tradeId = "trade_id"
        case replyToId = "reply_to_id" // ✨ NEW: Map to DB
    }
    
    var isCurrentUser: Bool {
        return senderId == UserManager.shared.currentUser?.id
    }
}
