import SwiftUI
import Combine
import Supabase

class ChatManager: ObservableObject {
    static let shared = ChatManager()
    private let client = SupabaseConfig.client
    
    // Stores messages grouped by Trade ID
    @Published var conversations: [UUID: [Message]] = [:]
    @Published var currentUserId: UUID?
    
    // Connection Status
    @Published var isConnected = false
    
    // Track Online Users via Presence
    @Published var onlineUsers: Set<UUID> = []
    
    // MARK: - ✨ NEW: Unread Message Tracking
    @Published var lastReadTimestamps: [String: TimeInterval] = [:]
    private let readTimestampsKey = "chat_read_timestamps"
    
    // Message Validation State
    @Published var lastMessageError: String?
    @Published var showMessageError = false
    
    private var channel: RealtimeChannelV2?
    private var presenceChannel: RealtimeChannelV2?
    private var isSetup = false
    
    private init() {
        loadReadTimestamps() // ✨ Load stored read receipts on launch
        
        Task {
            for await state in client.auth.authStateChanges {
                if let session = state.session {
                    await MainActor.run { self.currentUserId = session.user.id }
                    await setup(userId: session.user.id)
                } else {
                    await reset()
                }
            }
        }
    }
    
    @MainActor
    func reset() async {
        conversations = [:]
        currentUserId = nil
        isConnected = false
        isSetup = false
        onlineUsers.removeAll()
        
        if let channel = channel {
            await channel.unsubscribe()
            self.channel = nil
        }
        
        if let presenceChannel = presenceChannel {
            await presenceChannel.unsubscribe()
            self.presenceChannel = nil
        }
    }
    
    func setup(userId: UUID) async {
        if isSetup { return }
        isSetup = true
        print("💬 ChatManager: Setting up for \(userId)...")
        
        // 1. Initial Sync (Inbox)
        await fetchInbox(userId: userId)
        
        // 2. Realtime Listener & Presence
        await subscribeToRealtime(userId: userId)
    }
    
    // MARK: - ✨ NEW: Unread Badge Logic
    
    private func loadReadTimestamps() {
        if let saved = UserDefaults.standard.dictionary(forKey: readTimestampsKey) as? [String: TimeInterval] {
            self.lastReadTimestamps = saved
        }
    }
    
    @MainActor
    func markAsRead(tradeId: UUID) {
        // Update the timestamp to exactly right now
        lastReadTimestamps[tradeId.uuidString] = Date().timeIntervalSince1970
        UserDefaults.standard.set(lastReadTimestamps, forKey: readTimestampsKey)
    }
    
    func hasUnreadMessages(tradeId: UUID) -> Bool {
        guard let latestMsg = conversations[tradeId]?.last,
              latestMsg.senderId != currentUserId else {
            // No messages, or the last message was sent by US (so it's read)
            return false
        }
        
        let readTime = lastReadTimestamps[tradeId.uuidString] ?? 0
        return latestMsg.createdAt.timeIntervalSince1970 > readTime
    }
    
    // MARK: - Message Send Result
    
    enum SendResult {
        case success
        case rateLimited(message: String)
        case blocked(reason: String)
        case invalid(reason: String)
        case error(String)
    }
    
    // MARK: - Actions
    
    @MainActor
    func sendMessageWithResult(_ text: String, to receiverId: UUID, tradeId: UUID? = nil, imageUrl: String? = nil) async -> SendResult {
        guard let myId = currentUserId else {
            return .error("Not logged in")
        }
        
        let isSystemMessage = text.hasPrefix("ACTION:")
        let isImageMessage = imageUrl != nil
        var sanitizedContent = text
        
        if !isSystemMessage && !isImageMessage {
            let (allowed, rateLimitMsg) = await RateLimiter.canSendMessage()
            if !allowed {
                return .rateLimited(message: rateLimitMsg ?? "Too many messages")
            }
            
            let sanitizeResult = MessageSanitizer.sanitize(text)
            
            switch sanitizeResult {
            case .valid(let sanitized):
                sanitizedContent = sanitized
            case .tooLong(let maxAllowed):
                return .invalid(reason: "Message too long. Maximum \(maxAllowed) characters allowed.")
            case .tooShort:
                return .invalid(reason: "Message too short.")
            case .empty:
                return .invalid(reason: "Message cannot be empty.")
            case .blocked(let reason):
                return .blocked(reason: reason)
            case .invalid(let reason):
                return .invalid(reason: reason)
            }
        }
        
        let newMessage = Message(
            id: UUID(),
            senderId: myId,
            receiverId: receiverId,
            content: sanitizedContent,
            createdAt: Date(),
            imageUrl: imageUrl,
            tradeId: tradeId
        )
        
        // Optimistic UI Update
        appendMessage(newMessage)
        
        do {
            try await client.from("messages").insert(newMessage).execute()
            
            // ✨ NEW: Auto-mark as read since we just sent a message
            if let tId = tradeId {
                markAsRead(tradeId: tId)
            }
            
            return .success
        } catch {
            print("❌ Failed to send message: \(error)")
            return .error(error.localizedDescription)
        }
    }
    
    @MainActor
    func sendMessage(_ text: String, to receiverId: UUID, tradeId: UUID? = nil, imageUrl: String? = nil) async {
        let result = await sendMessageWithResult(text, to: receiverId, tradeId: tradeId, imageUrl: imageUrl)
        
        switch result {
        case .success:
            break
        case .rateLimited(let message), .blocked(let message), .invalid(let message), .error(let message):
            print("⚠️ Message Error: \(message)")
            self.lastMessageError = message
            self.showMessageError = true
        }
    }
    
    @MainActor
    func sendSystemMessage(_ actionType: String, to receiverId: UUID, tradeId: UUID) async {
        let content = "ACTION:\(actionType)"
        await sendMessage(content, to: receiverId, tradeId: tradeId)
    }
    
    @MainActor
    func sendImage(data: Data, to receiverId: UUID, tradeId: UUID) async {
        guard let myId = currentUserId else { return }
        
        let (allowed, rateLimitMsg) = await RateLimiter.canSendMessage()
        if !allowed {
            self.lastMessageError = rateLimitMsg
            self.showMessageError = true
            return
        }
        
        do {
            let filename = "\(myId)/\(UUID().uuidString).jpg"
            
            let _ = try await client.storage
                .from("chat-images")
                .upload(filename, data: data, options: FileOptions(contentType: "image/jpeg"))
            
            let projectUrl = SupabaseConfig.supabaseURL.absoluteString
            let publicUrl = "\(projectUrl)/storage/v1/object/public/chat-images/\(filename)"
            
            await sendMessage("Sent an image", to: receiverId, tradeId: tradeId, imageUrl: publicUrl)
        } catch {
            print("❌ Failed to upload image: \(error)")
        }
    }
    
    @MainActor
    func deleteConversation(tradeId: UUID) async {
        do {
            try await client.from("messages").delete().eq("trade_id", value: tradeId).execute()
            conversations.removeValue(forKey: tradeId)
        } catch {
            print("❌ Failed to delete chat: \(error)")
        }
    }
    
    // MARK: - Fetching & Realtime
    
    @MainActor
    func fetchInbox(userId: UUID) async {
        do {
            let messages: [Message] = try await client
                .from("messages")
                .select()
                .or("sender_id.eq.\(userId),receiver_id.eq.\(userId)")
                .order("created_at", ascending: false)
                .limit(50)
                .execute()
                .value
            
            let sorted = messages.sorted { $0.createdAt < $1.createdAt }
            self.conversations = Dictionary(grouping: sorted) { $0.tradeId ?? UUID() }
        } catch {
            print("❌ Error fetching inbox: \(error)")
        }
    }
    
    @MainActor
    func loadChat(tradeId: UUID) async {
        do {
            let messages: [Message] = try await client
                .from("messages")
                .select()
                .eq("trade_id", value: tradeId)
                .order("created_at", ascending: true)
                .execute()
                .value
            
            let sanitizedMessages = messages.map { message -> Message in
                var sanitized = message
                if !message.content.hasPrefix("ACTION:") {
                    sanitized = Message(
                        id: message.id,
                        senderId: message.senderId,
                        receiverId: message.receiverId,
                        content: MessageSanitizer.sanitizeForDisplay(message.content),
                        createdAt: message.createdAt,
                        imageUrl: message.imageUrl,
                        tradeId: message.tradeId
                    )
                }
                return sanitized
            }
            
            self.conversations[tradeId] = sanitizedMessages
        } catch {
            print("❌ Error loading chat room: \(error)")
        }
    }
    
    func subscribeToRealtime(userId: UUID) async {
        if let existingChannel = channel { await existingChannel.unsubscribe() }
        if let existingPresence = presenceChannel { await existingPresence.unsubscribe() }
        
        // 1. Messages Channel
        let newChannel = client.channel("public:messages")
        self.channel = newChannel
        
        let changeStream = newChannel.postgresChange(
            AnyAction.self,
            schema: "public",
            table: "messages",
            filter: .eq("receiver_id", value: userId)
        )
        
        // 2. Presence Channel
        let pChannel = client.channel("online_users")
        self.presenceChannel = pChannel
        
        struct UserPresence: Codable { let user_id: UUID }
        
        Task {
            let presenceStream = pChannel.presenceChange()
            for await presence in presenceStream {
                do {
                    let joins = try presence.decodeJoins(as: UserPresence.self)
                    let leaves = try presence.decodeLeaves(as: UserPresence.self)
                    
                    await MainActor.run {
                        for join in joins {
                            self.onlineUsers.insert(join.user_id)
                        }
                        for leave in leaves {
                            self.onlineUsers.remove(leave.user_id)
                        }
                    }
                } catch {
                    print("⚠️ Presence parse error: \(error)")
                }
            }
        }
        
        // 3. Connect & Track
        do {
            try await newChannel.subscribeWithError()
            try await pChannel.subscribeWithError()
            try await pChannel.track(UserPresence(user_id: userId))
            await MainActor.run { self.isConnected = true }
        } catch {
            print("⚠️ Realtime connection failed, retrying...")
            try? await Task.sleep(nanoseconds: 5 * 1_000_000_000)
            await subscribeToRealtime(userId: userId)
            return
        }
        
        // 4. Message Stream Processing
        Task {
            for await action in changeStream {
                guard let myId = await MainActor.run(body: { return self.currentUserId }) else { continue }
                
                await MainActor.run {
                    switch action {
                    case .insert(let insertAction):
                        do {
                            let data = try JSONEncoder().encode(insertAction.record)
                            var message = try JSONDecoder().decode(Message.self, from: data)
                            
                            if !message.content.hasPrefix("ACTION:") {
                                message = Message(
                                    id: message.id,
                                    senderId: message.senderId,
                                    receiverId: message.receiverId,
                                    content: MessageSanitizer.sanitizeForDisplay(message.content),
                                    createdAt: message.createdAt,
                                    imageUrl: message.imageUrl,
                                    tradeId: message.tradeId
                                )
                            }
                            
                            self.appendMessage(message)
                            
                            if message.senderId != myId {
                                let notificationBody = message.content.hasPrefix("ACTION:")
                                    ? "New Update on your trade"
                                    : String(message.content.prefix(100))
                                
                                NotificationManager.shared.sendLocalNotification(
                                    title: "New Message",
                                    body: notificationBody
                                )
                            }
                        } catch {
                            print("⚠️ Failed to decode realtime message: \(error)")
                        }
                    default:
                        break
                    }
                }
            }
            await MainActor.run { self.isConnected = false }
        }
    }
    
    @MainActor
    private func appendMessage(_ message: Message) {
        guard let tradeId = message.tradeId else { return }
        
        if conversations[tradeId] == nil {
            conversations[tradeId] = []
        }
        
        if !(conversations[tradeId]?.contains(where: { $0.id == message.id }) ?? false) {
            conversations[tradeId]?.append(message)
            conversations[tradeId]?.sort { $0.createdAt < $1.createdAt }
        }
    }
}
