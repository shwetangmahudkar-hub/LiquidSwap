import SwiftUI

struct ChatsListView: View {
    @Environment(\.colorScheme) private var colorScheme
    @ObservedObject var tradeManager = TradeManager.shared
    @ObservedObject var userManager = UserManager.shared
    @ObservedObject var chatManager = ChatManager.shared
    @ObservedObject var tabManager = TabBarManager.shared
    
    // UI State
    @State private var searchText = ""
    @State private var isSearchFocused = false
    
    // MARK: - Adaptive Colors
    private var primaryText: Color {
        colorScheme == .dark ? .white : .black
    }
    
    private var secondaryText: Color {
        colorScheme == .dark ? .white.opacity(0.5) : .black.opacity(0.5)
    }
    
    private var tertiaryText: Color {
        colorScheme == .dark ? .white.opacity(0.4) : .black.opacity(0.4)
    }
    
    // Computed Properties
    var filteredTrades: [TradeOffer] {
        let trades = tradeManager.activeTrades
        
        if searchText.isEmpty {
            return trades.sorted { t1, t2 in
                let t1Action = requiresAction(t1)
                let t2Action = requiresAction(t2)
                
                // Priority 1: Action Required
                if t1Action && !t2Action { return true }
                if !t1Action && t2Action { return false }
                
                // Priority 2: Most Recent Message
                let t1LastMessageTime = chatManager.conversations[t1.id]?.last?.createdAt ?? t1.createdAt
                let t2LastMessageTime = chatManager.conversations[t2.id]?.last?.createdAt ?? t2.createdAt
                
                return t1LastMessageTime > t2LastMessageTime
            }
        } else {
            return trades.filter { trade in
                let partnerId = (trade.senderId == userManager.currentUser?.id) ? trade.receiverId : trade.senderId
                let profile = tradeManager.relatedProfiles[partnerId]
                let username = profile?.username.lowercased() ?? ""
                let itemTitle = trade.offeredItem?.title.lowercased() ?? ""
                let query = searchText.lowercased()
                
                return username.contains(query) || itemTitle.contains(query)
            }
        }
    }
    
    var body: some View {
        NavigationStack {
            ZStack(alignment: .bottom) {
                // Global Background
                LiquidBackground()
                    .ignoresSafeArea()
                
                // Main Content
                if filteredTrades.isEmpty {
                    emptyState
                } else {
                    ScrollView {
                        LazyVStack(spacing: 12) {
                            ForEach(filteredTrades) { trade in
                                NavigationLink(destination: ChatRoomView(trade: trade)) {
                                    ChatRow(
                                        trade: trade,
                                        partnerProfile: getPartnerProfile(for: trade),
                                        lastMessage: chatManager.conversations[trade.id]?.last,
                                        requiresAction: requiresAction(trade),
                                        isOnline: isPartnerOnline(for: trade),
                                        hasUnread: chatManager.hasUnreadMessages(tradeId: trade.id) // ✨ NEW: Pass Unread Status
                                    )
                                }
                                .buttonStyle(.plain)
                            }
                        }
                        .padding(.horizontal, DS.Spacing.edge)
                        .padding(.top, 20)
                        .padding(.bottom, 120)
                    }
                }
                
                // FLOATING SEARCH PILL
                floatingSearchPill
                    .padding(.bottom, tabManager.isVisible ? 100 : 16)
                    .animation(.spring(response: 0.5, dampingFraction: 0.8), value: tabManager.isVisible)
            }
            .onAppear {
                Task {
                    await tradeManager.loadTradesData()
                }
            }
        }
    }
    
    // MARK: - Subviews
    
    private var floatingSearchPill: some View {
        HStack(spacing: 12) {
            Image(systemName: "magnifyingglass")
                .font(.subheadline.bold())
                .foregroundStyle(.cyan)
            
            TextField("Search chats...", text: $searchText)
                .font(.subheadline)
                .foregroundStyle(.white)
                .accentColor(.cyan)
            
            if !searchText.isEmpty {
                Button(action: { searchText = "" }) {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundStyle(.white.opacity(0.6))
                }
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 14)
        .background(.ultraThinMaterial)
        .clipShape(Capsule())
        .shadow(color: .black.opacity(0.25), radius: 8, y: 4)
        .overlay(Capsule().stroke(Color.white.opacity(0.1), lineWidth: 1))
        .padding(.horizontal, 16)
    }
    
    private var emptyState: some View {
        VStack(spacing: 16) {
            Spacer()
            ZStack {
                Circle()
                    .fill(Color.cyan.opacity(0.1))
                    .frame(width: 80, height: 80)
                Image(systemName: "bubble.left.and.bubble.right.fill")
                    .font(.system(size: 32))
                    .foregroundStyle(.cyan.opacity(0.6))
            }
            VStack(spacing: 6) {
                Text(searchText.isEmpty ? "No active chats" : "No results found")
                    .appFont(16, weight: .bold)
                    .foregroundStyle(primaryText)
                Text(searchText.isEmpty ? "Start a trade to begin chatting." : "Try a different search term.")
                    .appFont(13)
                    .foregroundStyle(secondaryText)
                    .multilineTextAlignment(.center)
            }
            Spacer()
        }
    }
    
    // MARK: - Helpers
    
    func getPartnerProfile(for trade: TradeOffer) -> UserProfile? {
        guard let myId = userManager.currentUser?.id else { return nil }
        let partnerId = (trade.senderId == myId) ? trade.receiverId : trade.senderId
        return tradeManager.relatedProfiles[partnerId]
    }
    
    func requiresAction(_ trade: TradeOffer) -> Bool {
        guard let myId = userManager.currentUser?.id else { return false }
        if trade.status == .pending && trade.receiverId == myId { return true }
        if trade.status == .accepted { return true }
        return false
    }
    
    func isPartnerOnline(for trade: TradeOffer) -> Bool {
        guard let myId = userManager.currentUser?.id else { return false }
        let partnerId = (trade.senderId == myId) ? trade.receiverId : trade.senderId
        return chatManager.onlineUsers.contains(partnerId)
    }
}

// MARK: - Chat Row Component

struct ChatRow: View {
    @Environment(\.colorScheme) private var colorScheme
    let trade: TradeOffer
    let partnerProfile: UserProfile?
    let lastMessage: Message?
    let requiresAction: Bool
    let isOnline: Bool
    let hasUnread: Bool // ✨ NEW: Receives Unread Status
    
    private var primaryText: Color {
        colorScheme == .dark ? .white : .black
    }
    
    private var secondaryText: Color {
        colorScheme == .dark ? .white.opacity(0.5) : .black.opacity(0.5)
    }
    
    private var tertiaryText: Color {
        colorScheme == .dark ? .white.opacity(0.4) : .black.opacity(0.4)
    }
    
    var body: some View {
        HStack(spacing: 12) {
            // Avatar
            ZStack {
                Circle()
                    .fill(Color.gray.opacity(0.2))
                    .frame(width: 50, height: 50)
                
                if let url = partnerProfile?.avatarUrl {
                    AsyncImageView(filename: url)
                        .scaledToFill()
                        .frame(width: 50, height: 50)
                        .clipShape(Circle())
                } else {
                    Image(systemName: "person.fill")
                        .foregroundStyle(.gray)
                }
                
                if isOnline {
                    VStack {
                        Spacer()
                        HStack {
                            Spacer()
                            Circle()
                                .fill(Color.green)
                                .frame(width: 14, height: 14)
                                .overlay(Circle().stroke(Color.black, lineWidth: 2.5))
                                .shadow(color: .green.opacity(0.4), radius: 4)
                        }
                    }
                }
            }
            .frame(width: 50, height: 50)
            
            // Content
            VStack(alignment: .leading, spacing: 4) {
                HStack(alignment: .top) {
                    Text(partnerProfile?.username ?? "Unknown")
                        .appFont(15, weight: .bold)
                        .foregroundStyle(hasUnread ? .white : primaryText) // Brighten name if unread
                    
                    Spacer()
                    
                    VStack(alignment: .trailing, spacing: 4) {
                        if let msg = lastMessage {
                            Text(msg.createdAt.formatted(date: .omitted, time: .shortened))
                                .font(.caption2)
                                .foregroundStyle(hasUnread ? .cyan : tertiaryText) // Highlight time if unread
                        } else {
                            Text(trade.createdAt.formatted(date: .omitted, time: .shortened))
                                .font(.caption2)
                                .foregroundStyle(tertiaryText)
                        }
                        
                        StatusPillSmall(status: trade.status.displayName)
                    }
                }
                
                // Dynamic Message Snippet
                HStack(spacing: 4) {
                    if let msg = lastMessage {
                        if msg.imageUrl != nil {
                            Image(systemName: "photo")
                                .font(.caption2)
                                .foregroundStyle(tertiaryText)
                            Text("Sent an image")
                                .appFont(13, weight: hasUnread ? .bold : .regular)
                                .foregroundStyle(hasUnread ? .white : secondaryText)
                                .lineLimit(1)
                        } else if msg.content.hasPrefix("ACTION:") || msg.content.contains("📍") {
                            Image(systemName: "arrow.triangle.2.circlepath")
                                .font(.caption2)
                                .foregroundStyle(tertiaryText)
                            Text("Trade update")
                                .appFont(13, weight: hasUnread ? .bold : .regular)
                                .foregroundStyle(hasUnread ? .white : secondaryText)
                                .lineLimit(1)
                        } else {
                            Text(msg.content)
                                .appFont(13, weight: hasUnread ? .bold : .regular)
                                .foregroundStyle(hasUnread ? .white : secondaryText)
                                .lineLimit(1)
                        }
                    } else {
                        Text("Trading:")
                            .appFont(12)
                            .foregroundStyle(tertiaryText)
                        Text(trade.offeredItem?.title ?? "Item")
                            .appFont(12, weight: .medium)
                            .foregroundStyle(secondaryText)
                            .lineLimit(1)
                    }
                }
            }
            
            // ✨ UPDATED: Unread / Action Notification Dot Logic
            if requiresAction {
                Circle()
                    .fill(Color.orange)
                    .frame(width: 9, height: 9)
                    .shadow(color: .orange, radius: 4)
            } else if hasUnread {
                Circle()
                    .fill(Color.cyan)
                    .frame(width: 9, height: 9)
                    .shadow(color: .cyan, radius: 4)
            } else {
                Image(systemName: "chevron.right")
                    .font(.caption2.bold())
                    .foregroundStyle(tertiaryText)
            }
        }
        .padding(14)
        .background(.ultraThinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .stroke(
                    requiresAction ? AnyShapeStyle(Color.orange.opacity(0.5)) :
                        (hasUnread ? AnyShapeStyle(Color.cyan.opacity(0.5)) : AnyShapeStyle(Color.white.opacity(0.1))),
                    lineWidth: (requiresAction || hasUnread) ? 1.5 : 1
                )
        )
        .shadow(color: .black.opacity(0.08), radius: 4, y: 2)
    }
}

// Helper Pill
struct StatusPillSmall: View {
    let status: String
    
    var color: Color {
        switch status.lowercased() {
        case "pending": return .orange
        case "accepted": return .green
        case "rejected": return .red
        case "countered": return .purple
        case "completed": return .gray
        default: return .white
        }
    }
    
    var body: some View {
        Text(status.capitalized)
            .font(.system(size: 9, weight: .bold))
            .foregroundStyle(color)
            .padding(.horizontal, 5)
            .padding(.vertical, 2)
            .background(color.opacity(0.15))
            .clipShape(Capsule())
    }
}
