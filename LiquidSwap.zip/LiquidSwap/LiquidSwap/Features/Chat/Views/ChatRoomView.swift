import SwiftUI
import MapKit
import CoreLocation
import PhotosUI

struct ChatRoomView: View {
    let trade: TradeOffer
    
    // MARK: - Managers
    @ObservedObject var chatManager = ChatManager.shared
    @ObservedObject var userManager = UserManager.shared
    @ObservedObject var tradeManager = TradeManager.shared
    @ObservedObject var tabManager = TabBarManager.shared
    
    @Environment(\.dismiss) var dismiss
    
    // MARK: - Input State
    @State private var newMessageText = ""
    @FocusState private var isFocused: Bool
    @State private var isCurrentlyTyping = false
    @State private var replyingToMessage: Message? = nil
    
    // MARK: - Trade State
    @State private var showRatingSheet = false
    @State private var isCompletingTrade = false
    @State private var showNoTradeAlert = false
    @State private var partnerName = "Trading Partner"
    @State private var showDealDashboard = true
    @State private var showSafeMap = false
    
    // MARK: - Two-Phase Completion State
    @State private var currentTrade: TradeOffer?
    @State private var userHasConfirmed = false
    @State private var partnerHasConfirmed = false
    @State private var showCompletionStatusBanner = false
    
    // MARK: - Celebration State
    @State private var showCompletionCelebration = false
    
    // MARK: - Safety Alerts
    @State private var showBlockAlert = false
    @State private var showReportAlert = false
    
    // MARK: - Counter Offer
    @State private var showCounterSheet = false
    
    // MARK: - Premium & Media State
    @State private var showPremiumPaywall = false
    @State private var selectedPhotoItem: PhotosPickerItem?
    @State private var selectedCameraImage: UIImage?
    @State private var showCamera = false
    @State private var isSendingImage = false
    @State private var showAttachmentOptions = false
    
    // MARK: - Computed Properties
    var myId: UUID? { userManager.currentUser?.id }
    
    var partnerId: UUID {
        guard let myId = myId else { return trade.receiverId }
        return (trade.senderId == myId) ? trade.receiverId : trade.senderId
    }
    
    var messages: [Message] {
        return chatManager.conversations[trade.id] ?? []
    }
    
    var activeTrade: TradeOffer {
        return currentTrade ?? trade
    }
    
    // MARK: - Body
    var body: some View {
        ZStack {
            // 1. Global Background
            LiquidBackground().ignoresSafeArea()
            
            // 2. Main Layout
            mainContent
            
            // 3. Celebration Overlay
            if showCompletionCelebration {
                TradeCompletionOverlay(onDismiss: {
                    showCompletionCelebration = false
                    showRatingSheet = true
                })
                .zIndex(200)
                .transition(.opacity.combined(with: .scale(scale: 0.9)))
            }
        }
        .navigationBarHidden(true)
        .overlay(alignment: .bottom) {
            inputSection
        }
        .onAppear {
            setupView()
        }
        .onDisappear {
            TabBarManager.shared.show()
            Task { await chatManager.setActiveTrade(tradeId: nil) }
        }
        .modifier(ChatSheetModifier(
            isPresented: $showPremiumPaywall,
            sheetType: .premium
        ))
        .sheet(isPresented: $showCamera) {
            CameraPicker(selectedImage: $selectedCameraImage).ignoresSafeArea()
        }
        .sheet(isPresented: $showRatingSheet) {
            RateUserView(targetUserId: partnerId, targetUsername: partnerName, tradeId: trade.id)
        }
        .sheet(isPresented: $showCounterSheet) {
            CounterOfferSheet(originalTrade: activeTrade)
                .presentationDetents([.medium, .large])
        }
        .sheet(isPresented: $showSafeMap) {
            safeMapSheet
        }
        .alert("No Trade Found", isPresented: $showNoTradeAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text("This trade is no longer active.")
        }
        .alert("Block User?", isPresented: $showBlockAlert) {
            Button("Block", role: .destructive) { blockUser() }
            Button("Cancel", role: .cancel) { }
        } message: {
            Text("You will no longer receive messages from this user.")
        }
        .alert("Report User?", isPresented: $showReportAlert) {
            Button("Spam", role: .destructive) { reportUser(id: partnerId, reason: "Spam") }
            Button("Abusive", role: .destructive) { reportUser(id: partnerId, reason: "Abusive") }
            Button("Cancel", role: .cancel) { }
        } message: {
            Text("Please select a reason for reporting.")
        }
        .onChange(of: selectedPhotoItem) { newItem in handlePhotoSelection(newItem) }
        .onChange(of: selectedCameraImage) { newImage in handleCameraSelection(newImage) }
        .onChange(of: newMessageText) { newValue in
            let typing = !newValue.isEmpty
            if typing != isCurrentlyTyping {
                isCurrentlyTyping = typing
                Task { await chatManager.updateTypingStatus(isTyping: typing) }
            }
        }
    }
    
    // MARK: - Subviews
    
    var mainContent: some View {
        VStack(spacing: 0) {
            customHeader
                .zIndex(100)
            
            if showCompletionStatusBanner && activeTrade.status == .accepted {
                completionStatusBanner
                    .zIndex(95)
                    .transition(.move(edge: .top).combined(with: .opacity))
            }
            
            DealDashboard(
                trade: activeTrade,
                isExpanded: $showDealDashboard,
                currentUserId: myId,
                onCounter: { showCounterSheet = true }
            )
            .zIndex(90)
            
            messageListSection
                .onTapGesture {
                    dismissKeyboard()
                    withAnimation { showAttachmentOptions = false }
                }
        }
    }
    
    // MARK: - Completion Status Banner
    
    var completionStatusBanner: some View {
        HStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(bannerColor.opacity(0.2))
                    .frame(width: 36, height: 36)
                
                if userHasConfirmed && partnerHasConfirmed {
                    Image(systemName: "checkmark.seal.fill")
                        .foregroundStyle(.green)
                } else if userHasConfirmed {
                    Image(systemName: "hourglass")
                        .foregroundStyle(.orange)
                } else if partnerHasConfirmed {
                    Image(systemName: "exclamationmark.circle.fill")
                        .foregroundStyle(.cyan)
                } else {
                    Image(systemName: "arrow.triangle.2.circlepath")
                        .foregroundStyle(.white.opacity(0.6))
                }
            }
            
            VStack(alignment: .leading, spacing: 2) {
                Text(bannerTitle)
                    .font(.subheadline.bold())
                    .foregroundStyle(.white)
                
                Text(bannerSubtitle)
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.7))
            }
            
            Spacer()
            
            if partnerHasConfirmed && !userHasConfirmed {
                Button(action: { confirmMyCompletion() }) {
                    Text("Confirm")
                        .font(.caption.bold())
                        .foregroundStyle(.black)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 8)
                        .background(Color.cyan)
                        .clipShape(Capsule())
                }
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(bannerColor.opacity(0.15))
        .background(.ultraThinMaterial)
        .overlay(
            Rectangle()
                .frame(height: 1)
                .foregroundStyle(bannerColor.opacity(0.3)),
            alignment: .bottom
        )
    }
    
    var bannerColor: Color {
        if userHasConfirmed && partnerHasConfirmed {
            return .green
        } else if partnerHasConfirmed && !userHasConfirmed {
            return .cyan
        } else if userHasConfirmed {
            return .orange
        }
        return .white
    }
    
    var bannerTitle: String {
        if userHasConfirmed && partnerHasConfirmed {
            return "Trade Complete!"
        } else if partnerHasConfirmed && !userHasConfirmed {
            return "Partner Confirmed"
        } else if userHasConfirmed {
            return "Waiting for Partner"
        }
        return "Ready to Complete"
    }
    
    var bannerSubtitle: String {
        if userHasConfirmed && partnerHasConfirmed {
            return "Both parties have confirmed the exchange"
        } else if partnerHasConfirmed && !userHasConfirmed {
            return "Tap Confirm when you've received your item"
        } else if userHasConfirmed {
            return "Your partner needs to confirm the exchange"
        }
        return "Both parties must confirm to complete"
    }
    
    var inputSection: some View {
        ChatInputBar(
            text: $newMessageText,
            isPremium: userManager.isPremium,
            isFocused: $isFocused, // ✨ FIXED: Connects keyboard focus
            replyingToMessage: $replyingToMessage,
            onCancelReply: { withAnimation { replyingToMessage = nil } },
            onSend: sendMessage,
            onMapTap: { showSafeMap = true },
            onCameraTap: {
                if userManager.isPremium {
                    showCamera = true
                } else {
                    showPremiumPaywall = true
                }
            },
            onPhotoTap: {
            },
            selectedPhotoItem: $selectedPhotoItem,
            showOptions: $showAttachmentOptions
        )
        .padding(.bottom, tabManager.isVisible ? 100 : 16)
        .animation(.spring(response: 0.5, dampingFraction: 0.8), value: tabManager.isVisible)
    }
    
    var safeMapSheet: some View {
        let userLoc = LocationManager.shared.userLocation?.coordinate
        let start = getCoordinate(for: activeTrade.offeredItem) ?? userLoc ?? CLLocationCoordinate2D(latitude: 43.6532, longitude: -79.3832)
        let end = getCoordinate(for: activeTrade.wantedItem) ?? userLoc ?? CLLocationCoordinate2D(latitude: 43.6532, longitude: -79.3832)
        
        return SafeMeetingPointView(
            locationA: start,
            locationB: end,
            onSendLocation: { name, _ in
                let msg = "📍 Let's meet at **\(name)**. It's a Verified Safe Zone."
                Task { await chatManager.sendMessage(msg, to: partnerId, tradeId: trade.id) }
                showSafeMap = false
            }
        )
    }
    
    // MARK: - Custom Header
    
    var customHeader: some View {
        HStack(spacing: 16) {
            Button(action: { dismiss() }) {
                GlassNavButton(icon: "arrow.left")
            }
            
            VStack(alignment: .leading, spacing: 2) {
                Text(partnerName)
                    .font(.headline)
                    .foregroundStyle(.white)
                
                HStack(spacing: 6) {
                    Circle()
                        .fill(chatManager.isConnected ? Color.green : Color.orange)
                        .frame(width: 8, height: 8)
                    Text(chatManager.isConnected ? "Online" : "Connecting...")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.7))
                }
            }
            
            Spacer()
            
            HStack(spacing: 12) {
                if activeTrade.status == .accepted {
                    completionButton
                }
                
                Menu {
                    Button(role: .destructive, action: { showBlockAlert = true }) {
                        Label("Block User", systemImage: "hand.raised.fill")
                    }
                    Button(action: { showReportAlert = true }) {
                        Label("Report User", systemImage: "exclamationmark.bubble")
                    }
                } label: {
                    Image(systemName: "ellipsis")
                        .font(.system(size: 20))
                        .foregroundStyle(.white)
                        .frame(width: 44, height: 44)
                        .background(Color.white.opacity(0.1))
                        .clipShape(Circle())
                }
            }
        }
        .padding(.horizontal)
        .padding(.bottom, 12)
        .padding(.top, 0)
        .background(.ultraThinMaterial)
        .overlay(Rectangle().frame(height: 1).foregroundStyle(Color.white.opacity(0.1)), alignment: .bottom)
        .shadow(color: .black.opacity(0.1), radius: 5, y: 5)
    }
    
    // MARK: - Completion Button
    
    var completionButton: some View {
        Button {
            confirmMyCompletion()
        } label: {
            ZStack {
                if isCompletingTrade {
                    ProgressView().tint(.cyan)
                } else if userHasConfirmed {
                    Image(systemName: "hourglass")
                        .font(.system(size: 18))
                        .foregroundStyle(.orange)
                        .frame(width: 44, height: 44)
                        .background(Color.orange.opacity(0.1))
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.orange.opacity(0.3), lineWidth: 1))
                } else if partnerHasConfirmed {
                    Image(systemName: "checkmark.seal.fill")
                        .font(.system(size: 20))
                        .foregroundStyle(.white)
                        .frame(width: 44, height: 44)
                        .background(Color.cyan)
                        .clipShape(Circle())
                        .shadow(color: .cyan.opacity(0.5), radius: 8)
                } else {
                    Image(systemName: "checkmark.seal.fill")
                        .font(.system(size: 20))
                        .foregroundStyle(.cyan)
                        .frame(width: 44, height: 44)
                        .background(Color.cyan.opacity(0.1))
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.cyan.opacity(0.3), lineWidth: 1))
                }
            }
        }
        .disabled(isCompletingTrade || userHasConfirmed)
    }
    
    // MARK: - Message List Section
    
    var messageListSection: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 0) {
                    Color.clear.frame(height: 10)
                    
                    let sections = groupedMessages
                    let myLastMessageId = messages.last(where: { $0.senderId == myId })?.id
                    
                    if sections.isEmpty {
                        VStack(spacing: 16) {
                            Image(systemName: "bubble.left.and.bubble.right.fill")
                                .font(.system(size: 40))
                                .foregroundStyle(.white.opacity(0.1))
                            Text("This is the start of your conversation.")
                                .font(.caption)
                                .foregroundStyle(.white.opacity(0.4))
                        }
                        .padding(.top, 60)
                    }
                    
                    ForEach(sections, id: \.date) { section in
                        Section(header: DateHeader(date: section.date)) {
                            ForEach(Array(section.messages.enumerated()), id: \.element.id) { index, message in
                                ChatMessageRow(
                                    message: message,
                                    nextMessage: index < section.messages.count - 1 ? section.messages[index + 1] : nil,
                                    previousMessage: index > 0 ? section.messages[index - 1] : nil,
                                    isCurrentUser: message.senderId == myId,
                                    myLastMessageId: myLastMessageId,
                                    trade: activeTrade,
                                    partnerId: partnerId,
                                    userHasConfirmed: userHasConfirmed,
                                    partnerHasConfirmed: partnerHasConfirmed,
                                    allMessages: messages,
                                    onReply: { msg in
                                        withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) { replyingToMessage = msg }
                                        isFocused = true // Trigger keyboard
                                    },
                                    onConfirm: { confirmMyCompletion() }
                                )
                                .id(message.id)
                            }
                        }
                    }
                    
                    if isSendingImage {
                        HStack {
                            Spacer()
                            ProgressView()
                                .tint(.white)
                                .padding()
                                .background(Color.white.opacity(0.1))
                                .clipShape(Circle())
                        }
                        .padding(.horizontal)
                        .id("uploading")
                    }
                    
                    if chatManager.typingUsers.contains(partnerId) {
                        TypingIndicatorBubble()
                            .id("typing")
                            .transition(.opacity.combined(with: .scale(scale: 0.9, anchor: .bottomLeading)))
                            .padding(.bottom, 12)
                    }
                    
                    Color.clear.frame(height: 120).id("bottom")
                }
                .padding(.horizontal)
                .padding(.bottom, 20)
            }
            .scrollDismissesKeyboard(.interactively)
            .onChange(of: messages.count) { _ in
                withAnimation(.spring()) {
                    proxy.scrollTo("bottom", anchor: .bottom)
                }
            }
            .onChange(of: chatManager.typingUsers) { _ in
                if chatManager.typingUsers.contains(partnerId) {
                    withAnimation(.spring()) {
                        proxy.scrollTo("bottom", anchor: .bottom)
                    }
                }
            }
            .onAppear {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    proxy.scrollTo("bottom", anchor: .bottom)
                }
            }
        }
    }
    
    // MARK: - Logic & Helpers
    
    struct MessageSection: Hashable {
        let date: Date
        let messages: [Message]
    }
    
    var groupedMessages: [MessageSection] {
        let grouped = Dictionary(grouping: messages) { (message) -> Date in
            Calendar.current.startOfDay(for: message.createdAt)
        }
        return grouped.keys.sorted().map { date in
            MessageSection(date: date, messages: grouped[date]!.sorted { $0.createdAt < $1.createdAt })
        }
    }
    
    func setupView() {
        chatManager.markAsRead(tradeId: trade.id)
        TabBarManager.shared.hide()
        fetchPartnerProfile()
        currentTrade = trade
        
        Task {
            await chatManager.setActiveTrade(tradeId: trade.id)
            await chatManager.loadChat(tradeId: trade.id)
            await refreshCompletionStatus()
        }
    }
    
    func refreshCompletionStatus() async {
        guard let myId = myId else { return }
        
        if let freshTrade = await tradeManager.fetchTrade(id: trade.id) {
            
            var shouldShowFlow = false
            if freshTrade.status == .completed {
                if let canReview = try? await DatabaseService.shared.canReviewTrade(reviewerId: myId, tradeId: trade.id) {
                    shouldShowFlow = canReview
                }
            }
            
            await MainActor.run {
                self.currentTrade = freshTrade
                let isSender = freshTrade.senderId == myId
                self.userHasConfirmed = isSender ? freshTrade.senderConfirmedCompletion : freshTrade.receiverConfirmedCompletion
                self.partnerHasConfirmed = isSender ? freshTrade.receiverConfirmedCompletion : freshTrade.senderConfirmedCompletion
                
                withAnimation {
                    self.showCompletionStatusBanner = freshTrade.status == .accepted && (userHasConfirmed || partnerHasConfirmed)
                }
                
                if shouldShowFlow && !showCompletionCelebration && !showRatingSheet {
                    withAnimation(.spring(response: 0.6, dampingFraction: 0.7)) {
                        showCompletionCelebration = true
                    }
                }
            }
        }
    }
    
    func confirmMyCompletion() {
        guard !isCompletingTrade && !userHasConfirmed else { return }
        isCompletingTrade = true
        Haptics.shared.playMedium()
        
        Task {
            let result = await tradeManager.confirmCompletion(tradeId: trade.id)
            await MainActor.run {
                isCompletingTrade = false
                switch result {
                case .tradeCompleted:
                    Haptics.shared.playSuccess()
                    userHasConfirmed = true
                    partnerHasConfirmed = true
                    withAnimation(.spring(response: 0.6, dampingFraction: 0.7)) {
                        showCompletionCelebration = true
                    }
                case .confirmed:
                    Haptics.shared.playLight()
                    userHasConfirmed = true
                    withAnimation { showCompletionStatusBanner = true }
                    Task { await chatManager.sendSystemMessage("COMPLETE_REQUEST", to: partnerId, tradeId: trade.id) }
                case .alreadyConfirmed:
                    userHasConfirmed = true
                default:
                    Haptics.shared.playError()
                }
            }
            await refreshCompletionStatus()
        }
    }
    
    func dismissKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
    
    func sendMessage() {
        guard !newMessageText.isEmpty else { return }
        let text = newMessageText
        let replyId = replyingToMessage?.id
        
        newMessageText = ""
        withAnimation { replyingToMessage = nil }
        
        Task { await chatManager.sendMessage(text, to: partnerId, tradeId: trade.id, replyToId: replyId) }
    }
    
    func fetchPartnerProfile() {
        if let cached = tradeManager.relatedProfiles[partnerId] {
            self.partnerName = cached.username
            return
        }
        Task {
            if let profile = try? await DatabaseService.shared.fetchProfile(userId: partnerId) {
                await MainActor.run { self.partnerName = profile.username }
            }
        }
    }
    
    func blockUser() {
        Task {
            await UserManager.shared.blockUser(userId: partnerId)
            dismiss()
        }
    }
    
    func reportUser(id: UUID, reason: String) {
        guard let myId = myId else { return }
        Task {
            try? await DatabaseService.shared.reportUser(reporterId: myId, reportedId: id, reason: reason)
        }
    }
    
    func getCoordinate(for item: TradeItem?) -> CLLocationCoordinate2D? {
        guard let lat = item?.latitude, let lon = item?.longitude,
              lat != 0, lon != 0,
              !lat.isNaN, !lon.isNaN else { return nil }
        return CLLocationCoordinate2D(latitude: lat, longitude: lon)
    }
    
    func handlePhotoSelection(_ newItem: PhotosPickerItem?) {
        guard let newItem = newItem else { return }
        Task {
            if let data = try? await newItem.loadTransferable(type: Data.self) {
                await MainActor.run { isSendingImage = true }
                await chatManager.sendImage(data: data, to: partnerId, tradeId: trade.id)
                await MainActor.run {
                    isSendingImage = false
                    selectedPhotoItem = nil
                    showAttachmentOptions = false
                }
            }
        }
    }
    
    func handleCameraSelection(_ newImage: UIImage?) {
        if let image = newImage, let data = image.jpegData(compressionQuality: 0.7) {
            Task {
                await MainActor.run { isSendingImage = true }
                await chatManager.sendImage(data: data, to: partnerId, tradeId: trade.id)
                await MainActor.run {
                    isSendingImage = false
                    selectedCameraImage = nil
                    showAttachmentOptions = false
                }
            }
        }
    }
}

// MARK: - Row Logic
struct ChatMessageRow: View {
    let message: Message
    let nextMessage: Message?
    let previousMessage: Message?
    let isCurrentUser: Bool
    let myLastMessageId: UUID?
    let trade: TradeOffer
    let partnerId: UUID
    let userHasConfirmed: Bool
    let partnerHasConfirmed: Bool
    
    let allMessages: [Message]
    let onReply: (Message) -> Void
    let onConfirm: () -> Void
    
    @ObservedObject var chatManager = ChatManager.shared
    @State private var dragOffset: CGFloat = 0

    var body: some View {
        let isNextSameSender = nextMessage?.senderId == message.senderId
        let isPrevSameSender = previousMessage?.senderId == message.senderId
        
        let isNextWithinTime = nextMessage != nil ? nextMessage!.createdAt.timeIntervalSince(message.createdAt) < 300 : false
        let isPrevWithinTime = previousMessage != nil ? message.createdAt.timeIntervalSince(previousMessage!.createdAt) < 300 : false
        
        let isGroupedWithNext = isNextSameSender && isNextWithinTime
        let isGroupedWithPrev = isPrevSameSender && isPrevWithinTime
        
        let messageStatus: String? = {
            if message.id == myLastMessageId {
                let isPartnerInChat = chatManager.partnerActiveTrades[partnerId] == trade.id
                let partnerReadTime = chatManager.partnerReadTimes[trade.id.uuidString] ?? 0
                let messageTime = message.createdAt.timeIntervalSince1970
                
                if isPartnerInChat || partnerReadTime >= messageTime {
                    return "Read"
                } else {
                    return "Delivered"
                }
            }
            return nil
        }()
        
        let repliedMessage = message.replyToId != nil ? allMessages.first(where: { $0.id == message.replyToId }) : nil
        
        Group {
            if message.content.hasPrefix("ACTION:") {
                TwoPhaseActionBubble(
                    message: message,
                    isMine: isCurrentUser,
                    userConfirmed: userHasConfirmed,
                    partnerConfirmed: partnerHasConfirmed,
                    onConfirm: onConfirm
                )
                .padding(.bottom, 12)
            } else {
                MessageBubble(
                    message: message,
                    isCurrentUser: isCurrentUser,
                    isGroupedWithNext: isGroupedWithNext,
                    isGroupedWithPrev: isGroupedWithPrev,
                    messageStatus: messageStatus,
                    repliedMessage: repliedMessage
                )
                .offset(x: dragOffset)
                .background(
                    HStack {
                        if dragOffset > 20 {
                            Image(systemName: "arrowshape.turn.up.left.fill")
                                .font(.system(size: 20))
                                .foregroundStyle(.white.opacity(0.6))
                                .padding(.leading, 16)
                        }
                        Spacer()
                    }
                )
                .gesture(
                    // ✨ FIXED: Added minimumDistance to perfectly respect vertical scrolling
                    DragGesture(minimumDistance: 20, coordinateSpace: .local)
                        .onChanged { value in
                            if value.translation.width > 0 {
                                dragOffset = min(value.translation.width, 60)
                            }
                        }
                        .onEnded { value in
                            if dragOffset > 40 {
                                onReply(message)
                                Haptics.shared.playLight()
                            }
                            withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) {
                                dragOffset = 0
                            }
                        }
                )
                .padding(.bottom, isGroupedWithNext ? 2 : 12)
            }
        }
    }
}

// MARK: - UI COMPONENTS

struct ChatInputBar: View {
    @Binding var text: String
    let isPremium: Bool
    
    var isFocused: FocusState<Bool>.Binding // ✨ FIXED: Ties keyboard directly to TextField
    
    @Binding var replyingToMessage: Message?
    var onCancelReply: () -> Void
    
    var onSend: () -> Void
    var onMapTap: () -> Void
    var onCameraTap: () -> Void
    var onPhotoTap: () -> Void
    @Binding var selectedPhotoItem: PhotosPickerItem?
    @Binding var showOptions: Bool
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            
            // ✨ FIXED: Overlay Bug Resolved with clean transition and unified background
            if let replyMsg = replyingToMessage {
                HStack {
                    Rectangle()
                        .fill(Color.cyan)
                        .frame(width: 4)
                        .cornerRadius(2)
                    
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Replying")
                            .font(.caption.bold())
                            .foregroundStyle(.cyan)
                        
                        Text(replyMsg.content.isEmpty && replyMsg.imageUrl != nil ? "📸 Image" : replyMsg.content)
                            .font(.caption)
                            .foregroundStyle(.white.opacity(0.7))
                            .lineLimit(1)
                    }
                    Spacer()
                    
                    Button(action: onCancelReply) {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundStyle(.white.opacity(0.5))
                            .padding(8)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.top, 12)
                .padding(.bottom, 8)
                .background(Color.white.opacity(0.05))
                .transition(.opacity) // Safe transition prevents stretching artifacts
            }
            
            if showOptions {
                HStack(spacing: 20) {
                    Button(action: { onMapTap(); withAnimation { showOptions = false } }) {
                        VStack(spacing: 4) {
                            Circle().fill(Color.green.opacity(0.2)).frame(width: 44, height: 44)
                                .overlay(Image(systemName: "checkmark.shield.fill").foregroundStyle(.green))
                            Text("Safe Zone").font(.caption2).foregroundStyle(.white)
                        }
                    }
                    Button(action: { onCameraTap(); withAnimation { if isPremium { showOptions = false } } }) {
                        VStack(spacing: 4) {
                            ZStack {
                                Circle().fill(Color.blue.opacity(0.2)).frame(width: 44, height: 44)
                                Image(systemName: "camera.fill").foregroundStyle(.blue)
                                if !isPremium { Image(systemName: "lock.fill").font(.caption2).foregroundStyle(.yellow).offset(x: 14, y: -14) }
                            }
                            Text("Camera").font(.caption2).foregroundStyle(.white)
                        }
                    }
                    if isPremium {
                        PhotosPicker(selection: $selectedPhotoItem, matching: .images) {
                            VStack(spacing: 4) {
                                Circle().fill(Color.purple.opacity(0.2)).frame(width: 44, height: 44)
                                    .overlay(Image(systemName: "photo.on.rectangle").foregroundStyle(.purple))
                                Text("Gallery").font(.caption2).foregroundStyle(.white)
                            }
                        }
                    } else {
                        Button(action: onPhotoTap) {
                            VStack(spacing: 4) {
                                ZStack {
                                    Circle().fill(Color.purple.opacity(0.2)).frame(width: 44, height: 44)
                                    Image(systemName: "photo.on.rectangle").foregroundStyle(.purple)
                                    Image(systemName: "lock.fill").font(.caption2).foregroundStyle(.yellow).offset(x: 14, y: -14)
                                }
                                Text("Gallery").font(.caption2).foregroundStyle(.white)
                            }
                        }
                    }
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 16)
                .background(.ultraThinMaterial)
                .clipShape(RoundedRectangle(cornerRadius: 24))
                .padding(.leading, 16)
                .padding(.bottom, 8)
                .transition(.scale(scale: 0.8, anchor: .bottomLeading).combined(with: .opacity))
            }
            
            HStack(alignment: .bottom, spacing: 12) {
                Button(action: { withAnimation(.spring(response: 0.4, dampingFraction: 0.7)) { showOptions.toggle() } }) {
                    Image(systemName: showOptions ? "xmark.circle.fill" : "plus.circle.fill")
                        .font(.system(size: 30))
                        .foregroundStyle(showOptions ? .white.opacity(0.5) : .cyan)
                        .background(Color.black.clipShape(Circle()))
                }
                .padding(.bottom, 4)
                
                TextField("Message...", text: $text, axis: .vertical)
                    .focused(isFocused)
                    .font(.body)
                    .padding(12)
                    .background(Color.white.opacity(0.1))
                    .cornerRadius(20)
                    .foregroundStyle(.white)
                    .lineLimit(1...5)
                    .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white.opacity(0.2), lineWidth: 1))
                
                Button(action: onSend) {
                    Image(systemName: "arrow.up.circle.fill")
                        .font(.system(size: 38))
                        .foregroundStyle(text.isEmpty ? .gray : .cyan)
                        .background(Color.black.clipShape(Circle()))
                        .shadow(color: text.isEmpty ? .clear : .cyan.opacity(0.3), radius: 5)
                }
                .disabled(text.isEmpty)
                .padding(.bottom, 2)
            }
            .padding(.horizontal)
            .padding(.top, replyingToMessage != nil ? 4 : 12)
            .padding(.bottom, 8)
        }
        .background(.ultraThinMaterial) // ✨ Clean unified background
    }
}

struct TypingIndicatorBubble: View {
    @State private var bounce = false
    
    var body: some View {
        HStack(alignment: .bottom, spacing: 8) {
            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 4) {
                    ForEach(0..<3) { index in
                        Circle()
                            .fill(Color.white.opacity(0.6))
                            .frame(width: 6, height: 6)
                            .offset(y: bounce ? -3 : 3)
                            .animation(
                                .easeInOut(duration: 0.4)
                                .repeatForever(autoreverses: true)
                                .delay(Double(index) * 0.15),
                                value: bounce
                            )
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 14)
                .background(Color.white.opacity(0.15))
                .clipShape(UnevenRoundedRectangle(
                    topLeadingRadius: 18,
                    bottomLeadingRadius: 4,
                    bottomTrailingRadius: 18,
                    topTrailingRadius: 18
                ))
            }
            Spacer()
        }
        .onAppear {
            bounce = true
        }
    }
}

struct DateHeader: View {
    let date: Date
    var body: some View {
        Text(date.formatted(date: .abbreviated, time: .omitted))
            .font(.caption.bold())
            .foregroundStyle(.white.opacity(0.4))
            .padding(.vertical, 16)
            .frame(maxWidth: .infinity)
    }
}

struct DealDashboard: View {
    let trade: TradeOffer
    @Binding var isExpanded: Bool
    let currentUserId: UUID?
    var onCounter: () -> Void
    
    var iAmSender: Bool { trade.senderId == currentUserId }
    var myItems: [TradeItem] { iAmSender ? trade.allOfferedItems : trade.allWantedItems }
    var theirItems: [TradeItem] { iAmSender ? trade.allWantedItems : trade.allOfferedItems }
    
    var body: some View {
        VStack(spacing: 0) {
            Button(action: { withAnimation(.spring()) { isExpanded.toggle() } }) {
                HStack {
                    Text(isExpanded ? "Current Deal Details" : "Show Deal Details")
                        .font(.caption.bold())
                        .foregroundStyle(.white)
                    
                    Spacer()
                    
                    if !isExpanded {
                        Text("\(theirItems.count) for \(myItems.count)")
                            .font(.caption2.bold())
                            .foregroundStyle(.gray)
                    }
                    
                    Image(systemName: "chevron.down")
                        .font(.caption.bold())
                        .foregroundStyle(.white.opacity(0.3))
                        .rotationEffect(.degrees(isExpanded ? 180 : 0))
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .background(.ultraThinMaterial)
            }
            
            if isExpanded {
                VStack(spacing: 0) {
                    HStack(alignment: .top, spacing: 0) {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("YOU GET (\(theirItems.count))")
                                .font(.system(size: 9, weight: .black))
                                .foregroundStyle(.cyan)
                                .padding(.leading, 8)
                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack(spacing: 8) {
                                    ForEach(theirItems) { item in MiniItemPill(item: item) }
                                }
                                .padding(.horizontal, 8)
                            }
                        }
                        .frame(maxWidth: .infinity)
                        
                        Image(systemName: "arrow.left.arrow.right")
                            .foregroundStyle(.white.opacity(0.2))
                            .font(.title3)
                            .padding(.top, 24)
                        
                        VStack(alignment: .trailing, spacing: 8) {
                            Text("YOU GIVE (\(myItems.count))")
                                .font(.system(size: 9, weight: .black))
                                .foregroundStyle(.purple)
                                .padding(.trailing, 8)
                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack(spacing: 8) {
                                    ForEach(myItems) { item in MiniItemPill(item: item) }
                                }
                                .padding(.horizontal, 8)
                            }
                            .flipsForRightToLeftLayoutDirection(true)
                            .environment(\.layoutDirection, .rightToLeft)
                        }
                        .frame(maxWidth: .infinity)
                    }
                    .padding(.vertical, 16)
                    
                    if trade.status == .pending {
                        if trade.receiverId == currentUserId {
                            Button(action: onCounter) {
                                Text("Propose Counter Offer")
                                    .font(.caption.bold())
                                    .padding(.horizontal, 16)
                                    .padding(.vertical, 8)
                                    .background(Color.orange)
                                    .clipShape(Capsule())
                                    .foregroundStyle(.white)
                            }
                            .padding(.bottom, 12)
                        } else {
                            Text("Waiting for partner response...")
                                .font(.caption2)
                                .italic()
                                .foregroundStyle(.white.opacity(0.5))
                                .padding(.bottom, 12)
                        }
                    }
                }
                .background(Color.black.opacity(0.2))
                .overlay(Rectangle().frame(height: 1).foregroundStyle(Color.white.opacity(0.1)), alignment: .bottom)
            }
        }
        .background(.ultraThinMaterial)
    }
}

struct MiniItemPill: View {
    let item: TradeItem
    var body: some View {
        VStack(spacing: 4) {
            AsyncImageView(filename: item.imageUrl)
                .scaledToFill()
                .frame(width: 44, height: 44)
                .cornerRadius(10)
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white.opacity(0.2), lineWidth: 1))
            
            Text(item.title)
                .font(.system(size: 9, weight: .medium))
                .foregroundStyle(.white.opacity(0.8))
                .lineLimit(1)
                .frame(width: 44)
        }
    }
}

struct MessageBubble: View {
    let message: Message
    let isCurrentUser: Bool
    var isGroupedWithNext: Bool = false
    var isGroupedWithPrev: Bool = false
    var messageStatus: String? = nil
    var repliedMessage: Message? = nil
    
    var body: some View {
        HStack(alignment: .bottom, spacing: 8) {
            if isCurrentUser { Spacer() }
            
            VStack(alignment: isCurrentUser ? .trailing : .leading, spacing: 4) {
                if let imageUrl = message.imageUrl {
                    AsyncImageView(filename: imageUrl)
                        .scaledToFill()
                        .frame(width: 220, height: 220)
                        .clipShape(RoundedRectangle(cornerRadius: 18))
                        .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.white.opacity(0.2), lineWidth: 1))
                }
                
                if !message.content.isEmpty && message.content != "Sent an image" {
                    if message.content.contains("📍 Let's meet at") {
                        HStack(spacing: 12) {
                            Image(systemName: "map.fill").font(.title2).foregroundStyle(.green)
                            VStack(alignment: .leading, spacing: 2) {
                                Text("PROPOSED MEETUP").font(.system(size: 8, weight: .black)).foregroundStyle(.green)
                                Text(message.content.replacingOccurrences(of: "📍 ", with: "")).font(.subheadline).foregroundStyle(.white)
                            }
                        }
                        .padding(12)
                        .background(Color.black.opacity(0.4))
                        .cornerRadius(16)
                        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.green.opacity(0.5), lineWidth: 1))
                    } else {
                        VStack(alignment: isCurrentUser ? .trailing : .leading, spacing: 4) {
                            
                            if let reply = repliedMessage {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("Replying to")
                                        .font(.system(size: 10, weight: .bold))
                                        .foregroundStyle(isCurrentUser ? .black.opacity(0.5) : .white.opacity(0.5))
                                    Text(reply.content.isEmpty && reply.imageUrl != nil ? "📸 Image" : reply.content)
                                        .font(.caption)
                                        .lineLimit(1)
                                        .foregroundStyle(isCurrentUser ? .black.opacity(0.7) : .white.opacity(0.7))
                                }
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .frame(maxWidth: 200, alignment: .leading)
                                .background(isCurrentUser ? Color.black.opacity(0.1) : Color.black.opacity(0.2))
                                .cornerRadius(10)
                            }
                            
                            Text(message.content)
                                .font(.body)
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 10)
                        .background(isCurrentUser ? Color.cyan : Color.white.opacity(0.15))
                        .foregroundStyle(isCurrentUser ? .black : .white)
                        .clipShape(UnevenRoundedRectangle(
                            topLeadingRadius: (!isCurrentUser && isGroupedWithPrev) ? 4 : 18,
                            bottomLeadingRadius: (!isCurrentUser && isGroupedWithNext) ? 4 : (!isCurrentUser ? 2 : 18),
                            bottomTrailingRadius: (isCurrentUser && isGroupedWithNext) ? 4 : (isCurrentUser ? 2 : 18),
                            topTrailingRadius: (isCurrentUser && isGroupedWithPrev) ? 4 : 18
                        ))
                    }
                }
                
                if !isGroupedWithNext {
                    HStack(spacing: 4) {
                        Text(message.createdAt.formatted(.dateTime.hour().minute()))
                            .font(.caption2)
                            .foregroundStyle(.white.opacity(0.3))
                        
                        if let status = messageStatus {
                            Text("•")
                                .font(.caption2)
                                .foregroundStyle(.white.opacity(0.3))
                            Text(status)
                                .font(.caption2.bold())
                                .foregroundStyle(status == "Read" ? .cyan : .white.opacity(0.4))
                        }
                    }
                    .padding(.horizontal, 4)
                }
            }
            if !isCurrentUser { Spacer() }
        }
    }
}

struct TwoPhaseActionBubble: View {
    let message: Message
    let isMine: Bool
    let userConfirmed: Bool
    let partnerConfirmed: Bool
    let onConfirm: () -> Void
    
    var body: some View {
        HStack {
            if isMine { Spacer() }
            VStack(spacing: 12) {
                ZStack {
                    Circle().fill(iconGradient).frame(width: 44, height: 44)
                    Image(systemName: iconName).font(.system(size: 20)).foregroundStyle(.white)
                }
                .shadow(color: iconShadowColor, radius: 10)
                
                Text(statusTitle).font(.system(size: 14, weight: .bold)).multilineTextAlignment(.center).foregroundStyle(.white)
                Text(statusSubtitle).font(.caption).multilineTextAlignment(.center).foregroundStyle(.white.opacity(0.6))
                
                if !isMine && !userConfirmed {
                    Button(action: onConfirm) {
                        Text("Confirm Completion").font(.system(size: 14, weight: .bold)).foregroundStyle(.black).padding(.horizontal, 20).padding(.vertical, 10).background(Color.cyan).clipShape(Capsule())
                    }
                } else if userConfirmed && !partnerConfirmed {
                    HStack(spacing: 6) {
                        ProgressView().scaleEffect(0.7).tint(.orange)
                        Text("Waiting for partner...").font(.caption).foregroundStyle(.orange)
                    }
                } else if userConfirmed && partnerConfirmed {
                    HStack(spacing: 6) {
                        Image(systemName: "checkmark.circle.fill").foregroundStyle(.green)
                        Text("Trade completed!").font(.caption.bold()).foregroundStyle(.green)
                    }
                }
            }
            .padding(20)
            .background(.ultraThinMaterial)
            .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 24).stroke(LinearGradient(colors: [.white.opacity(0.4), .white.opacity(0.1)], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1))
            .padding(.horizontal, 40)
            if !isMine { Spacer() }
        }
        .padding(.vertical, 8)
    }
    
    var iconGradient: LinearGradient {
        if userConfirmed && partnerConfirmed { return LinearGradient(colors: [.green, .mint], startPoint: .topLeading, endPoint: .bottomTrailing) }
        else if partnerConfirmed && !userConfirmed { return LinearGradient(colors: [.cyan, .blue], startPoint: .topLeading, endPoint: .bottomTrailing) }
        else { return LinearGradient(colors: [.orange, .yellow], startPoint: .topLeading, endPoint: .bottomTrailing) }
    }
    
    var iconName: String {
        if userConfirmed && partnerConfirmed { return "checkmark.seal.fill" }
        else if userConfirmed { return "hourglass" }
        return "checkmark.seal.fill"
    }
    
    var iconShadowColor: Color {
        if userConfirmed && partnerConfirmed { return .green.opacity(0.5) }
        else if userConfirmed { return .orange.opacity(0.5) }
        return .cyan.opacity(0.5)
    }
    
    var statusTitle: String {
        if userConfirmed && partnerConfirmed { return "🎉 Trade Complete!" }
        else if isMine { return userConfirmed ? "You confirmed completion" : "You requested completion" }
        else { return partnerConfirmed ? "Partner confirmed completion" : "Partner wants to complete" }
    }
    
    var statusSubtitle: String {
        if userConfirmed && partnerConfirmed { return "Both parties have confirmed the exchange" }
        else if userConfirmed && !partnerConfirmed { return "Waiting for your partner to confirm" }
        else if partnerConfirmed && !userConfirmed { return "Confirm when you've received your item" }
        return "Both parties must confirm to complete"
    }
}

struct TradeCompletionOverlay: View {
    let onDismiss: () -> Void
    var body: some View {
        ZStack {
            Color.black.opacity(0.8).ignoresSafeArea()
            VStack(spacing: 24) {
                ZStack {
                    Circle().fill(Color.green).frame(width: 100, height: 100).blur(radius: 20).opacity(0.5)
                    Image(systemName: "checkmark.seal.fill").font(.system(size: 80)).foregroundStyle(LinearGradient(colors: [.green, .mint], startPoint: .top, endPoint: .bottom)).shadow(color: .green.opacity(0.5), radius: 20)
                }
                .scaleEffect(1.0)
                .animation(.spring(response: 0.5, dampingFraction: 0.5).repeatCount(1, autoreverses: true), value: true)
                
                VStack(spacing: 8) {
                    Text("Trade Complete!").font(.system(size: 32, weight: .heavy, design: .default)).foregroundStyle(.white)
                    Text("The item has been exchanged successfully.").font(.body).foregroundStyle(.white.opacity(0.7)).multilineTextAlignment(.center)
                }
                
                Button(action: onDismiss) {
                    Text("Rate Partner").font(.headline).foregroundStyle(.black).frame(maxWidth: .infinity).frame(height: 56).background(Color.white).clipShape(Capsule())
                }
                .padding(.horizontal, 40).padding(.top, 20)
            }
        }
    }
}

struct SafeSpotItem: Identifiable {
    let id = UUID()
    let item: MKMapItem
}

struct SafeMeetingPointView: View {
    let locationA: CLLocationCoordinate2D
    let locationB: CLLocationCoordinate2D
    var onSendLocation: (String, CLLocationCoordinate2D) -> Void
    
    @Environment(\.dismiss) var dismiss
    @StateObject private var locationManager = LocationManager.shared
    
    @State private var safeSpots: [SafeSpotItem] = []
    @State private var selectedSpot: SafeSpotItem?
    @State private var region: MKCoordinateRegion
    @State private var isSearching = false
    
    init(locationA: CLLocationCoordinate2D, locationB: CLLocationCoordinate2D, onSendLocation: @escaping (String, CLLocationCoordinate2D) -> Void) {
        self.locationA = locationA
        self.locationB = locationB
        self.onSendLocation = onSendLocation
        
        let center = CLLocationCoordinate2D(latitude: (locationA.latitude + locationB.latitude) / 2, longitude: (locationA.longitude + locationB.longitude) / 2)
        _region = State(initialValue: MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)))
    }
    
    var body: some View {
        NavigationStack {
            ZStack(alignment: .bottom) {
                Map(coordinateRegion: $region, showsUserLocation: true, annotationItems: safeSpots) { spot in
                    MapAnnotation(coordinate: spot.item.placemark.coordinate) {
                        Image(systemName: "shield.fill")
                            .font(.title)
                            .foregroundStyle(selectedSpot?.id == spot.id ? .white : .green)
                            .background(Circle().fill(selectedSpot?.id == spot.id ? Color.green : Color.black).frame(width: 44, height: 44))
                            .shadow(radius: 4)
                            .scaleEffect(selectedSpot?.id == spot.id ? 1.2 : 1.0)
                            .animation(.spring(), value: selectedSpot?.id)
                            .onTapGesture {
                                selectedSpot = spot
                            }
                    }
                }
                .ignoresSafeArea()
                
                VStack {
                    HStack {
                        Spacer()
                        Button(action: centerOnUser) {
                            Image(systemName: "location.fill")
                                .padding()
                                .background(.ultraThinMaterial)
                                .clipShape(Circle())
                                .shadow(radius: 4)
                                .foregroundStyle(.cyan)
                        }
                        .padding(.trailing, 16)
                        .padding(.top, 16)
                    }
                    Spacer()
                }
                
                if let selected = selectedSpot {
                    VStack(spacing: 16) {
                        HStack {
                            ZStack {
                                Circle().fill(Color.green.opacity(0.2)).frame(width: 44, height: 44)
                                Image(systemName: "shield.lefthalf.filled").foregroundStyle(.green)
                            }
                            VStack(alignment: .leading) {
                                Text(selected.item.name ?? "Safe Spot")
                                    .font(.headline)
                                    .foregroundStyle(.white)
                                Text(selected.item.placemark.title ?? "Public Location")
                                    .font(.caption)
                                    .foregroundStyle(.white.opacity(0.6))
                            }
                            Spacer()
                        }
                        
                        Button(action: {
                            onSendLocation(selected.item.name ?? "Safe Spot", selected.item.placemark.coordinate)
                        }) {
                            Text("Send Location")
                                .font(.headline)
                                .padding()
                                .frame(maxWidth: .infinity)
                                .background(Color.cyan)
                                .foregroundColor(.black)
                                .clipShape(Capsule())
                        }
                    }
                    .padding(20)
                    .background(LiquidBackground().opacity(0.95))
                    .cornerRadius(24)
                    .padding(.horizontal, 16)
                    .padding(.bottom, 20)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                } else if isSearching {
                    ProgressView()
                        .padding(20)
                        .background(.ultraThinMaterial)
                        .clipShape(Circle())
                        .padding(.bottom, 40)
                }
            }
            .navigationTitle("Suggest Safe Spot")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") { dismiss() }
                }
            }
            .onAppear {
                locationManager.requestPermission()
                if locationA.latitude == 43.6532, let userLoc = locationManager.userLocation {
                    region = MKCoordinateRegion(center: userLoc.coordinate, span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05))
                }
                findSafeSpots()
            }
        }
    }
    
    func centerOnUser() {
        if let userLoc = locationManager.userLocation {
            withAnimation {
                region = MKCoordinateRegion(center: userLoc.coordinate, span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05))
            }
            findSafeSpots()
        }
    }
    
    func findSafeSpots() {
        isSearching = true
        let queries = ["Police Station", "Fire Station", "Bank", "Library"]
        var newSpots: [SafeSpotItem] = []
        
        Task {
            for query in queries {
                let req = MKLocalSearch.Request()
                req.naturalLanguageQuery = query
                req.region = region
                if let response = try? await MKLocalSearch(request: req).start() {
                    let spots = response.mapItems.map { SafeSpotItem(item: $0) }
                    newSpots.append(contentsOf: spots)
                }
            }
            
            await MainActor.run {
                self.safeSpots = Array(newSpots.prefix(10))
                self.isSearching = false
            }
        }
    }
}

struct ChatSheetModifier: ViewModifier {
    @Binding var isPresented: Bool
    enum SheetType { case premium }
    let sheetType: SheetType
    
    func body(content: Content) -> some View {
        content.sheet(isPresented: $isPresented) {
            PremiumUpgradeSheet()
                .presentationDetents([.fraction(0.6)])
                .presentationDragIndicator(.visible)
        }
    }
}
