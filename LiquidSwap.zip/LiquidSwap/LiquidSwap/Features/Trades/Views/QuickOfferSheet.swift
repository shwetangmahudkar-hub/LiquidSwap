import SwiftUI
import Supabase

struct QuickOfferSheet: View {
    // The item you are interested in (Target)
    let wantedItem: TradeItem
    
    @Environment(\.dismiss) var dismiss
    @ObservedObject var userManager = UserManager.shared
    @ObservedObject var tradeManager = TradeManager.shared
    
    // Selection State
    @State private var selectedItemId: UUID?
    @State private var isSending = false
    @State private var showSuccess = false
    
    // Add Item Sheet State
    @State private var showAddItemSheet = false
    
    // ✨ FIX: Computed Property for Instant Updates
    // This ensures that as soon as AddItemView adds an item to UserManager, it appears here.
    var availableItems: [TradeItem] {
        let busy = busyItemIds
        return userManager.userItems.filter { !busy.contains($0.id) }
    }
    
    // Calculate items that are already in pending/accepted trades
    var busyItemIds: Set<UUID> {
        guard let myId = userManager.currentUser?.id else { return [] }
        var ids = Set<UUID>()
        
        for trade in tradeManager.activeTrades {
            if trade.status.isCommitted {
                if trade.senderId == myId {
                    ids.insert(trade.offeredItemId)
                    trade.additionalOfferedItemIds.forEach { ids.insert($0) }
                }
                if trade.receiverId == myId {
                    ids.insert(trade.wantedItemId)
                }
            }
        }
        return ids
    }
    
    var body: some View {
        ZStack {
            // 1. Global Background
            LiquidBackground()
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // 2. Standardized Header (Action in Top Right)
                HStack {
                    Text("Make an Offer")
                        .font(.system(size: 24, weight: .heavy, design: .rounded))
                        .foregroundStyle(.white)
                    
                    Spacer()
                    
                    if isSending {
                        ProgressView()
                            .tint(.cyan)
                    } else {
                        Button("Send") {
                            sendOffer()
                        }
                        .font(.headline.bold())
                        .foregroundStyle(.cyan)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 8)
                        .background(Color.cyan.opacity(0.1))
                        .clipShape(Capsule())
                        .disabled(selectedItemId == nil)
                        .opacity(selectedItemId == nil ? 0.5 : 1)
                    }
                }
                .padding(.horizontal, 24)
                .padding(.top, 24)
                .padding(.bottom, 16)
                
                // 3. Context (Target Item)
                HStack(spacing: 12) {
                    Text("Trading for:")
                        .font(.subheadline)
                        .foregroundStyle(.white.opacity(0.6))
                    
                    AsyncImageView(filename: wantedItem.imageUrl)
                        .scaledToFill()
                        .frame(width: 32, height: 32)
                        .clipShape(RoundedRectangle(cornerRadius: 6))
                        .overlay(
                            RoundedRectangle(cornerRadius: 6)
                                .stroke(Color.white.opacity(0.2), lineWidth: 1)
                        )
                    
                    Text(wantedItem.title)
                        .font(.subheadline.bold())
                        .foregroundStyle(.white)
                        .lineLimit(1)
                    
                    Spacer()
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 20)
                
                // 4. Inventory Grid
                ScrollView(showsIndicators: false) {
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 16) {
                        
                        // "Add New Item" Card
                        Button(action: {
                            Haptics.shared.playMedium()
                            showAddItemSheet = true
                        }) {
                            AddItemCard()
                        }
                        
                        // My Items (Uses Shared Component)
                        ForEach(availableItems) { item in
                            InventoryItemCard(item: item, isSelected: selectedItemId == item.id)
                                .onTapGesture {
                                    Haptics.shared.playLight()
                                    if selectedItemId == item.id {
                                        selectedItemId = nil
                                    } else {
                                        selectedItemId = item.id
                                    }
                                }
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 40)
                }
            }
            
            // 5. Success Overlay
            if showSuccess {
                Color.black.opacity(0.6).ignoresSafeArea()
                VStack(spacing: 20) {
                    // ✨ FIX: Removed iOS 17 .symbolEffect(.bounce)
                    // Replaced with standard Image and scale transition
                    Image(systemName: "checkmark.circle.fill")
                        .font(.system(size: 60))
                        .foregroundStyle(.green)
                    
                    Text("Offer Sent!")
                        .font(.title2.bold())
                        .foregroundStyle(.white)
                }
                .transition(.scale.combined(with: .opacity))
                .zIndex(100)
            }
        }
        .presentationDetents([.large])
        .presentationDragIndicator(.visible)
        .sheet(isPresented: $showAddItemSheet) {
            AddItemView(isPresented: $showAddItemSheet)
        }
    }
    
    // MARK: - Logic
    
    func sendOffer() {
        guard let itemId = selectedItemId else { return }
        
        // ✨ FIX: Find the full object from the local array
        guard let offeredItem = availableItems.first(where: { $0.id == itemId }) else { return }
        
        isSending = true
        
        Task {
            // ✨ FIX: Use correct TradeManager method signature
            let result = await tradeManager.sendMultiItemOfferWithResult(
                wantedItems: [wantedItem],
                offeredItems: [offeredItem]
            )
            
            await MainActor.run {
                isSending = false
                
                if case .success = result {
                    Haptics.shared.playSuccess()
                    withAnimation {
                        showSuccess = true
                    }
                    
                    // Close after delay
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                        dismiss()
                    }
                } else {
                    Haptics.shared.playError()
                    print("Error sending offer: \(result)")
                }
            }
        }
    }
}

// MARK: - Local Component (Add Item Card)

struct AddItemCard: View {
    var body: some View {
        VStack(spacing: 12) {
            Spacer()
            
            // Plus Icon with Glow
            ZStack {
                Circle()
                    .fill(Color.cyan.opacity(0.15))
                    .frame(width: 50, height: 50)
                
                Image(systemName: "plus")
                    .font(.system(size: 24, weight: .bold))
                    .foregroundStyle(.cyan)
            }
            
            Text("Add Item")
                .font(.system(size: 12, weight: .bold))
                .foregroundStyle(.white.opacity(0.7))
            
            Spacer()
        }
        .frame(maxWidth: .infinity)
        .frame(height: 160)
        .background(.ultraThinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .stroke(
                    LinearGradient(
                        colors: [.cyan.opacity(0.5), .cyan.opacity(0.1)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ),
                    lineWidth: 1.5
                )
        )
        .overlay(
            // Dashed Inner Border
            RoundedRectangle(cornerRadius: 16)
                .strokeBorder(style: StrokeStyle(lineWidth: 1.5, dash: [6, 4]))
                .foregroundStyle(.cyan.opacity(0.3))
                .padding(8)
        )
    }
}
