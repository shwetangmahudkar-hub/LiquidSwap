import SwiftUI

struct TradeBuilderView: View {
    @Environment(\.dismiss) var dismiss
    @Environment(\.colorScheme) private var colorScheme
    @ObservedObject var userManager = UserManager.shared
    @ObservedObject var tradeManager = TradeManager.shared
    
    // The partner we are trading with
    let partner: UserProfile
    
    // Available Inventories
    @State private var myInventory: [TradeItem] = []
    @State private var theirInventory: [TradeItem] = []
    
    // THE DEAL POT (Selection State)
    @State private var selectedMyIDs: Set<UUID> = []
    @State private var selectedTheirIDs: Set<UUID> = []
    
    // UI State
    @State private var activeTab: DealSide = .theirs
    @State private var isLoading = true
    @State private var showConfirmAlert = false
    
    enum DealSide: String, CaseIterable {
        case theirs = "Their Items"
        case mine = "My Items"
    }
    
    var body: some View {
        NavigationStack {
            ZStack(alignment: .bottom) {
                // 1. Global Background (Standardization Rule)
                LiquidBackground().ignoresSafeArea()
                
                VStack(spacing: 0) {
                    // 2. Standardized Header
                    headerView
                    
                    // 3. Tab Switcher
                    tabSwitcher
                    
                    // 4. Grid Content
                    if isLoading {
                        Spacer()
                        ProgressView().tint(.white)
                        Spacer()
                    } else {
                        inventoryGrid
                    }
                }
                .padding(.bottom, 160) // Extra padding for the Deal Pot
                
                // 5. THE DEAL POT (Floating Glass Sheet)
                dealPotView
            }
            .navigationBarHidden(true)
            .onAppear {
                loadInventories()
            }
            .alert("Confirm Offer", isPresented: $showConfirmAlert) {
                Button("Send Offer", role: .none) { submitTrade() }
                Button("Cancel", role: .cancel) { }
            } message: {
                Text("You are offering \(selectedMyIDs.count) item(s) for \(selectedTheirIDs.count) of theirs.")
            }
        }
    }
    
    // MARK: - Views
    
    private var headerView: some View {
        HStack {
            // Standard Back Button (Matches ChatRoomView)
            Button(action: { dismiss() }) {
                GlassNavButton(icon: "xmark")
            }
            
            Spacer()
            
            // Standard Page Title (Matches SettingsView)
            Text("Build Trade")
                .font(.system(size: 24, weight: .heavy, design: .rounded))
                .foregroundStyle(.white)
            
            Spacer()
            
            // Placeholder for alignment
            Color.clear.frame(width: 44, height: 44)
        }
        .padding(.horizontal, 24)
        .padding(.top, 24)
        .padding(.bottom, 16)
    }
    
    private var tabSwitcher: some View {
        HStack(spacing: 0) {
            ForEach(DealSide.allCases, id: \.self) { side in
                Button(action: {
                    Haptics.shared.playLight()
                    withAnimation(.spring(response: 0.3)) { activeTab = side }
                }) {
                    VStack(spacing: 12) {
                        Text(side.rawValue)
                            .font(.subheadline.weight(.bold))
                            .foregroundStyle(activeTab == side ? .white : .white.opacity(0.5))
                        
                        // Active Indicator
                        Capsule()
                            .fill(activeTab == side ? Color.cyan : Color.white.opacity(0.1))
                            .frame(height: 3)
                    }
                }
                .frame(maxWidth: .infinity)
            }
        }
        .padding(.top, 10)
        .background(Color.black.opacity(0.2))
    }
    
    private var inventoryGrid: some View {
        ScrollView {
            let items = activeTab == .mine ? myInventory : theirInventory
            let selection = activeTab == .mine ? selectedMyIDs : selectedTheirIDs
            
            if items.isEmpty {
                VStack(spacing: 16) {
                    Spacer(minLength: 80)
                    Image(systemName: "archivebox.fill")
                        .font(.system(size: 60))
                        .foregroundStyle(.white.opacity(0.1))
                    Text("No items found")
                        .font(.headline)
                        .foregroundStyle(.white.opacity(0.5))
                }
                .frame(maxWidth: .infinity)
            } else {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 150), spacing: 16)], spacing: 16) {
                    ForEach(items) { item in
                        // ✨ REUSE: Shared Component (Matches SettingsView/InventoryView style)
                        InventoryItemCard(item: item, isSelected: selection.contains(item.id))
                            .onTapGesture {
                                toggleSelection(item: item)
                            }
                    }
                }
                .padding(20)
            }
        }
    }
    
    private var dealPotView: some View {
        // ✨ Standardized Container: GlassCard
        GlassCard {
            VStack(spacing: 16) {
                // Visual Summary
                HStack(spacing: 20) {
                    // Their Side
                    dealSideSummary(title: "THEIRS", count: selectedTheirIDs.count, inventory: theirInventory, ids: selectedTheirIDs)
                    
                    Image(systemName: "arrow.left.arrow.right")
                        .font(.title2.bold())
                        .foregroundStyle(.cyan)
                    
                    // My Side
                    dealSideSummary(title: "YOURS", count: selectedMyIDs.count, inventory: myInventory, ids: selectedMyIDs)
                }
                .padding(.vertical, 8)
                
                // Action Button
                Button(action: {
                    Haptics.shared.playMedium()
                    showConfirmAlert = true
                }) {
                    Text("Send Offer")
                        .font(.headline.bold())
                        .foregroundStyle(.black)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(isValidOffer ? Color.cyan : Color.white.opacity(0.2))
                        .clipShape(Capsule())
                }
                .disabled(!isValidOffer)
                .opacity(isValidOffer ? 1 : 0.6)
            }
            .padding(4)
        }
        .padding(.horizontal, 16)
        .padding(.bottom, 20)
    }
    
    private func dealSideSummary(title: String, count: Int, inventory: [TradeItem], ids: Set<UUID>) -> some View {
        VStack(spacing: 8) {
            Text(title)
                .font(.caption.bold())
                .foregroundStyle(.white.opacity(0.5))
            
            HStack(spacing: -12) {
                if ids.isEmpty {
                    Circle()
                        .strokeBorder(Color.white.opacity(0.2), lineWidth: 1)
                        .background(Circle().fill(Color.white.opacity(0.05)))
                        .frame(width: 44, height: 44)
                        .overlay(Image(systemName: "plus").font(.caption).foregroundStyle(.white.opacity(0.3)))
                } else {
                    ForEach(Array(ids.prefix(3)), id: \.self) { id in
                        if let item = inventory.first(where: { $0.id == id }) {
                            AsyncImageView(filename: item.imageUrl)
                                .scaledToFill()
                                .frame(width: 44, height: 44)
                                .clipShape(Circle())
                                .overlay(Circle().stroke(Color.black.opacity(0.5), lineWidth: 2))
                        }
                    }
                    if count > 3 {
                        Circle().fill(Color.gray).frame(width: 44, height: 44)
                            .overlay(Text("+\(count - 3)").font(.caption.bold()).foregroundStyle(.white))
                            .overlay(Circle().stroke(Color.black.opacity(0.5), lineWidth: 2))
                    }
                }
            }
        }
        .frame(maxWidth: .infinity)
    }
    
    // MARK: - Logic
    
    var isValidOffer: Bool {
        !selectedMyIDs.isEmpty && !selectedTheirIDs.isEmpty
    }
    
    func toggleSelection(item: TradeItem) {
        Haptics.shared.playLight()
        if activeTab == .mine {
            if selectedMyIDs.contains(item.id) {
                selectedMyIDs.remove(item.id)
            } else {
                selectedMyIDs.insert(item.id)
            }
        } else {
            if selectedTheirIDs.contains(item.id) {
                selectedTheirIDs.remove(item.id)
            } else {
                selectedTheirIDs.insert(item.id)
            }
        }
    }
    
    func loadInventories() {
        Task {
            // My Inventory
            if let myId = userManager.currentUser?.id {
                let myItems = try? await DatabaseService.shared.fetchUserItems(userId: myId)
                await MainActor.run { self.myInventory = myItems ?? [] }
            }
            
            // Their Inventory
            let theirItems = try? await DatabaseService.shared.fetchUserItems(userId: partner.id)
            await MainActor.run {
                self.theirInventory = theirItems ?? []
                self.isLoading = false
            }
        }
    }
    
    func submitTrade() {
        Task {
            let myItems = myInventory.filter { selectedMyIDs.contains($0.id) }
            let theirItems = theirInventory.filter { selectedTheirIDs.contains($0.id) }
            
            let result = await tradeManager.sendMultiItemOfferWithResult(wantedItems: theirItems, offeredItems: myItems)
            
            await MainActor.run {
                switch result {
                case .success:
                    Haptics.shared.playSuccess()
                    dismiss()
                case .rateLimited(let msg):
                    tradeManager.rateLimitMessage = msg
                    tradeManager.showRateLimitAlert = true
                case .itemsBusy:
                    print("Items busy")
                default:
                    print("Error sending trade")
                }
            }
        }
    }
}
