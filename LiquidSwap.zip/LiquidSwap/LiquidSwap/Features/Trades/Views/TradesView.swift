import SwiftUI

struct TradesView: View {
    @Environment(\.colorScheme) private var colorScheme
    @ObservedObject var tradeManager = TradeManager.shared
    @ObservedObject var userManager = UserManager.shared
    @ObservedObject var tabManager = TabBarManager.shared // ✨ ADDED: Dependency for dynamic padding
    
    // Filter State
    enum TradeFilter: String, CaseIterable {
        case incoming = "Incoming"
        case sent = "Sent"
    }
    @State private var selectedFilter: TradeFilter = .incoming
    
    // Sheet State
    @State private var selectedItemForOffer: TradeItem?
    @State private var selectedItemForDetail: TradeItem?
    @State private var selectedProfileSheet: TradeProfileSheetWrapper?
    @State private var selectedOfferForCounter: TradeOffer?
    
    // Navigation State (For Auto-Redirect)
    @State private var navigateToChatTrade: TradeOffer?
    
    // Cancel Offer Confirmation
    @State private var offerToCancel: TradeOffer?
    @State private var showCancelConfirmation = false
    
    // MARK: - Adaptive Colors
    private var primaryText: Color {
        colorScheme == .dark ? .white : .black
    }
    
    private var secondaryText: Color {
        colorScheme == .dark ? .white.opacity(0.5) : .black.opacity(0.5)
    }
    
    // Computed Property for Sent Offers
    var sentOffers: [TradeOffer] {
        guard let myId = userManager.currentUser?.id else { return [] }
        return tradeManager.activeTrades.filter { trade in
            trade.senderId == myId && trade.status == .pending
        }
    }
    
    var body: some View {
        NavigationStack {
            if #available(iOS 17.0, *) {
                ZStack(alignment: .bottom) { // ✨ Changed to Bottom Alignment for Pill
                    // Global Background
                    LiquidBackground()
                        .ignoresSafeArea()
                    
                    // Main Content
                    ScrollView {
                        VStack(spacing: 16) {
                            // List Content based on Filter
                            LazyVStack(spacing: 12) {
                                switch selectedFilter {
                                case .incoming:
                                    incomingOffersList
                                case .sent:
                                    sentOffersList
                                }
                            }
                            .padding(.top, 20) // ✨ Added top space since header is gone
                            .padding(.bottom, 120) // ✨ Bottom space for Pill + Tab Bar
                        }
                        .padding(.horizontal, 12)
                    }
                    .refreshable {
                        await tradeManager.loadTradesData()
                    }
                    
                    // ✨ FLOATING PILL (Bottom)
                    floatingPill
                        .padding(.bottom, tabManager.isVisible ? 100 : 16) // Dynamic Padding
                        .animation(.spring(response: 0.5, dampingFraction: 0.8), value: tabManager.isVisible)
                }
                // Auto-Navigation to Chat Room
                .navigationDestination(item: $navigateToChatTrade) { trade in
                    ChatRoomView(trade: trade)
                }
                .onAppear {
                    Task { await tradeManager.loadTradesData() }
                }
                // Quick Offer Sheet
                .sheet(item: $selectedItemForOffer) { item in
                    QuickOfferSheet(wantedItem: item)
                        .presentationDetents([.medium, .large])
                        .presentationDragIndicator(.visible)
                }
                // Product Detail Sheet
                .sheet(item: $selectedItemForDetail) { item in
                    NavigationStack {
                        ProductDetailView(item: item)
                    }
                    .presentationDetents([.large])
                    .presentationDragIndicator(.visible)
                }
                // Profile Sheet using Wrapper
                .sheet(item: $selectedProfileSheet) { wrapper in
                    NavigationStack {
                        PublicProfileView(userId: wrapper.id)
                    }
                    .presentationDetents([.large])
                    .presentationDragIndicator(.visible)
                }
                // Counter Offer Sheet
                .sheet(item: $selectedOfferForCounter) { offer in
                    CounterOfferSheet(originalTrade: offer)
                        .presentationDetents([.medium, .large])
                        .presentationDragIndicator(.visible)
                }
                // Cancel Offer Alert
                .alert("Cancel Offer?", isPresented: $showCancelConfirmation) {
                    Button("Keep Offer", role: .cancel) { }
                    Button("Cancel Offer", role: .destructive) {
                        if let offer = offerToCancel {
                            cancelSentOffer(offer)
                        }
                    }
                } message: {
                    Text("This will remove the offer permanently.")
                }
            } else {
                EmptyView()
            }
        }
    }
    
    // MARK: - ✨ New Floating Pill View
    
    private var floatingPill: some View {
        HStack(spacing: 10) {
            // Title Section (Left)
            HStack(spacing: 6) {
                Image(systemName: "arrow.triangle.2.circlepath")
                    .font(.subheadline.bold())
                    .foregroundStyle(.cyan)
                
                Text("Trades")
                    .font(.subheadline.bold())
                    .foregroundStyle(.white)
            }
            
            Spacer()
            
            // Divider
            Rectangle()
                .fill(Color.white.opacity(0.2))
                .frame(width: 1, height: 18)
            
            // Toggle Chips (Right)
            HStack(spacing: 4) {
                TradeFilterChip(
                    title: "Incoming",
                    icon: "tray.and.arrow.down.fill",
                    isSelected: selectedFilter == .incoming
                ) {
                    withAnimation { selectedFilter = .incoming }
                }
                
                TradeFilterChip(
                    title: "Sent",
                    icon: "paperplane.fill",
                    isSelected: selectedFilter == .sent
                ) {
                    withAnimation { selectedFilter = .sent }
                }
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(.ultraThinMaterial)
        .clipShape(Capsule())
        // Floating Shadow
        .shadow(color: .black.opacity(0.25), radius: 8, y: 4)
        .overlay(Capsule().stroke(Color.white.opacity(0.1), lineWidth: 1))
        .padding(.horizontal, 16)
    }
    
    // MARK: - List Views
    
    private var incomingOffersList: some View {
        Group {
            if tradeManager.incomingOffers.isEmpty && !tradeManager.isLoading {
                GlassEmptyState(
                    icon: "tray",
                    message: "No incoming offers",
                    subtitle: "When someone wants to trade with you, it'll appear here."
                )
            } else {
                ForEach(tradeManager.incomingOffers) { offer in
                    OfferCard(
                        offer: offer,
                        onViewProfile: {
                            selectedProfileSheet = TradeProfileSheetWrapper(id: offer.senderId)
                        },
                        onCounter: { selectedOfferForCounter = offer }
                    )
                    .contextMenu {
                        Button {
                            handleOfferResponse(offer: offer, accept: true)
                        } label: {
                            Label("Accept Offer", systemImage: "checkmark.circle.fill")
                        }
                        Button {
                            selectedOfferForCounter = offer
                        } label: {
                            Label("Counter Offer", systemImage: "arrow.triangle.2.circlepath")
                        }
                        Button {
                            selectedProfileSheet = TradeProfileSheetWrapper(id: offer.senderId)
                        } label: {
                            Label("View Sender Profile", systemImage: "person.circle")
                        }
                    }
                }
            }
        }
    }
    
    private var sentOffersList: some View {
        Group {
            if sentOffers.isEmpty && !tradeManager.isLoading {
                GlassEmptyState(
                    icon: "paperplane",
                    message: "No sent offers",
                    subtitle: "Offers you make will appear here until accepted."
                )
            } else {
                ForEach(sentOffers) { offer in
                    SentOfferCard(
                        offer: offer,
                        onCancel: {
                            offerToCancel = offer
                            showCancelConfirmation = true
                        }
                    )
                }
            }
        }
    }
    
    // MARK: - Actions
    
    private func handleOfferResponse(offer: TradeOffer, accept: Bool) {
        Task {
            let success = await tradeManager.respondToOffer(offer: offer, accept: accept)
            
            if accept && success {
                Haptics.shared.playSuccess()
                
                var acceptedTrade = offer
                acceptedTrade.status = .accepted
                
                try? await Task.sleep(nanoseconds: 500_000_000)
                
                await MainActor.run {
                    navigateToChatTrade = acceptedTrade
                }
            }
        }
    }
    
    private func cancelSentOffer(_ offer: TradeOffer) {
        Task {
            try? await DatabaseService.shared.updateTradeStatus(tradeId: offer.id, status: TradeStatus.cancelled.rawValue)
            Haptics.shared.playMedium()
            await tradeManager.loadTradesData()
        }
    }
}

// MARK: - Helper Components

struct GlassEmptyState: View {
    @Environment(\.colorScheme) private var colorScheme
    
    let icon: String
    let message: String
    let subtitle: String
    
    private var primaryText: Color {
        colorScheme == .dark ? .white : .black
    }
    
    private var secondaryText: Color {
        colorScheme == .dark ? .white.opacity(0.5) : .black.opacity(0.5)
    }
    
    var body: some View {
        VStack(spacing: 16) {
            ZStack {
                Circle()
                    .fill(Color.cyan.opacity(0.1))
                    .frame(width: 80, height: 80)
                Image(systemName: icon)
                    .font(.system(size: 32))
                    .foregroundStyle(.cyan.opacity(0.6))
            }
            VStack(spacing: 6) {
                Text(message)
                    .appFont(16, weight: .bold)
                    .foregroundStyle(primaryText)
                Text(subtitle)
                    .appFont(13)
                    .foregroundStyle(secondaryText)
                    .multilineTextAlignment(.center)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 60)
    }
}

// ✨ Helper Chip (Local to this View)
struct TradeFilterChip: View {
    let title: String
    let icon: String
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 4) {
                Image(systemName: icon)
                Text(title)
            }
            .font(.caption2.bold())
            .padding(.vertical, 6)
            .padding(.horizontal, 10)
            .background(isSelected ? Color.cyan : Color.white.opacity(0.1))
            .foregroundStyle(isSelected ? .black : .white)
            .clipShape(Capsule())
        }
    }
}

// MARK: - Offer Card

struct OfferCard: View {
    @Environment(\.colorScheme) private var colorScheme
    
    let offer: TradeOffer
    let onViewProfile: () -> Void
    let onCounter: () -> Void
    
    @State private var isProcessing = false
    
    private var primaryText: Color {
        colorScheme == .dark ? .white : .black
    }
    
    private var secondaryText: Color {
        colorScheme == .dark ? .white.opacity(0.5) : .black.opacity(0.5)
    }
    
    var body: some View {
        VStack(spacing: 14) {
            // Header
            HStack(spacing: 10) {
                Circle()
                    .fill(Color.cyan.opacity(0.15))
                    .frame(width: 36, height: 36)
                    .overlay(Image(systemName: "arrow.down.circle.fill").font(.system(size: 16)).foregroundStyle(.cyan))
                
                VStack(alignment: .leading, spacing: 2) {
                    Text("New Offer")
                        .appFont(14, weight: .bold)
                        .foregroundStyle(primaryText)
                    Text(timeAgoString(from: offer.createdAt))
                        .appFont(11)
                        .foregroundStyle(secondaryText)
                }
                
                Spacer()
                
                Button(action: onViewProfile) {
                    HStack(spacing: 4) {
                        Image(systemName: "person.circle.fill")
                            .font(.system(size: 14))
                        Text("Profile")
                            .appFont(11, weight: .bold)
                    }
                    .foregroundStyle(.cyan)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(Color.cyan.opacity(0.15))
                    .clipShape(Capsule())
                }
            }
            
            // Items
            HStack(spacing: 10) {
                itemVisual(item: offer.offeredItem, label: "THEY OFFER", borderColor: .cyan)
                VStack(spacing: 4) {
                    Image(systemName: "arrow.left.arrow.right")
                        .font(.system(size: 16, weight: .bold))
                        .foregroundStyle(colorScheme == .dark ? .white.opacity(0.3) : .black.opacity(0.3))
                }
                itemVisual(item: offer.wantedItem, label: "FOR YOUR", borderColor: .orange)
            }
            
            Divider().background(Color.white.opacity(0.1))
            
            // Actions
            HStack(spacing: 12) {
                Button(action: onCounter) {
                    HStack(spacing: 5) {
                        Image(systemName: "arrow.triangle.2.circlepath").font(.system(size: 12))
                        Text("Counter").appFont(13, weight: .bold)
                    }
                    .foregroundStyle(.cyan).frame(maxWidth: .infinity).padding(.vertical, 12)
                        .background(.ultraThinMaterial).cornerRadius(12)
                        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.white.opacity(0.2), lineWidth: 1))
                }
                .disabled(isProcessing)
                
                Button(action: { handleResponse(accept: false) }) {
                    HStack(spacing: 5) {
                        if isProcessing { ProgressView().tint(primaryText) } else {
                            Image(systemName: "xmark").font(.system(size: 12, weight: .bold))
                            Text("Decline").appFont(13, weight: .bold)
                        }
                    }
                    .foregroundStyle(primaryText).frame(maxWidth: .infinity).padding(.vertical, 12)
                        .background(.ultraThinMaterial).cornerRadius(12)
                        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.white.opacity(0.2), lineWidth: 1))
                }
                .disabled(isProcessing)
                
                Button(action: { handleResponse(accept: true) }) {
                    HStack(spacing: 5) {
                        if isProcessing { ProgressView().tint(.black) } else {
                            Image(systemName: "checkmark").font(.system(size: 12, weight: .bold))
                            Text("Accept").appFont(13, weight: .bold)
                        }
                    }
                    .foregroundStyle(.black).frame(maxWidth: .infinity).padding(.vertical, 12)
                    .background(Color.cyan).cornerRadius(12)
                }
                .disabled(isProcessing)
            }
        }
        .padding(16)
        .background(.ultraThinMaterial)
        .cornerRadius(20)
        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white.opacity(0.1), lineWidth: 1))
        .shadow(color: .black.opacity(0.15), radius: 8, y: 4)
    }
    
    func itemVisual(item: TradeItem?, label: String, borderColor: Color) -> some View {
        VStack(spacing: 6) {
            Text(label).appFont(8, weight: .black).foregroundStyle(borderColor.opacity(0.8))
            AsyncImageView(filename: item?.imageUrl)
                .frame(width: 60, height: 60).cornerRadius(14)
                .overlay(RoundedRectangle(cornerRadius: 14).stroke(borderColor.opacity(0.4), lineWidth: 2))
            Text(item?.title ?? "Unknown").appFont(11, weight: .bold).lineLimit(1).foregroundStyle(primaryText)
        }
        .frame(maxWidth: .infinity)
    }
    
    func handleResponse(accept: Bool) {
        isProcessing = true
        Haptics.shared.playLight()
        Task {
            _ = await TradeManager.shared.respondToOffer(offer: offer, accept: accept)
            await MainActor.run { isProcessing = false; if accept { Haptics.shared.playSuccess() } }
        }
    }
    
    func timeAgoString(from date: Date) -> String {
        let interval = Date().timeIntervalSince(date)
        if interval < 60 { return "Just now" }
        if interval < 3600 { return "\(Int(interval / 60))m ago" }
        if interval < 86400 { return "\(Int(interval / 3600))h ago" }
        return "\(Int(interval / 86400))d ago"
    }
}

struct SentOfferCard: View {
    @Environment(\.colorScheme) private var colorScheme
    
    let offer: TradeOffer
    let onCancel: () -> Void
    
    private var primaryText: Color {
        colorScheme == .dark ? .white : .black
    }
    
    var body: some View {
        VStack(spacing: 12) {
            // Header
            HStack {
                HStack(spacing: 6) {
                    Circle()
                        .fill(Color.orange.opacity(0.2))
                        .frame(width: 28, height: 28)
                        .overlay(Image(systemName: "paperplane.fill").font(.system(size: 12)).foregroundStyle(.orange))
                    Text("Offer Sent")
                        .appFont(13, weight: .bold)
                        .foregroundStyle(primaryText)
                }
                Spacer()
                Text(offer.status.displayName)
                    .font(.caption2.bold())
                    .foregroundStyle(.orange)
                    .padding(.horizontal, 6).padding(.vertical, 3)
                    .background(Color.orange.opacity(0.1)).clipShape(Capsule())
            }
            
            // Items
            HStack(spacing: 10) {
                itemVisual(item: offer.offeredItem, label: "YOU OFFERED", borderColor: .orange)
                VStack(spacing: 4) {
                    Image(systemName: "arrow.right")
                        .font(.system(size: 14, weight: .bold))
                        .foregroundStyle(colorScheme == .dark ? .white.opacity(0.4) : .black.opacity(0.4))
                }
                itemVisual(item: offer.wantedItem, label: "FOR THEIR", borderColor: .gray)
            }
            
            Divider().background(Color.white.opacity(0.1))
            
            Button(action: onCancel) {
                HStack {
                    Image(systemName: "trash")
                    Text("Cancel Offer")
                }
                .font(.system(size: 13, weight: .bold))
                .foregroundStyle(.red.opacity(0.8))
                .padding(.vertical, 6)
                .frame(maxWidth: .infinity)
            }
        }
        .padding(16)
        .background(.ultraThinMaterial)
        .cornerRadius(20)
        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white.opacity(0.1), lineWidth: 1))
    }
    
    func itemVisual(item: TradeItem?, label: String, borderColor: Color) -> some View {
        VStack(spacing: 6) {
            Text(label).appFont(8, weight: .black).foregroundStyle(borderColor.opacity(0.8))
            AsyncImageView(filename: item?.imageUrl)
                .frame(width: 52, height: 52).cornerRadius(12)
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(borderColor.opacity(0.4), lineWidth: 2))
            Text(item?.title ?? "Unknown").appFont(11, weight: .bold).lineLimit(1).foregroundStyle(primaryText)
        }
        .frame(maxWidth: .infinity)
    }
}

// Helper Struct for Identifiable UUID
struct TradeProfileSheetWrapper: Identifiable {
    let id: UUID
}
