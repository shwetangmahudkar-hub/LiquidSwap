import SwiftUI

struct ActivityHubView: View {
    // ✨ Standard: Use native dismiss
    @Environment(\.dismiss) var dismiss
    
    @State private var events: [ActivityEvent] = []
    @State private var isLoading = true
    @State private var loadError: Error?
    @State private var selectedEvent: ActivityEvent?
    
    var body: some View {
        ZStack {
            // 1. Global Background (Standardization Rule)
            LiquidBackground()
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // 2. Standardized Header (No Back Button)
                HStack {
                    Text("Activity Hub")
                        .font(.system(size: 24, weight: .heavy, design: .rounded))
                        .foregroundStyle(.white)
                    
                    Spacer()
                }
                .padding(.horizontal, 24)
                .padding(.top, 24)
                .padding(.bottom, 16)
                
                // 3. Content
                if isLoading && events.isEmpty {
                    Spacer()
                    ProgressView()
                        .tint(.cyan)
                        .scaleEffect(1.2)
                    Spacer()
                } else if events.isEmpty {
                    VStack(spacing: 16) {
                        Image(systemName: "bell.slash")
                            .font(.system(size: 50))
                            .foregroundStyle(.white.opacity(0.5))
                        Text("No recent activity")
                            .font(.headline)
                            .foregroundStyle(.white.opacity(0.7))
                    }
                    .frame(maxHeight: .infinity)
                } else {
                    ScrollView(showsIndicators: false) {
                        LazyVStack(spacing: 16) {
                            ForEach(events) { event in
                                ActivityEventCard(event: event)
                                    .onTapGesture {
                                        Haptics.shared.playLight()
                                        selectedEvent = event
                                    }
                            }
                        }
                        .padding(.horizontal, 20)
                        .padding(.top, 10)
                        .padding(.bottom, 40)
                    }
                }
            }
        }
        // (Rule: No Default Nav Bar)
        .navigationBarHidden(true)
        .task {
            await loadActivity()
        }
        .sheet(item: $selectedEvent) { event in
            ZStack {
                // Detail Sheet with Liquid Background
                LiquidBackground().ignoresSafeArea()
                
                VStack(spacing: 20) {
                    Text(event.type.rawValue)
                        .font(.system(size: 24, weight: .heavy, design: .rounded))
                        .foregroundStyle(.white)
                    
                    Text("Item: \(event.item.title)")
                        .font(.headline)
                        .foregroundStyle(.white.opacity(0.8))
                    
                    Spacer()
                }
                .padding(.top, 40)
            }
            .presentationDetents([.medium])
            .presentationDragIndicator(.visible)
        }
    }
    
    // MARK: - Logic (Preserved)
    
    func loadActivity() async {
        // Simulate loading
        try? await Task.sleep(nanoseconds: 1_000_000_000)
        
        // Mock Data Preserved
        let mockUser = UserProfile(
            id: UUID(),
            username: "PixelPanda",
            bio: "Retro gamer",
            location: "Toronto",
            avatarUrl: nil,
            isoCategories: []
        )
        
        let mockItem = TradeItem(
            id: UUID(),
            ownerId: UUID(),
            title: "Vintage Controller",
            description: "Mint condition",
            condition: "New",
            category: "Electronics",
            imageUrl: nil,
            createdAt: Date(),
            price: nil,
            isDonation: false,
            latitude: nil,
            longitude: nil
        )
        
        let mockEvents = [
            ActivityEvent(
                id: UUID(),
                type: .newTrade,
                actor: mockUser,
                item: mockItem,
                createdAt: Date(),
                status: .pending
            ),
            ActivityEvent(
                id: UUID(),
                type: .like,
                actor: mockUser,
                item: mockItem,
                createdAt: Date().addingTimeInterval(-3600),
                status: .ignored
            )
        ]
        
        await MainActor.run {
            self.events = mockEvents
            isLoading = false
        }
    }
}

// MARK: - Subcomponents

struct ActivityEventCard: View {
    let event: ActivityEvent
    
    var iconName: String {
        switch event.type {
        case .like: return "heart.fill"
        case .newTrade: return "arrow.2.squarepath"
        case .system: return "bell.fill"
        }
    }
    
    var iconColor: Color {
        switch event.type {
        case .like: return .pink
        case .newTrade: return .blue
        case .system: return .yellow
        }
    }
    
    var body: some View {
        HStack(spacing: 12) {
            // Avatar / Icon
            ZStack {
                Circle()
                    .fill(Color.gray.opacity(0.3))
                    .frame(width: 50, height: 50)
                
                if let url = event.actor.avatarUrl {
                    AsyncImageView(filename: url)
                        .clipShape(Circle())
                        .frame(width: 50, height: 50)
                } else {
                    Text(event.actor.username.prefix(1))
                        .foregroundStyle(.white)
                        .font(.title3)
                        .bold()
                }
                
                // Badge Icon
                Image(systemName: iconName)
                    .font(.caption)
                    .padding(4)
                    .background(iconColor)
                    .clipShape(Circle())
                    .foregroundStyle(.white)
                    .offset(x: 18, y: 18)
            }
            
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text(event.actor.username)
                        .bold()
                        .foregroundStyle(.white)
                    
                    Spacer()
                    
                    Text(event.createdAt, style: .time)
                        .font(.caption)
                        .foregroundStyle(.gray)
                }
                
                Text(event.type.rawValue)
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.8))
                
                Text("on \(event.item.title)")
                    .font(.caption2)
                    .foregroundStyle(.gray)
                    .lineLimit(1)
            }
            
            Spacer()
        }
        .padding()
        // ✨ Updated to match GlassSection aesthetic
        .background(.ultraThinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .stroke(Color.white.opacity(0.1), lineWidth: 1)
        )
    }
}
