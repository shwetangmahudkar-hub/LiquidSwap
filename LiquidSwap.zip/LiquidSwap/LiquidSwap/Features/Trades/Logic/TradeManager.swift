import Foundation
import Combine
import SwiftUI
import Supabase

@MainActor
class TradeManager: ObservableObject {
    static let shared = TradeManager()
    
    @Published var interestedItems: [TradeItem] = []
    @Published var incomingOffers: [TradeOffer] = []
    @Published var activeTrades: [TradeOffer] = []
    
    // ✨ Cache profiles for chat list to avoid N+1 queries
    @Published var relatedProfiles: [UUID: UserProfile] = [:]
    
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var showError = false
    
    // MARK: - ✨ Rate Limit State
    @Published var rateLimitMessage: String?
    @Published var showRateLimitAlert = false
    
    private let db = DatabaseService.shared
    private let userManager = UserManager.shared
    private let client = SupabaseConfig.client
    
    private var channel: RealtimeChannelV2?
    private var realtimeTask: Task<Void, Never>?
    
    private init() {
        Task { await subscribeToRealtime() }
    }
    
    // MARK: - Data Loading
    func loadTradesData() async {
        guard let userId = userManager.currentUser?.id else { return }
        self.isLoading = true
        defer { self.isLoading = false }
        
        let blockedIDs = userManager.blockedUserIds
        
        do {
            async let interestedResult = loadInterestedItems(userId: userId)
            async let offersResult = loadIncomingOffers(userId: userId)
            async let activeResult = loadActiveTrades(userId: userId)
            
            let (interested, rawOffers, rawActive) = try await (interestedResult, offersResult, activeResult)
            
            // 1. Filter Blocked Users
            let filteredOffers = rawOffers.filter { !blockedIDs.contains($0.senderId) }
            let filteredActive = rawActive.filter { trade in
                let partnerId = (trade.senderId == userId) ? trade.receiverId : trade.senderId
                return !blockedIDs.contains(partnerId)
            }
            
            // 2. Hydrate Item Data
            let hydratedOffers = await hydrateTrades(filteredOffers)
            let hydratedActive = await hydrateTrades(filteredActive)
            
            self.interestedItems = interested
            self.incomingOffers = hydratedOffers
            self.activeTrades = hydratedActive
            
            // 3. Batch Load Profiles
            await loadRelatedProfiles(offers: hydratedOffers, active: hydratedActive, currentUserId: userId)
            
        } catch {
            print("Error loading trades: \(error)")
            self.errorMessage = error.localizedDescription
            self.showError = true
        }
    }
    
    private func loadRelatedProfiles(offers: [TradeOffer], active: [TradeOffer], currentUserId: UUID) async {
        var userIds = Set<UUID>()
        let allTrades = offers + active
        for trade in allTrades {
            if trade.senderId != currentUserId { userIds.insert(trade.senderId) }
            if trade.receiverId != currentUserId { userIds.insert(trade.receiverId) }
        }
        
        guard !userIds.isEmpty else { return }
        
        do {
            let profiles = try await db.fetchProfiles(userIds: Array(userIds))
            self.relatedProfiles = Dictionary(uniqueKeysWithValues: profiles.map { ($0.id, $0) })
        } catch {
            print("❌ Failed to batch load profiles: \(error)")
        }
    }
    
    private func loadInterestedItems(userId: UUID) async throws -> [TradeItem] {
        try await db.fetchLikedItems(userId: userId)
    }
    
    private func loadIncomingOffers(userId: UUID) async throws -> [TradeOffer] {
        return try await db.fetchIncomingOffers(userId: userId)
    }
    
    private func loadActiveTrades(userId: UUID) async throws -> [TradeOffer] {
        return try await db.fetchActiveTrades(userId: userId)
    }
    
    // MARK: - Hydration Logic
    private func hydrateTrades(_ trades: [TradeOffer]) async -> [TradeOffer] {
        if trades.isEmpty { return [] }
        
        var allItemIds = Set<UUID>()
        for trade in trades {
            trade.offeredItemIds.forEach { allItemIds.insert($0) }
            trade.wantedItemIds.forEach { allItemIds.insert($0) }
        }
        
        guard !allItemIds.isEmpty else { return trades }
        
        do {
            let fetchedItems = try await db.fetchBatchItems(ids: Array(allItemIds))
            let itemMap = Dictionary(uniqueKeysWithValues: fetchedItems.map { ($0.id, $0) })
            
            return trades.map { trade in
                var hydrated = trade
                hydrated.offeredItems = trade.offeredItemIds.compactMap { itemMap[$0] }
                hydrated.wantedItems = trade.wantedItemIds.compactMap { itemMap[$0] }
                return hydrated
            }
        } catch {
            print("❌ Hydration Error: \(error)")
            return trades
        }
    }
    
    // MARK: - Realtime
    func subscribeToRealtime() async {
        if let existing = channel { await existing.unsubscribe() }
        realtimeTask?.cancel()
        
        let newChannel = client.channel("public:trades")
        self.channel = newChannel
        let changeStream = newChannel.postgresChange(AnyAction.self, schema: "public", table: "trades")
        
        do {
            try await newChannel.subscribeWithError()
        } catch { return }
        
        realtimeTask = Task { [weak self] in
            for await _ in changeStream {
                await self?.loadTradesData()
            }
        }
    }
    
    // MARK: - Actions
    func markAsInterested(item: TradeItem) async -> Bool {
        guard let userId = userManager.currentUser?.id else { return false }
        let (allowed, message) = await RateLimiter.canLikeItem()
        if !allowed {
            await MainActor.run { self.rateLimitMessage = message; self.showRateLimitAlert = true }
            return false
        }
        do {
            try await db.saveLike(userId: userId, itemId: item.id)
            if !interestedItems.contains(where: { $0.id == item.id }) { interestedItems.append(item) }
            return true
        } catch { return false }
    }
    
    func removeInterest(item: TradeItem) async -> Bool {
        guard let userId = userManager.currentUser?.id else { return false }
        do {
            try await client.from("likes").delete().eq("user_id", value: userId).eq("item_id", value: item.id).execute()
            interestedItems.removeAll { $0.id == item.id }
            return true
        } catch { return false }
    }
    
    func checkIfOfferExists(wantedItemId: UUID, myItemId: UUID) async -> Bool {
        do {
            let count = try await client.from("trades").select("id", head: true, count: .exact).eq("wanted_item_id", value: wantedItemId).eq("offered_item_id", value: myItemId).in("status", values: TradeStatus.committedStatuses.map { $0.rawValue }).execute().count
            return (count ?? 0) > 0
        } catch { return false }
    }
    
    // MARK: - Item Check Logic
    
    struct ItemAvailabilityResult {
        let allAvailable: Bool
        let busyOfferedItems: [UUID]
        let busyWantedItems: [UUID]
        let duplicateTradeExists: Bool
    }
    
    func checkItemsAvailability(offeredItemIds: [UUID], wantedItemIds: [UUID]) async -> ItemAvailabilityResult {
        guard let myId = userManager.currentUser?.id else {
            return ItemAvailabilityResult(allAvailable: false, busyOfferedItems: [], busyWantedItems: [], duplicateTradeExists: false)
        }
        
        var busyOffered: [UUID] = []
        var busyWanted: [UUID] = []
        var duplicateExists = false
        
        do {
            let myActiveTrades: [TradeOffer] = try await client.from("trades").select()
                .eq("sender_id", value: myId)
                .in("status", values: TradeStatus.committedStatuses.map { $0.rawValue })
                .execute().value
            
            for trade in myActiveTrades {
                for offeredId in offeredItemIds {
                    if trade.offeredItemIds.contains(offeredId) { busyOffered.append(offeredId) }
                }
                if let pO = offeredItemIds.first, let pW = wantedItemIds.first,
                   trade.offeredItemId == pO && trade.wantedItemId == pW {
                    duplicateExists = true
                }
            }
            
            if !wantedItemIds.isEmpty {
                let wantedItemTrades: [TradeOffer] = try await client.from("trades").select()
                    .in("offered_item_id", values: wantedItemIds.map { $0.uuidString })
                    .in("status", values: TradeStatus.committedStatuses.map { $0.rawValue })
                    .execute().value
                
                for trade in wantedItemTrades {
                    if wantedItemIds.contains(trade.offeredItemId) { busyWanted.append(trade.offeredItemId) }
                }
            }
            
            return ItemAvailabilityResult(
                allAvailable: busyOffered.isEmpty && busyWanted.isEmpty && !duplicateExists,
                busyOfferedItems: Array(Set(busyOffered)),
                busyWantedItems: Array(Set(busyWanted)),
                duplicateTradeExists: duplicateExists
            )
        } catch {
            return ItemAvailabilityResult(allAvailable: true, busyOfferedItems: [], busyWantedItems: [], duplicateTradeExists: false)
        }
    }
    
    func isItemBusy(itemId: UUID) async -> Bool {
        do {
            let offeredCount = try await client.from("trades").select("id", head: true, count: .exact)
                .eq("offered_item_id", value: itemId).in("status", values: TradeStatus.committedStatuses.map { $0.rawValue }).execute().count
            if (offeredCount ?? 0) > 0 { return true }
            
            let wantedCount = try await client.from("trades").select("id", head: true, count: .exact)
                .eq("wanted_item_id", value: itemId).eq("status", value: TradeStatus.accepted.rawValue).execute().count
            return (wantedCount ?? 0) > 0
        } catch { return false }
    }

    func hasPendingOffer(for wantedItemId: UUID) async -> Bool {
        guard let myId = userManager.currentUser?.id else { return false }
        do {
            let count = try await client.from("trades").select("id", head: true, count: .exact).eq("sender_id", value: myId).eq("wanted_item_id", value: wantedItemId).eq("status", value: TradeStatus.pending.rawValue).execute().count
            return (count ?? 0) > 0
        } catch { return false }
    }
    
    func sendInquiry(wantedItem: TradeItem) async -> Bool {
        if await hasPendingOffer(for: wantedItem.id) {
            print("ℹ️ Trade already exists, skipping creation.")
            return true
        }
        guard let placeholderItem = userManager.userItems.first else {
            print("❌ sendInquiry Failed: User has no items to trade.")
            return false
        }
        return await sendOffer(wantedItem: wantedItem, myItem: placeholderItem)
    }

    func sendOffer(wantedItem: TradeItem, myItem: TradeItem) async -> Bool {
        return await sendMultiItemOffer(wantedItems: [wantedItem], offeredItems: [myItem])
    }
    
    // MARK: - Offer Result Enum
    enum OfferResult {
        case success
        case rateLimited(message: String)
        case duplicateOffer
        case itemsBusy(offered: [UUID], wanted: [UUID])
        case invalidItems
        case blocked
        case error(String)
        case securityViolation(String) // ✨ NEW: Specific error for RLS block
    }
    
    // MARK: - Send Multi-Item Offer
    func sendMultiItemOfferWithResult(wantedItems: [TradeItem], offeredItems: [TradeItem]) async -> OfferResult {
        guard let senderId = userManager.currentUser?.id else { return .error("Not logged in") }
        guard let primaryOffered = offeredItems.first, let primaryWanted = wantedItems.first else { return .invalidItems }
        
        let (allowed, rateLimitMsg) = await RateLimiter.canCreateOffer()
        if !allowed {
            await MainActor.run { self.rateLimitMessage = rateLimitMsg; self.showRateLimitAlert = true }
            return .rateLimited(message: rateLimitMsg ?? "Rate limited")
        }
        
        if primaryOffered.ownerId != senderId { return .invalidItems }
        if primaryWanted.ownerId == senderId { return .invalidItems }
        if userManager.blockedUserIds.contains(primaryWanted.ownerId) { return .blocked }
        
        let allOfferedIds = offeredItems.map { $0.id }
        let allWantedIds = wantedItems.map { $0.id }
        
        let availability = await checkItemsAvailability(offeredItemIds: allOfferedIds, wantedItemIds: allWantedIds)
        if availability.duplicateTradeExists { return .duplicateOffer }
        if !availability.allAvailable {
            return .itemsBusy(offered: availability.busyOfferedItems, wanted: availability.busyWantedItems)
        }
        
        let offer = TradeOffer(
            id: UUID(),
            senderId: senderId,
            receiverId: primaryWanted.ownerId,
            offeredItemId: primaryOffered.id,
            wantedItemId: primaryWanted.id,
            offeredItemIds: allOfferedIds,
            wantedItemIds: allWantedIds,
            status: .pending,
            createdAt: Date()
        )
        
        do {
            try await db.createTradeOffer(offer: offer)
            try? await db.saveLike(userId: senderId, itemId: primaryWanted.id)
            interestedItems.removeAll { $0.id == primaryWanted.id }
            return .success
        } catch {
            // ✨ NEW: Catch RLS violations
            let errorMsg = error.localizedDescription
            if errorMsg.contains("Security Violation") || errorMsg.contains("violates row-level security") {
                print("🚨 SECURITY ALERT: Database rejected trade due to ownership or policy violation.")
                return .securityViolation("Trade blocked by security check.")
            }
            return .error(errorMsg)
        }
    }
    
    func sendMultiItemOffer(wantedItems: [TradeItem], offeredItems: [TradeItem]) async -> Bool {
        let result = await sendMultiItemOfferWithResult(wantedItems: wantedItems, offeredItems: offeredItems)
        if case .success = result { return true }
        return false
    }
    
    func respondToOffer(offer: TradeOffer, accept: Bool) async -> Bool {
        guard let userId = userManager.currentUser?.id, offer.receiverId == userId else { return false }
        if accept {
            let isBlockedByMe = userManager.blockedUserIds.contains(offer.senderId)
            let isBlockedByThem = await checkIfBlockedBy(userId: offer.senderId)
            if isBlockedByMe || isBlockedByThem { return false }
        }
        let newStatus = accept ? TradeStatus.accepted.rawValue : TradeStatus.rejected.rawValue
        do {
            try await db.updateTradeStatus(tradeId: offer.id, status: newStatus)
            incomingOffers.removeAll { $0.id == offer.id }
            return true
        } catch { return false }
    }
    
    // MARK: - Blocked Helper
    private func checkIfBlockedBy(userId: UUID) async -> Bool {
        guard let myId = userManager.currentUser?.id else { return false }
        do {
            let count = try await client.from("blocked_users").select("id", head: true, count: .exact).eq("blocker_id", value: userId).eq("blocked_id", value: myId).execute().count
            return (count ?? 0) > 0
        } catch { return false }
    }
    
    // MARK: - Completion Logic
    enum CompletionResult {
        case confirmed, alreadyConfirmed, tradeCompleted, tradeNotAccepted, notParticipant, blocked, error(String)
    }
    
    func confirmCompletion(tradeId: UUID) async -> CompletionResult {
        guard let myId = userManager.currentUser?.id else { return .error("Not logged in") }
        do {
            let trades: [TradeOffer] = try await client.from("trades").select().eq("id", value: tradeId).execute().value
            guard let trade = trades.first else { return .error("Trade not found") }
            
            let isSender = trade.senderId == myId
            let isReceiver = trade.receiverId == myId
            guard isSender || isReceiver else { return .notParticipant }
            
            let partnerId = isSender ? trade.receiverId : trade.senderId
            
            if userManager.blockedUserIds.contains(partnerId) { return .blocked }
            if await checkIfBlockedBy(userId: partnerId) { return .blocked }
            
            if trade.status == .completed { return .tradeCompleted }
            if trade.status != .accepted { return .tradeNotAccepted }
            
            if (isSender && trade.senderConfirmedCompletion) || (isReceiver && trade.receiverConfirmedCompletion) {
                return .alreadyConfirmed
            }
            
            let column = isSender ? "sender_confirmed_completion" : "receiver_confirmed_completion"
            try await client.from("trades").update([column: true]).eq("id", value: tradeId).execute()
            
            let partnerConfirmed = isSender ? trade.receiverConfirmedCompletion : trade.senderConfirmedCompletion
            if partnerConfirmed {
                await ProgressionManager.shared.onTradeCompleted()
                await userManager.loadUserData()
                await loadTradesData()
                return .tradeCompleted
            }
            
            await loadTradesData()
            return .confirmed
        } catch { return .error(error.localizedDescription) }
    }
    
    func getCompletionStatus(tradeId: UUID) async -> (userConfirmed: Bool, partnerConfirmed: Bool, isComplete: Bool)? {
        guard let myId = userManager.currentUser?.id else { return nil }
        do {
            let trades: [TradeOffer] = try await client.from("trades").select().eq("id", value: tradeId).execute().value
            guard let trade = trades.first else { return nil }
            let isSender = trade.senderId == myId
            return (
                isSender ? trade.senderConfirmedCompletion : trade.receiverConfirmedCompletion,
                isSender ? trade.receiverConfirmedCompletion : trade.senderConfirmedCompletion,
                trade.status == .completed
            )
        } catch { return nil }
    }
    
    func fetchTrade(id: UUID) async -> TradeOffer? {
        do {
            let trades: [TradeOffer] = try await client.from("trades").select().eq("id", value: id).execute().value
            guard let trade = trades.first else { return nil }
            let hydrated = await hydrateTrades([trade])
            return hydrated.first
        } catch { return nil }
    }
    
    @available(*, deprecated, message: "Use confirmCompletion(tradeId:)")
    func completeTrade(with partnerId: UUID) async -> Bool {
        return false
    }
    
    func getActiveTrade(with partnerId: UUID) async -> TradeOffer? {
        guard let myId = userManager.currentUser?.id else { return nil }
        do {
            let response: [TradeOffer] = try await client.from("trades").select().in("status", values: [TradeStatus.accepted.rawValue, TradeStatus.pending.rawValue, TradeStatus.completed.rawValue]).or("and(sender_id.eq.\(myId),receiver_id.eq.\(partnerId)),and(sender_id.eq.\(partnerId),receiver_id.eq.\(myId))").order("created_at", ascending: false).limit(1).execute().value
            guard let tradeStub = response.first else { return nil }
            let hydratedTrades = await hydrateTrades([tradeStub])
            return hydratedTrades.first
        } catch { return nil }
    }
    
    // MARK: - Counter Offers
    enum CounterOfferResult {
        case success, rateLimited(message: String), originalTradeNotFound, originalTradeInvalidStatus, notOriginalReceiver, itemsBusy, blocked, error(String), securityViolation(String)
    }
    
    func sendCounterOfferWithResult(originalTradeId: UUID, newWantedItem: TradeItem) async -> CounterOfferResult {
        guard let myId = userManager.currentUser?.id else { return .error("Not logged in") }
        let (allowed, rateLimitMsg) = await RateLimiter.canCreateOffer()
        if !allowed {
            await MainActor.run { self.rateLimitMessage = rateLimitMsg; self.showRateLimitAlert = true }
            return .rateLimited(message: rateLimitMsg ?? "Rate limited")
        }
        
        do {
            let trades: [TradeOffer] = try await client.from("trades").select().eq("id", value: originalTradeId).execute().value
            guard let originalTrade = trades.first else { return .originalTradeNotFound }
            
            if originalTrade.status != .pending { return .originalTradeInvalidStatus }
            if originalTrade.receiverId != myId { return .notOriginalReceiver }
            if userManager.blockedUserIds.contains(originalTrade.senderId) { return .blocked }
            
            let myItemId = originalTrade.wantedItemId
            let availability = await checkItemsAvailability(offeredItemIds: [myItemId], wantedItemIds: [newWantedItem.id])
            if !availability.allAvailable { return .itemsBusy }
            
            if newWantedItem.ownerId != originalTrade.senderId { return .error("Item ownership mismatch") }
            
            let newOffer = TradeOffer(
                id: UUID(),
                senderId: myId,
                receiverId: originalTrade.senderId,
                offeredItemId: myItemId,
                wantedItemId: newWantedItem.id,
                offeredItemIds: [myItemId],
                wantedItemIds: [newWantedItem.id],
                status: .pending,
                createdAt: Date()
            )
            
            try await db.updateTradeStatus(tradeId: originalTrade.id, status: TradeStatus.countered.rawValue)
            try await db.createTradeOffer(offer: newOffer)
            try? await db.saveLike(userId: myId, itemId: newWantedItem.id)
            
            if let index = incomingOffers.firstIndex(where: { $0.id == originalTrade.id }) {
                incomingOffers.remove(at: index)
            }
            return .success
        } catch {
            // ✨ NEW: Catch RLS violations
            let errorMsg = error.localizedDescription
            if errorMsg.contains("Security Violation") || errorMsg.contains("violates row-level security") {
                print("🚨 SECURITY ALERT: Database rejected counter-offer.")
                return .securityViolation("Action blocked by security check.")
            }
            return .error(errorMsg)
        }
    }
    
    func sendCounterOffer(originalTrade: TradeOffer, newWantedItem: TradeItem) async -> Bool {
        let result = await sendCounterOfferWithResult(originalTradeId: originalTrade.id, newWantedItem: newWantedItem)
        if case .success = result { return true }
        return false
    }
}
