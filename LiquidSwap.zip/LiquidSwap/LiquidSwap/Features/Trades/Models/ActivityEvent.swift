//
//  ActivityEvent.swift
//  LiquidSwap
//
//  Created by Shwetang Mahudkar on 2025-12-27.
//

import Foundation

struct ActivityEvent: Identifiable, Codable {
    let id: UUID
    let type: EventType // ✨ Added: Distinguish between likes, trades, etc.
    let actor: UserProfile // The user who performed the action
    let item: TradeItem    // The item involved
    let createdAt: Date
    
    // We add a "status" to track if you've acted on it yet
    var status: ActivityStatus
    
    enum ActivityStatus: String, Codable {
        case pending  // You haven't seen/acted on it
        case matched  // You swiped back (It's a match!)
        case ignored  // You dismissed it
    }
    
    // ✨ New: Event Types
    enum EventType: String, Codable {
        case like = "Liked your item"
        case newTrade = "New Trade Offer"
        case system = "System Notification"
    }
    
    // Custom Init for easier mapping
    // ✨ default 'type' to .like to maintain compatibility with DatabaseService
    init(id: UUID = UUID(),
         type: EventType = .like,
         actor: UserProfile,
         item: TradeItem,
         createdAt: Date = Date(),
         status: ActivityStatus = .pending) {
        self.id = id
        self.type = type
        self.actor = actor
        self.item = item
        self.createdAt = createdAt
        self.status = status
    }
}
