import Foundation

// MARK: - Type-Safe Trade Status Enum

/// All possible trade statuses - eliminates magic strings
enum TradeStatus: String, Codable, CaseIterable {
    case pending = "pending"
    case accepted = "accepted"
    case rejected = "rejected"
    case countered = "countered"
    case cancelled = "cancelled"
    case completed = "completed"
    
    // MARK: - Display Properties
    
    var displayName: String {
        switch self {
        case .pending: return "Pending"
        case .accepted: return "Accepted"
        case .rejected: return "Declined"
        case .countered: return "Countered"
        case .cancelled: return "Cancelled"
        case .completed: return "Completed"
        }
    }
    
    var icon: String {
        switch self {
        case .pending: return "clock.fill"
        case .accepted: return "checkmark.circle.fill"
        case .rejected: return "xmark.circle.fill"
        case .countered: return "arrow.triangle.2.circlepath"
        case .cancelled: return "trash.fill"
        case .completed: return "star.fill"
        }
    }
    
    // MARK: - Status Categories
    
    /// Statuses where the trade is still active/in-progress
    static var activeStatuses: [TradeStatus] {
        return [.pending, .accepted]
    }
    
    /// Statuses where the trade has ended
    static var finalStatuses: [TradeStatus] {
        return [.rejected, .cancelled, .completed]
    }
    
    /// Statuses where items are committed (can't be used elsewhere)
    static var committedStatuses: [TradeStatus] {
        return [.pending, .accepted]
    }
    
    var isActive: Bool {
        return Self.activeStatuses.contains(self)
    }
    
    var isFinal: Bool {
        return Self.finalStatuses.contains(self)
    }
    
    var isCommitted: Bool {
        return Self.committedStatuses.contains(self)
    }
}

// MARK: - Trade Offer Model

struct TradeOffer: Identifiable, Codable, Hashable {
    var id: UUID
    var senderId: UUID
    var receiverId: UUID
    
    // MARK: - Primary Items (Legacy & Display)
    // We keep these for 1-to-1 backward compatibility and easy display logic
    var offeredItemId: UUID
    var wantedItemId: UUID
    
    // MARK: - Multi-Trade Support (The Source of Truth)
    // These arrays hold ALL items involved in the trade (Primary + Extras)
    // ✨ Updated to match the SQL column `offered_item_ids`
    var offeredItemIds: [UUID]
    var wantedItemIds: [UUID]
    
    var status: TradeStatus
    var createdAt: Date
    
    // MARK: - Two-Phase Completion
    var senderConfirmedCompletion: Bool = false
    var receiverConfirmedCompletion: Bool = false
    var completedAt: Date?
    
    // MARK: - UI-Only Properties (Hydrated after fetch)
    var offeredItems: [TradeItem] = []
    var wantedItems: [TradeItem] = []
    
    // MARK: - Computed Properties (UI Compatibility)
    
    // Primary Items
    var offeredItem: TradeItem? { offeredItems.first }
    var wantedItem: TradeItem? { wantedItems.first }
    
    // Extra Items (Calculated dynamically from the full list)
    var additionalOfferedItems: [TradeItem] {
        guard offeredItems.count > 1 else { return [] }
        return Array(offeredItems.dropFirst())
    }
    
    var additionalWantedItems: [TradeItem] {
        guard wantedItems.count > 1 else { return [] }
        return Array(wantedItems.dropFirst())
    }
    
    // ID Helpers
    var additionalOfferedItemIds: [UUID] {
        guard offeredItemIds.count > 1 else { return [] }
        return Array(offeredItemIds.dropFirst())
    }
    
    var additionalWantedItemIds: [UUID] {
        guard wantedItemIds.count > 1 else { return [] }
        return Array(wantedItemIds.dropFirst())
    }
    
    var allOfferedIds: [UUID] { offeredItemIds }
    var allWantedIds: [UUID] { wantedItemIds }
    var allOfferedItems: [TradeItem] { offeredItems }
    var allWantedItems: [TradeItem] { wantedItems }
    
    // MARK: - Completion Status Helpers
    
    var isBothConfirmed: Bool {
        return senderConfirmedCompletion && receiverConfirmedCompletion
    }
    
    var isCompleted: Bool {
        return status == .completed
    }
    
    var isPendingPartnerConfirmation: Bool {
        return status == .accepted && (senderConfirmedCompletion || receiverConfirmedCompletion) && !isBothConfirmed
    }
    
    func hasUserConfirmed(userId: UUID) -> Bool {
        if userId == senderId { return senderConfirmedCompletion }
        if userId == receiverId { return receiverConfirmedCompletion }
        return false
    }
    
    func hasPartnerConfirmed(userId: UUID) -> Bool {
        if userId == senderId { return receiverConfirmedCompletion }
        if userId == receiverId { return senderConfirmedCompletion }
        return false
    }
    
    // MARK: - Coding Keys
    
    enum CodingKeys: String, CodingKey {
        case id
        case senderId = "sender_id"
        case receiverId = "receiver_id"
        case offeredItemId = "offered_item_id"
        case wantedItemId = "wanted_item_id"
        // ✨ Updated to match SQL columns
        case offeredItemIds = "offered_item_ids"
        case wantedItemIds = "wanted_item_ids"
        case status
        case createdAt = "created_at"
        case senderConfirmedCompletion = "sender_confirmed_completion"
        case receiverConfirmedCompletion = "receiver_confirmed_completion"
        case completedAt = "completed_at"
    }
    
    // MARK: - Custom Decoder (Robust Handling)
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        id = try container.decode(UUID.self, forKey: .id)
        senderId = try container.decode(UUID.self, forKey: .senderId)
        receiverId = try container.decode(UUID.self, forKey: .receiverId)
        offeredItemId = try container.decode(UUID.self, forKey: .offeredItemId)
        wantedItemId = try container.decode(UUID.self, forKey: .wantedItemId)
        createdAt = try container.decode(Date.self, forKey: .createdAt)
        
        // Decode Status
        if let statusString = try? container.decode(String.self, forKey: .status),
           let decodedStatus = TradeStatus(rawValue: statusString) {
            status = decodedStatus
        } else {
            status = .pending
        }
        
        // ✨ SMART DECODING: Handle Migration
        // If 'offered_item_ids' is empty (old trade), build it from 'offered_item_id'
        if let ids = try? container.decode([UUID].self, forKey: .offeredItemIds), !ids.isEmpty {
            offeredItemIds = ids
        } else {
            offeredItemIds = [offeredItemId]
        }
        
        if let ids = try? container.decode([UUID].self, forKey: .wantedItemIds), !ids.isEmpty {
            wantedItemIds = ids
        } else {
            wantedItemIds = [wantedItemId]
        }
        
        // Completion Fields
        senderConfirmedCompletion = try container.decodeIfPresent(Bool.self, forKey: .senderConfirmedCompletion) ?? false
        receiverConfirmedCompletion = try container.decodeIfPresent(Bool.self, forKey: .receiverConfirmedCompletion) ?? false
        completedAt = try container.decodeIfPresent(Date.self, forKey: .completedAt)
    }
    
    // MARK: - Encodable
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(id, forKey: .id)
        try container.encode(senderId, forKey: .senderId)
        try container.encode(receiverId, forKey: .receiverId)
        
        // Write both Single and Array fields to keep DB consistent
        try container.encode(offeredItemId, forKey: .offeredItemId)
        try container.encode(wantedItemId, forKey: .wantedItemId)
        try container.encode(offeredItemIds, forKey: .offeredItemIds)
        try container.encode(wantedItemIds, forKey: .wantedItemIds)
        
        try container.encode(status.rawValue, forKey: .status)
        try container.encode(createdAt, forKey: .createdAt)
        try container.encode(senderConfirmedCompletion, forKey: .senderConfirmedCompletion)
        try container.encode(receiverConfirmedCompletion, forKey: .receiverConfirmedCompletion)
        try container.encodeIfPresent(completedAt, forKey: .completedAt)
    }
    
    // MARK: - Init
    
    init(id: UUID = UUID(),
         senderId: UUID,
         receiverId: UUID,
         offeredItemId: UUID, // Legacy param for convenience
         wantedItemId: UUID,  // Legacy param for convenience
         offeredItemIds: [UUID], // New Source of Truth
         wantedItemIds: [UUID],  // New Source of Truth
         status: TradeStatus = .pending,
         createdAt: Date = Date(),
         senderConfirmedCompletion: Bool = false,
         receiverConfirmedCompletion: Bool = false,
         completedAt: Date? = nil) {
        
        self.id = id
        self.senderId = senderId
        self.receiverId = receiverId
        
        self.offeredItemIds = offeredItemIds
        self.wantedItemIds = wantedItemIds
        
        // Ensure legacy IDs match the first item in the array
        self.offeredItemId = offeredItemIds.first ?? offeredItemId
        self.wantedItemId = wantedItemIds.first ?? wantedItemId
        
        self.status = status
        self.createdAt = createdAt
        self.senderConfirmedCompletion = senderConfirmedCompletion
        self.receiverConfirmedCompletion = receiverConfirmedCompletion
        self.completedAt = completedAt
    }
    
    // Helper init for creating fresh offers (Autofills legacy IDs)
    init(senderId: UUID, receiverId: UUID, offeredItemIds: [UUID], wantedItemIds: [UUID]) {
        self.init(
            id: UUID(),
            senderId: senderId,
            receiverId: receiverId,
            offeredItemId: offeredItemIds.first!,
            wantedItemId: wantedItemIds.first!,
            offeredItemIds: offeredItemIds,
            wantedItemIds: wantedItemIds
        )
    }
}
