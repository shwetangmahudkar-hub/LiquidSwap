import SwiftUI

struct EditItemView: View {
    @Environment(\.dismiss) var dismiss
    @ObservedObject var userManager = UserManager.shared
    
    // The item we are editing
    @State var item: TradeItem
    
    // UI State
    @State private var isSaving = false
    @State private var showDeleteAlert = false
    @State private var showErrorShake = false
    
    // Granular Category List
    let categories = [
        "Electronics", "Video Games", "Fashion", "Shoes",
        "Books", "Sports", "Home & Garden", "Collectibles", "Other"
    ]
    let conditions = ["New", "Like New", "Good", "Fair", "Poor"]
    
    // ✨ FIX: Explicit Initializer to prevent the crash
    init(item: TradeItem) {
        _item = State(initialValue: item)
    }
    
    var body: some View {
        ZStack {
            // 1. Global Background (Rule: Base Layer)
            LiquidBackground()
                .ignoresSafeArea()
            
            VStack(spacing: 0) { // (Rule: Layout)
                
                // 2. Custom Header (Rule: Typography & Structure)
                HStack {
                    Text("Edit Item")
                        .font(.system(size: 24, weight: .heavy, design: .rounded)) // (Rule: 24pt Heavy Rounded)
                        .foregroundStyle(.white)
                    
                    Spacer()
                    
                    if isSaving {
                        ProgressView().tint(.cyan)
                    } else {
                        Button("Save") {
                            saveChanges()
                        }
                        .font(.headline.bold())
                        .foregroundStyle(.cyan)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 8)
                        .background(Color.cyan.opacity(0.1))
                        .clipShape(Capsule())
                        .disabled(item.title.isEmpty)
                        .opacity(item.title.isEmpty ? 0.5 : 1)
                    }
                }
                .padding(.horizontal, 24)
                .padding(.top, 24)
                .padding(.bottom, 16)
                
                // 3. Main Form
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 24) {
                        
                        // Hero Image
                        heroImageSection
                        
                        // Form Fields
                        VStack(spacing: 20) {
                            // Primary Info
                            GlassSection {
                                VStack(spacing: 16) {
                                    // Title
                                    GlassTextField(placeholder: "Item Title", text: $item.title, icon: "tag.fill")
                                    
                                    // Description
                                    VStack(alignment: .leading, spacing: 8) {
                                        Text("DESCRIPTION")
                                            .font(.caption.bold())
                                            .foregroundStyle(.white.opacity(0.6))
                                            .padding(.leading, 4)
                                        
                                        TextEditor(text: $item.description)
                                            .scrollContentBackground(.hidden)
                                            .frame(height: 120)
                                            .padding(12)
                                            .background(Color.black.opacity(0.2))
                                            .cornerRadius(16)
                                            .overlay(
                                                RoundedRectangle(cornerRadius: 16)
                                                    .stroke(Color.white.opacity(0.1), lineWidth: 1)
                                            )
                                            .foregroundStyle(.white)
                                    }
                                }
                            }
                            
                            // Details
                            GlassSection {
                                VStack(spacing: 16) {
                                    GlassPicker(title: "Category", selection: $item.category, options: categories, icon: "square.grid.2x2.fill")
                                    
                                    Divider().background(Color.white.opacity(0.1))
                                    
                                    GlassPicker(title: "Condition", selection: $item.condition, options: conditions, icon: "star.fill")
                                }
                            }
                            
                            // Danger Zone
                            Button(action: { showDeleteAlert = true }) {
                                HStack {
                                    Image(systemName: "trash.fill")
                                    Text("Delete Listing")
                                }
                                .font(.headline)
                                .foregroundStyle(.white)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.red.opacity(0.8))
                                .clipShape(RoundedRectangle(cornerRadius: 16))
                                .shadow(color: .red.opacity(0.4), radius: 10, y: 5)
                            }
                            .padding(.top, 10)
                        }
                        .padding(.horizontal, 20)
                        
                        Spacer(minLength: 100)
                    }
                    .padding(.top, 20)
                }
                .scrollDismissesKeyboard(.interactively)
            }
        }
        // (Rule: No Default Nav Bar)
        .navigationBarHidden(true)
        .alert("Delete Item?", isPresented: $showDeleteAlert) {
            Button("Delete", role: .destructive) { deleteItem() }
            Button("Cancel", role: .cancel) { }
        } message: {
            Text("This action cannot be undone. The item will be removed from the marketplace.")
        }
        .offset(x: showErrorShake ? 10 : 0)
        .animation(.spring(response: 0.2, dampingFraction: 0.2), value: showErrorShake)
    }
    
    // MARK: - Subviews
    
    private var heroImageSection: some View {
        AsyncImageView(filename: item.imageUrl)
            .scaledToFill()
            .frame(height: 280)
            .frame(maxWidth: .infinity)
            .clipShape(RoundedRectangle(cornerRadius: 24))
            .overlay(
                RoundedRectangle(cornerRadius: 24)
                    .stroke(Color.white.opacity(0.1), lineWidth: 1)
            )
            .shadow(color: .black.opacity(0.3), radius: 20, y: 10)
            .padding(.horizontal, 20)
    }
    
    // MARK: - Logic
    
    func saveChanges() {
        isSaving = true
        Task {
            do {
                try await userManager.updateItem(item)
                try? await Task.sleep(nanoseconds: 500_000_000)
                
                await MainActor.run {
                    Haptics.shared.playSuccess()
                    isSaving = false
                    dismiss()
                }
            } catch {
                await MainActor.run {
                    Haptics.shared.playError()
                    print("Error saving item: \(error)")
                    showErrorShake = true
                    isSaving = false
                }
                try? await Task.sleep(nanoseconds: 300_000_000)
                await MainActor.run { showErrorShake = false }
            }
        }
    }
    
    func deleteItem() {
        isSaving = true
        Task {
            do {
                try await userManager.deleteItem(item: item)
                try? await Task.sleep(nanoseconds: 500_000_000)
                
                await MainActor.run {
                    Haptics.shared.playSuccess()
                    isSaving = false
                    dismiss()
                }
            } catch {
                await MainActor.run {
                    Haptics.shared.playError()
                    print("Error deleting item: \(error)")
                    showErrorShake = true
                    isSaving = false
                }
            }
        }
    }
}
