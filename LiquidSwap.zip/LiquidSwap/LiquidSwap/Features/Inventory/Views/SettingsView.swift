import SwiftUI

struct SettingsView: View {
    // ✨ UPDATED: Use native dismiss since this is presented as a .sheet
    @Environment(\.dismiss) var dismiss
    @Environment(\.colorScheme) private var colorScheme
    
    // Dependencies
    @ObservedObject var userManager = UserManager.shared
    
    // UI State for Sheets
    @State private var showEditProfile = false
    @State private var showVerification = false
    @State private var showBlockedUsers = false
    
    // UI State for Toggles
    @State private var showExactLocation = true
    @State private var isGhostMode = false
    @State private var allowFriendRequests = true
    
    // App Preferences
    @AppStorage("isDarkMode") private var isDarkMode = true
    @AppStorage("autoHideTabBar") private var autoHideTabBar = false
    @AppStorage("showLikeButton") private var showLikeButton = false
    
    // Developer / Onboarding Controls
    @AppStorage("dev_alwaysShowOnboarding") private var alwaysShowOnboarding = false
    @AppStorage("hasSeenOnboarding") private var hasSeenOnboarding = true
    
    // ✨ NEW: Toggle for forcing analytics to show even when values are 0
    @AppStorage("dev_forceShowAnalytics") private var forceShowAnalytics = false
    
    // Alert State
    @State private var showDeleteAlert = false
    @State private var showSignOutAlert = false
    
    // MARK: - Body
    var body: some View {
        ZStack {
            // 1. Global Background (Standardization Rule)
            LiquidBackground()
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // 2. Standardized Header
                HStack {
                    Text("Settings")
                        .font(.system(size: 24, weight: .heavy, design: .rounded))
                        .foregroundStyle(.white)
                    
                    Spacer()
                }
                .padding(.horizontal, 24)
                .padding(.top, 24)
                .padding(.bottom, 16)
                
                // 3. Scrollable Content
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 24) {
                        accountSection
                        privacySection
                        preferencesSection
                        developerSection
                        dangerZoneSection
                        footerSection
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 10)
                    .padding(.bottom, 40)
                }
            }
        }
        // (Rule: No Default Nav Bar)
        .navigationBarHidden(true)
        .onAppear(perform: loadUserData)
        .onChange(of: showExactLocation) { _ in updatePrivacySettings() }
        .onChange(of: isGhostMode) { _ in updatePrivacySettings() }
        .onChange(of: allowFriendRequests) { _ in updatePrivacySettings() }
        
        // Sheets & Alerts
        .sheet(isPresented: $showEditProfile) {
            EditProfileView()
                .presentationDetents([.large])
                .presentationDragIndicator(.visible)
        }
        .sheet(isPresented: $showVerification) {
            VerificationView()
                .presentationDetents([.medium, .large])
                .presentationDragIndicator(.visible)
        }
        .alert("Sign Out", isPresented: $showSignOutAlert) {
            Button("Cancel", role: .cancel) { }
            Button("Sign Out", role: .destructive) { handleSignOut() }
        } message: {
            Text("Are you sure you want to sign out?")
        }
        .alert("Delete Account", isPresented: $showDeleteAlert) {
            Button("Cancel", role: .cancel) { }
            Button("Delete", role: .destructive) {
                print("Delete account requested")
            }
        } message: {
            Text("This action cannot be undone. All your items and trade history will be permanently removed.")
        }
    }
    
    // MARK: - Sections
    
    private var accountSection: some View {
        VStack(spacing: 12) {
            SectionHeader(title: "ACCOUNT")
            GlassSection {
                VStack(spacing: 0) {
                    SettingsRow(icon: "person.circle", title: "Edit Profile") { showEditProfile = true }
                    Divider().background(Color.white.opacity(0.1))
                    SettingsRow(icon: "checkmark.shield", title: "Verification") { showVerification = true }
                    Divider().background(Color.white.opacity(0.1))
                    SettingsRow(icon: "hand.raised.slash", title: "Blocked Users") { showBlockedUsers = true }
                }
            }
        }
    }
    
    private var privacySection: some View {
        VStack(spacing: 12) {
            SectionHeader(title: "PRIVACY")
            GlassSection {
                VStack(spacing: 0) {
                    SettingsToggleRow(icon: "location.circle", title: "Show Exact Location", isOn: $showExactLocation)
                    Divider().background(Color.white.opacity(0.1))
                    SettingsToggleRow(icon: "eye.slash", title: "Ghost Mode", isOn: $isGhostMode)
                    Divider().background(Color.white.opacity(0.1))
                    SettingsToggleRow(icon: "person.2.circle", title: "Allow Friend Requests", isOn: $allowFriendRequests)
                }
            }
        }
    }
    
    private var preferencesSection: some View {
        VStack(spacing: 12) {
            SectionHeader(title: "PREFERENCES")
            GlassSection {
                VStack(spacing: 0) {
                    SettingsToggleRow(icon: "moon.stars", title: "Dark Mode", isOn: $isDarkMode)
                    Divider().background(Color.white.opacity(0.1))
                    
                    SettingsToggleRow(icon: "heart.circle", title: "Show Like Button", isOn: $showLikeButton)
                    Divider().background(Color.white.opacity(0.1))
                    
                    SettingsToggleRow(icon: "menubar.arrow.down.rectangle", title: "Auto-Hide Navigation", isOn: $autoHideTabBar)
                }
            }
        }
    }
    
    private var developerSection: some View {
        VStack(spacing: 12) {
            SectionHeader(title: "DEVELOPER")
            GlassSection {
                VStack(spacing: 0) {
                    SettingsToggleRow(icon: "play.circle", title: "Always Show Onboarding", isOn: $alwaysShowOnboarding)
                    Divider().background(Color.white.opacity(0.1))
                    
                    // ✨ NEW: Force Show Analytics Toggle
                    SettingsToggleRow(icon: "chart.bar.fill", title: "Force Show Analytics", isOn: $forceShowAnalytics)
                    Divider().background(Color.white.opacity(0.1))
                    
                    Button(action: {
                        hasSeenOnboarding = false
                        Haptics.shared.playSuccess()
                    }) {
                        HStack(spacing: 12) {
                            Image(systemName: "arrow.counterclockwise")
                                .font(.system(size: 16))
                                .foregroundStyle(.yellow)
                                .frame(width: 24)
                            Text("Reset Onboarding Once")
                                .font(.subheadline)
                                .foregroundStyle(.yellow)
                            Spacer()
                        }
                        .padding(.vertical, 16)
                        .padding(.horizontal, 16)
                    }
                }
            }
        }
    }
    
    private var dangerZoneSection: some View {
        VStack(spacing: 12) {
            SectionHeader(title: "DANGER ZONE")
            GlassSection {
                VStack(spacing: 0) {
                    SettingsRow(icon: "rectangle.portrait.and.arrow.right", title: "Sign Out", isDestructive: true) {
                        showSignOutAlert = true
                    }
                    Divider().background(Color.white.opacity(0.1))
                    SettingsRow(icon: "trash", title: "Delete Account", isDestructive: true) {
                        showDeleteAlert = true
                    }
                }
            }
        }
    }
    
    private var footerSection: some View {
        VStack(spacing: 8) {
            Text("Swappr v1.0")
                .font(.caption)
                .foregroundStyle(.white.opacity(0.3))
            Text("Made with Liquid Code")
                .font(.caption2)
                .foregroundStyle(.white.opacity(0.2))
        }
        .padding(.top, 20)
    }
    
    // MARK: - Logic Handlers
    
    private func loadUserData() {
        if let user = userManager.currentUser {
            showExactLocation = user.showExactLocation
            isGhostMode = user.isGhostMode
            allowFriendRequests = user.allowFriendRequests
        }
    }
    
    private func updatePrivacySettings() {
        Task {
            await userManager.updatePrivacySettings(
                showExactLocation: showExactLocation,
                isGhostMode: isGhostMode,
                allowFriendRequests: allowFriendRequests
            )
        }
    }
    
    private func handleSignOut() {
        Task {
            do {
                try await userManager.signOut()
                dismiss()
            } catch {
                print("Error signing out: \(error)")
            }
        }
    }
}

// MARK: - Local Subcomponents

struct SectionHeader: View {
    let title: String
    
    var body: some View {
        HStack {
            Text(title)
                .font(.caption.bold())
                .foregroundStyle(.white.opacity(0.6))
                .padding(.leading, 8)
            Spacer()
        }
    }
}

struct SettingsRow: View {
    let icon: String
    let title: String
    var isDestructive: Bool = false
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Image(systemName: icon)
                    .font(.system(size: 16))
                    .foregroundStyle(isDestructive ? .red : .cyan)
                    .frame(width: 24)
                
                Text(title)
                    .font(.subheadline)
                    .foregroundStyle(isDestructive ? .red : .white)
                
                Spacer()
                
                Image(systemName: "chevron.right")
                    .font(.caption2)
                    .foregroundStyle(.white.opacity(0.3))
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 16)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}

struct SettingsToggleRow: View {
    let icon: String
    let title: String
    @Binding var isOn: Bool
    
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 16))
                .foregroundStyle(.purple)
                .frame(width: 24)
            
            Text(title)
                .font(.subheadline)
                .foregroundStyle(.white)
            
            Spacer()
            
            Toggle("", isOn: $isOn)
                .labelsHidden()
                .tint(.purple)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
    }
}
