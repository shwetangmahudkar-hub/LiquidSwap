import SwiftUI
import PhotosUI

struct VerificationView: View {
    @Environment(\.dismiss) var dismiss
    @ObservedObject var userManager = UserManager.shared
    
    // Form State
    @State private var fullName = ""
    @State private var selectedItem: PhotosPickerItem?
    @State private var selectedImage: UIImage?
    
    // Process State
    @State private var isSubmitting = false
    @State private var isSuccess = false
    
    var body: some View {
        ZStack(alignment: .top) {
            // 1. Global Background
            LiquidBackground()
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // 2. Standardized Header
                HStack {
                    Text("Get Verified")
                        .font(.system(size: 24, weight: .heavy, design: .rounded))
                        .foregroundStyle(.white)
                    
                    Spacer()
                }
                .padding(.horizontal, 24)
                .padding(.top, 24)
                .padding(.bottom, 16)
                
                // 3. Main Content
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 24) {
                        
                        // Hero Icon / Image Preview
                        ZStack {
                            if let image = selectedImage {
                                Image(uiImage: image)
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 100, height: 100)
                                    .clipShape(Circle())
                                    .overlay(
                                        Circle()
                                            .stroke(Color.cyan, lineWidth: 2)
                                    )
                                    .shadow(color: .cyan.opacity(0.3), radius: 10)
                                
                                // Edit Badge
                                VStack {
                                    Spacer()
                                    HStack {
                                        Spacer()
                                        Image(systemName: "pencil.circle.fill")
                                            .font(.title3)
                                            .foregroundStyle(.white)
                                            .background(Circle().fill(Color.cyan))
                                    }
                                }
                                .frame(width: 100, height: 100)
                                
                            } else {
                                // Default Hero
                                ZStack {
                                    Circle()
                                        .fill(Color.cyan.opacity(0.1))
                                        .frame(width: 100, height: 100)
                                        .overlay(Circle().stroke(Color.cyan.opacity(0.3), lineWidth: 1))
                                    
                                    Image(systemName: "checkmark.shield.fill")
                                        .font(.system(size: 44))
                                        .foregroundStyle(.cyan)
                                }
                            }
                        }
                        
                        // Instructions
                        VStack(spacing: 8) {
                            Text("Build Trust")
                                .font(.title3.bold())
                                .foregroundStyle(.white)
                            
                            Text("Verified users get 2x more trades and higher visibility in the feed.")
                                .font(.subheadline)
                                .foregroundStyle(.white.opacity(0.7))
                                .multilineTextAlignment(.center)
                                .padding(.horizontal)
                        }
                        
                        // Form
                        VStack(spacing: 20) {
                            // Name Field
                            GlassTextField(placeholder: "Full Legal Name", text: $fullName, icon: "person.text.rectangle")
                            
                            // ID Upload
                            PhotosPicker(selection: $selectedItem, matching: .images) {
                                HStack {
                                    Image(systemName: selectedImage == nil ? "camera.fill" : "checkmark.circle.fill")
                                        .foregroundStyle(selectedImage == nil ? .white : .green)
                                    
                                    Text(selectedImage == nil ? "Upload Government ID" : "ID Uploaded")
                                        .font(.headline)
                                        .foregroundStyle(.white)
                                    
                                    Spacer()
                                    
                                    if selectedImage == nil {
                                        Image(systemName: "chevron.right")
                                            .foregroundStyle(.white.opacity(0.5))
                                    }
                                }
                                .padding()
                                .background(Color.white.opacity(0.05))
                                .clipShape(RoundedRectangle(cornerRadius: 16))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 16)
                                        .stroke(Color.white.opacity(0.1), lineWidth: 1)
                                )
                            }
                        }
                        .padding(.horizontal, 4)
                        
                        Spacer(minLength: 40)
                        
                        // Submit Button
                        Button(action: submitVerification) {
                            HStack {
                                if isSubmitting {
                                    ProgressView()
                                        .tint(.black)
                                        .padding(.trailing, 4)
                                }
                                
                                Text(isSuccess ? "Request Sent!" : "Submit Request")
                                    .font(.headline.bold())
                            }
                            .foregroundStyle(isSuccess ? .white : .black)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                            .background(isSuccess ? Color.green : (isValid ? Color.cyan : Color.white.opacity(0.1)))
                            .clipShape(Capsule())
                            .shadow(color: isValid ? .cyan.opacity(0.3) : .clear, radius: 10, y: 5)
                        }
                        .disabled(!isValid || isSubmitting || isSuccess)
                        .padding(.horizontal, 4)
                        .padding(.bottom, 24)
                    }
                    .padding(.horizontal, 24)
                }
            }
        }
        // This enables the little grey "drag bar" at the top automatically
        .presentationDragIndicator(.visible)
        .presentationDetents([.large])
        .onChange(of: selectedItem) { newItem in
            Task {
                if let data = try? await newItem?.loadTransferable(type: Data.self),
                   let image = UIImage(data: data) {
                    await MainActor.run { selectedImage = image }
                }
            }
        }
    }
    
    // MARK: - Logic
    
    var isValid: Bool {
        !fullName.isEmpty && selectedImage != nil
    }
    
    func submitVerification() {
        Haptics.shared.playMedium()
        isSubmitting = true
        
        // Simulate API Processing
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            isSubmitting = false
            isSuccess = true
            Haptics.shared.playSuccess()
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                dismiss()
            }
        }
    }
}
