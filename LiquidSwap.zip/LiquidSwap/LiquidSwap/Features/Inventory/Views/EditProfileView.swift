import SwiftUI
import PhotosUI

@MainActor
struct EditProfileView: View {
    @Environment(\.dismiss) var dismiss
    
    @ObservedObject var userManager = UserManager.shared
    @ObservedObject var locationManager = LocationManager.shared
    
    // Form State
    @State private var username: String = ""
    @State private var bio: String = ""
    @State private var location: String = ""
    @State private var isoCategories: [String] = []
    
    // Image Handling
    @State private var selectedItem: PhotosPickerItem?
    @State private var selectedImage: UIImage?
    
    // UI State
    @State private var isSaving = false
    @State private var isFindingLocation = false
    @State private var showVerification = false
    
    // Data Sources
    let allCategories = [
        "Electronics", "Video Games", "Fashion", "Shoes",
        "Books", "Sports", "Home & Garden", "Collectibles", "Other"
    ]
    
    var body: some View {
        ZStack {
            // 1. Global Background
            LiquidBackground()
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // 2. Standardized Header
                HStack {
                    Text("Edit Profile")
                        .font(.system(size: 24, weight: .heavy, design: .rounded))
                        .foregroundStyle(.white)
                    
                    Spacer()
                    
                    if isSaving {
                        ProgressView().tint(.white)
                    } else {
                        Button("Save") {
                            saveProfile()
                        }
                        .font(.headline.bold())
                        .foregroundStyle(.cyan)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 8)
                        .background(Color.cyan.opacity(0.1))
                        .clipShape(Capsule())
                    }
                }
                .padding(.horizontal, 24)
                .padding(.top, 24)
                .padding(.bottom, 16)
                
                // 3. Main Content
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 24) {
                        
                        // Avatar Section
                        VStack(spacing: 12) {
                            // ✨ FIX: Safely capture MainActor properties locally to satisfy Swift 6 strict concurrency inside the PhotosPicker closure
                            let currentImg = selectedImage
                            let currentAvatarUrl = userManager.currentUser?.avatarUrl
                            
                            PhotosPicker(selection: $selectedItem, matching: .images) {
                                ZStack {
                                    if let img = currentImg {
                                        Image(uiImage: img)
                                            .resizable()
                                            .scaledToFill()
                                            .frame(width: 100, height: 100)
                                            .clipShape(Circle())
                                    } else if let url = currentAvatarUrl {
                                        AsyncImageView(filename: url)
                                            .scaledToFill()
                                            .frame(width: 100, height: 100)
                                            .clipShape(Circle())
                                    } else {
                                        Circle()
                                            .fill(Color.white.opacity(0.1))
                                            .frame(width: 100, height: 100)
                                            .overlay(
                                                Image(systemName: "camera.fill")
                                                    .font(.title2)
                                                    .foregroundStyle(.white.opacity(0.5))
                                            )
                                    }
                                    
                                    // Edit Overlay
                                    Circle()
                                        .stroke(Color.white.opacity(0.1), lineWidth: 4)
                                        .frame(width: 100, height: 100)
                                    
                                    VStack {
                                        Spacer()
                                        HStack {
                                            Spacer()
                                            Image(systemName: "pencil.circle.fill")
                                                .font(.title3)
                                                .foregroundStyle(.white)
                                                .background(Circle().fill(Color.cyan))
                                        }
                                    }
                                    .frame(width: 100, height: 100)
                                }
                            }
                            
                            Text("Change Photo")
                                .font(.caption)
                                .foregroundStyle(.white.opacity(0.5))
                        }
                        
                        // Form Fields
                        VStack(spacing: 20) {
                            GlassTextField(placeholder: "Username", text: $username, icon: "person.fill")
                            
                            GlassTextField(placeholder: "Bio", text: $bio, icon: "text.quote")
                            
                            // Location Field with Auto-Find
                            HStack(spacing: 12) {
                                GlassTextField(placeholder: "Location (City)", text: $location, icon: "mappin.and.ellipse")
                                
                                Button(action: fetchCurrentLocation) {
                                    if isFindingLocation {
                                        ProgressView().tint(.cyan)
                                    } else {
                                        Image(systemName: "location.fill")
                                            .foregroundStyle(.cyan)
                                            .padding(12)
                                            .background(Color.cyan.opacity(0.1))
                                            .clipShape(Circle())
                                    }
                                }
                            }
                        }
                        
                        // ISO Categories
                        VStack(alignment: .leading, spacing: 12) {
                            Text("INTERESTED IN (ISO)")
                                .font(.caption.bold())
                                .foregroundStyle(.white.opacity(0.5))
                                .padding(.leading, 4)
                            
                            // Relying on global FlowLayout since redeclaration caused error
                            FlowLayout(spacing: 8) {
                                ForEach(allCategories, id: \.self) { category in
                                    let isSelected = isoCategories.contains(category)
                                    Button(action: { toggleCategory(category) }) {
                                        Text(category)
                                            .font(.caption.bold())
                                            .foregroundStyle(isSelected ? .white : .white.opacity(0.6))
                                            .padding(.horizontal, 12)
                                            .padding(.vertical, 8)
                                            .background(isSelected ? Color.cyan : Color.white.opacity(0.05))
                                            .clipShape(Capsule())
                                            .overlay(
                                                Capsule()
                                                    .stroke(isSelected ? Color.clear : Color.white.opacity(0.1), lineWidth: 1)
                                            )
                                    }
                                }
                            }
                        }
                        
                        // Verification Status
                        GlassCard {
                            HStack {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text("Verification Status")
                                        .font(.headline)
                                        .foregroundStyle(.white)
                                    
                                    if userManager.currentUser?.isVerified == true {
                                        Text("Verified Account")
                                            .font(.caption)
                                            .foregroundStyle(.green)
                                    } else {
                                        Text("Not Verified")
                                            .font(.caption)
                                            .foregroundStyle(.white.opacity(0.5))
                                    }
                                }
                                
                                Spacer()
                                
                                if userManager.currentUser?.isVerified == true {
                                    Image(systemName: "checkmark.seal.fill")
                                        .font(.title)
                                        .foregroundStyle(.green)
                                } else {
                                    Button("Verify") {
                                        showVerification = true
                                    }
                                    .font(.subheadline.bold())
                                    .foregroundStyle(.black)
                                    .padding(.horizontal, 16)
                                    .padding(.vertical, 8)
                                    .background(Color.white)
                                    .clipShape(Capsule())
                                }
                            }
                            .padding()
                        }
                        
                        Spacer(minLength: 50)
                    }
                    .padding(.horizontal, 24)
                }
            }
        }
        .onAppear {
            TipManager.shared.showTip(.trustScore, delay: 0.5)
            
            if let user = userManager.currentUser {
                username = user.username
                bio = user.bio
                location = user.location
                isoCategories = user.isoCategories
            }
        }
        .onChange(of: selectedItem) { newItem in
            Task {
                if let data = try? await newItem?.loadTransferable(type: Data.self),
                   let uiImage = UIImage(data: data) {
                    await MainActor.run {
                        selectedImage = uiImage
                    }
                }
            }
        }
        .sheet(isPresented: $showVerification) {
            VerificationView()
                .presentationDetents([.large])
                .presentationDragIndicator(.visible)
        }
    }
    
    // MARK: - Logic
    
    func toggleCategory(_ cat: String) {
        if isoCategories.contains(cat) {
            isoCategories.removeAll { $0 == cat }
        } else {
            isoCategories.append(cat)
        }
        Haptics.shared.playLight()
    }
    
    func fetchCurrentLocation() {
        isFindingLocation = true
        Haptics.shared.playMedium()
        
        Task {
            if let cityString = await locationManager.getCurrentCity() {
                await MainActor.run {
                    self.location = cityString
                    self.isFindingLocation = false
                    Haptics.shared.playSuccess()
                }
            } else {
                await MainActor.run {
                    self.isFindingLocation = false
                }
            }
        }
    }
    
    func saveProfile() {
        isSaving = true
        Task {
            await userManager.updateProfile(
                username: username,
                bio: bio,
                location: location,
                isoCategories: isoCategories
            )
            
            if let newImage = selectedImage {
                await userManager.updateAvatar(image: newImage)
            }
            
            try? await Task.sleep(nanoseconds: 500_000_000)
            
            await MainActor.run {
                isSaving = false
                Haptics.shared.playSuccess()
                dismiss()
            }
        }
    }
}
