import SwiftUI
import PhotosUI
import CoreLocation

struct AddItemView: View {
    // Dependencies
    @ObservedObject var userManager = UserManager.shared
    
    // Binding to control presentation
    @Binding var isPresented: Bool
    
    // Form State
    @State private var title = ""
    @State private var description = ""
    @State private var category = "Electronics"
    @State private var condition = "Good"
    @State private var estimatedValue = "" // Price Input
    
    // Donation Toggle
    @State private var isDonation = false
    
    // Image Handling
    @State private var selectedItem: PhotosPickerItem?
    @State private var selectedImage: UIImage?
    
    // Source Selection Sheets
    @State private var showCamera = false
    @State private var showPhotoPicker = false
    @State private var showSourceSelection = false
    
    // AI State
    @State private var isAnalyzing = false
    
    // Error & Loading State
    @State private var isSaving = false
    @State private var errorMessage: String?
    @State private var showErrorShake = false
    
    // Data Sources
    let categories = [
        "Electronics", "Video Games", "Fashion", "Shoes",
        "Books", "Sports", "Home & Garden", "Collectibles", "Other"
    ]
    let conditions = ["New", "Like New", "Good", "Fair", "Poor"]
    
    var body: some View {
        ZStack {
            // 1. Global Background
            LiquidBackground()
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // 2. Standardized Header (No Cancel, Left Aligned)
                HStack {
                    Text("New Listing")
                        .font(.system(size: 24, weight: .heavy, design: .rounded))
                        .foregroundStyle(.white)
                    
                    Spacer()
                    
                    if isSaving {
                        ProgressView().tint(.cyan)
                    } else {
                        Button("Post") {
                            saveItem()
                        }
                        .font(.headline.bold())
                        .foregroundStyle(.cyan)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 8)
                        .background(Color.cyan.opacity(0.1))
                        .clipShape(Capsule())
                        .disabled(title.isEmpty || selectedImage == nil)
                        .opacity((title.isEmpty || selectedImage == nil) ? 0.5 : 1)
                    }
                }
                .padding(.horizontal, 24)
                .padding(.top, 24)
                .padding(.bottom, 16)
                
                // 3. Error Banner
                if let error = errorMessage {
                    Text(error)
                        .font(.caption.bold())
                        .foregroundStyle(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.red.opacity(0.8))
                        .cornerRadius(8)
                        .padding(.horizontal)
                        .transition(.move(edge: .top))
                        .offset(x: showErrorShake ? 10 : 0)
                        .animation(.spring(response: 0.2, dampingFraction: 0.2), value: showErrorShake)
                }
                
                // 4. Main Scrollable Form
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 24) {
                        // Hero Image Picker
                        heroImageSection
                        
                        // Form Sections
                        VStack(spacing: 20) {
                            // Primary Info
                            GlassSection {
                                VStack(spacing: 16) {
                                    GlassTextField(placeholder: "What are you swapping?", text: $title, icon: "tag.fill")
                                    
                                    if !isDonation {
                                        HStack {
                                            Image(systemName: "dollarsign.circle.fill")
                                                .foregroundStyle(.white.opacity(0.5))
                                            TextField("Estimated Value", text: $estimatedValue)
                                                .keyboardType(.decimalPad)
                                                .foregroundStyle(.white)
                                        }
                                        .padding()
                                        .background(Color.white.opacity(0.05))
                                        .cornerRadius(12)
                                    }
                                    
                                    // Donation Toggle
                                    Toggle(isOn: $isDonation) {
                                        HStack {
                                            Image(systemName: "heart.fill")
                                                .foregroundStyle(.pink)
                                            VStack(alignment: .leading) {
                                                Text("Donate Item")
                                                    .font(.subheadline.bold())
                                                    .foregroundStyle(.white)
                                                Text("List as free")
                                                    .font(.caption)
                                                    .foregroundStyle(.white.opacity(0.6))
                                            }
                                        }
                                    }
                                    .toggleStyle(SwitchToggleStyle(tint: .pink))
                                }
                            }
                            
                            // Details
                            GlassSection {
                                VStack(spacing: 16) {
                                    GlassPicker(title: "Category", selection: $category, options: categories, icon: "square.grid.2x2.fill")
                                    
                                    Divider().background(Color.white.opacity(0.1))
                                    
                                    GlassPicker(title: "Condition", selection: $condition, options: conditions, icon: "star.fill")
                                }
                            }
                            
                            // Description
                            VStack(alignment: .leading, spacing: 8) {
                                Text("DESCRIPTION")
                                    .font(.caption.bold())
                                    .foregroundStyle(.white.opacity(0.6))
                                    .padding(.leading, 4)
                                
                                TextEditor(text: $description)
                                    .scrollContentBackground(.hidden)
                                    .frame(height: 120)
                                    .padding(12)
                                    .background(Color.black.opacity(0.2))
                                    .cornerRadius(16)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 16)
                                            .stroke(Color.white.opacity(0.1), lineWidth: 1)
                                    )
                                    .foregroundStyle(.white)
                            }
                        }
                        .padding(.horizontal, 20)
                        
                        Spacer(minLength: 100)
                    }
                    .padding(.top, 20)
                }
                .scrollDismissesKeyboard(.interactively)
            }
        }
        // ✨ NEW: Tap anywhere to dismiss keyboard (Preserved from previous update)
        .onTapGesture {
            hideKeyboard()
        }
        // Force Hide Gray Drag Bar
        .presentationDragIndicator(.hidden)
        // Action Sheets
        .confirmationDialog("Add Photo", isPresented: $showSourceSelection) {
            Button("Camera") { showCamera = true }
            Button("Photo Library") { showPhotoPicker = true }
            Button("Cancel", role: .cancel) { }
        }
        .fullScreenCover(isPresented: $showCamera) {
            CameraPicker(selectedImage: $selectedImage)
                .ignoresSafeArea()
        }
        .photosPicker(isPresented: $showPhotoPicker, selection: $selectedItem, matching: .images)
        .onChange(of: selectedItem) { newItem in
            loadAndAnalyzeImage(from: newItem)
        }
        // ✨ NEW: Automatically detect item content whenever the image changes
        // This covers BOTH Camera and Gallery selections
        .onChange(of: selectedImage) { newImage in
            if let img = newImage {
                analyzeImage(img)
            }
        }
    }
    
    // MARK: - Subviews
    
    private var heroImageSection: some View {
        Button(action: { showSourceSelection = true }) {
            ZStack {
                if let image = selectedImage {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFill()
                        .frame(height: 280)
                        .frame(maxWidth: .infinity)
                        .clipShape(RoundedRectangle(cornerRadius: 24))
                        .overlay(
                            RoundedRectangle(cornerRadius: 24)
                                .stroke(Color.white.opacity(0.1), lineWidth: 1)
                        )
                        .overlay(
                            Image(systemName: "pencil.circle.fill")
                                .font(.title)
                                .foregroundStyle(.white)
                                .shadow(radius: 4)
                                .padding(16),
                            alignment: .topTrailing
                        )
                } else {
                    RoundedRectangle(cornerRadius: 24)
                        .fill(Color.white.opacity(0.05))
                        .frame(height: 280)
                        .frame(maxWidth: .infinity)
                        .overlay(
                            RoundedRectangle(cornerRadius: 24)
                                .stroke(style: StrokeStyle(lineWidth: 2, dash: [8]))
                                .foregroundStyle(Color.white.opacity(0.2))
                        )
                        .overlay(
                            VStack(spacing: 12) {
                                Circle()
                                    .fill(Color.cyan.opacity(0.1))
                                    .frame(width: 80, height: 80)
                                    .overlay(
                                        Image(systemName: "camera.fill")
                                            .font(.system(size: 32))
                                            .foregroundStyle(.cyan)
                                    )
                                
                                Text("Add Photo")
                                    .font(.headline)
                                    .foregroundStyle(.white)
                                
                                Text("Tap to upload")
                                    .font(.caption)
                                    .foregroundStyle(.white.opacity(0.5))
                            }
                        )
                }
                
                if isAnalyzing {
                    ZStack {
                        Color.black.opacity(0.4)
                            .clipShape(RoundedRectangle(cornerRadius: 24))
                        VStack(spacing: 12) {
                            ProgressView().tint(.white)
                            Text("AI analyzing...")
                                .font(.caption.bold())
                                .foregroundStyle(.white)
                        }
                    }
                }
            }
            .padding(.horizontal, 20)
            .shadow(color: .black.opacity(0.2), radius: 20, y: 10)
        }
    }
    
    // MARK: - Helpers
    
    private func loadAndAnalyzeImage(from item: PhotosPickerItem?) {
        guard let item = item else { return }
        Task {
            if let data = try? await item.loadTransferable(type: Data.self),
               let uiImage = UIImage(data: data) {
                await MainActor.run {
                    selectedImage = uiImage
                    // Basic haptic
                    Haptics.shared.playLight()
                    // ✨ NOTE: removed explicit analyzeImage() call here
                    // It is now handled by .onChange(of: selectedImage)
                }
            }
        }
    }
    
    private func analyzeImage(_ image: UIImage) {
        isAnalyzing = true
        Task {
            do {
                // Assuming ImageAnalyzer is available in your project scope
                let result = try await ImageAnalyzer.analyze(image: image)
                await MainActor.run {
                    // Only auto-fill title if the user hasn't typed one yet
                    if self.title.isEmpty { self.title = result.suggestedTitle }
                    self.category = result.suggestedCategory
                    self.isAnalyzing = false
                    Haptics.shared.playSuccess()
                }
            } catch {
                await MainActor.run {
                    print("AI Analysis failed: \(error)")
                    self.isAnalyzing = false
                }
            }
        }
    }
    
    private func saveItem() {
        guard let image = selectedImage else { return }
        
        isSaving = true
        errorMessage = nil
        
        Task {
            do {
                let priceValue = isDonation ? 0.0 : (Double(estimatedValue) ?? 0.0)
                
                try await userManager.addItem(
                    title: title,
                    description: description,
                    image: image,
                    category: category,
                    condition: condition,
                    price: priceValue,
                    isDonation: isDonation
                )
                
                await MainActor.run {
                    Haptics.shared.playSuccess()
                    isSaving = false
                    isPresented = false
                }
            } catch {
                await MainActor.run {
                    Haptics.shared.playError()
                    errorMessage = "Failed to post: \(error.localizedDescription)"
                    showErrorShake = true
                    isSaving = false
                }
                // Reset shake after delay
                try? await Task.sleep(nanoseconds: 300_000_000)
                await MainActor.run { showErrorShake = false }
            }
        }
    }
}
