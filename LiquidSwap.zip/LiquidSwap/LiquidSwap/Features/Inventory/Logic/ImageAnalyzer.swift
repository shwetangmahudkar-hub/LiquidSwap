import Vision
import UIKit

struct ImageAnalyzer {
    
    // ✨ Define the result type expected by AddItemView
    struct AnalysisResult {
        let suggestedTitle: String
        let suggestedCategory: String
    }
    
    enum AnalysisError: Error {
        case invalidImage
        case processingFailed
    }
    
    // ✨ SMART FEATURE 1: Blocklist for vague terms
    // Vision often returns these generic terms. We want to ignore them to find the real object.
    private static let vaguenessBlocklist: Set<String> = [
        "structure", "product", "object", "artifact", "device",
        "implement", "container", "material", "design", "surface",
        "commodity", "instrument", "mechanism", "appliance", "equipment"
    ]
    
    /// Analyzes an image and returns a structured result with title and category
    static func analyze(image: UIImage) async throws -> AnalysisResult {
        guard let ciImage = CIImage(image: image) else {
            throw AnalysisError.invalidImage
        }
        
        let handler = VNImageRequestHandler(ciImage: ciImage, options: [:])
        
        return try await withCheckedThrowingContinuation { continuation in
            let request = VNClassifyImageRequest { request, error in
                if let error = error {
                    continuation.resume(throwing: error)
                    return
                }
                
                guard let observations = request.results as? [VNClassificationObservation] else {
                    continuation.resume(returning: AnalysisResult(suggestedTitle: "", suggestedCategory: "Other"))
                    return
                }
                
                // ✨ SMART FEATURE 2: Filter and Refine Labels
                // We keep lower confidence items (0.1) initially to check for specific matches like "sunglasses"
                // even if the AI is more confident that it looks like a "structure".
                let validLabels = observations
                    .filter { $0.confidence > 0.1 }
                    .map { $0.identifier.lowercased() }
                    .filter { !vaguenessBlocklist.contains($0) } // Remove "Structure", etc.
                
                // 1. Determine Title
                // Find the first high-confidence label that isn't blocked
                let titleCandidate = observations
                    .filter { $0.confidence > 0.4 } // We want the title to be fairly certain
                    .map { $0.identifier }
                    .filter { !vaguenessBlocklist.contains($0.lowercased()) }
                    .first
                
                let title = titleCandidate?.capitalized ?? ""
                
                // 2. Determine Category (Using the expanded brain)
                let category = categorize(labels: validLabels)
                
                let result = AnalysisResult(
                    suggestedTitle: title,
                    suggestedCategory: category
                )
                
                continuation.resume(returning: result)
            }
            
            do {
                try handler.perform([request])
            } catch {
                continuation.resume(throwing: error)
            }
        }
    }
    
    /// ✨ SMART FEATURE 3: Expanded Knowledge Base
    /// Maps Vision labels to App Categories with much deeper keyword lists
    private static func categorize(labels: [String]) -> String {
        // Iterate through all detected labels to find a match
        for label in labels {
            
            // 🎮 Electronics / Games
            if matches(label, ["computer", "phone", "screen", "monitor", "keyboard", "mouse", "laptop", "tablet", "camera", "lens", "headphone", "speaker", "console", "controller", "video game", "arcade", "television", "circuit"]) { return "Electronics" }
            
            // 👗 Fashion (Added Sunglasses/Accessories)
            if matches(label, ["clothing", "shirt", "dress", "jacket", "coat", "pants", "jeans", "sweater", "hoodie", "suit", "vest", "sunglasses", "glasses", "spectacles", "shades", "wallet", "purse", "bag", "handbag", "backpack", "watch", "jewelry", "necklace", "ring", "bracelet", "hat", "cap"]) { return "Fashion" }
            
            // 👟 Shoes
            if matches(label, ["shoe", "sneaker", "boot", "sandal", "heel", "loafer", "footwear", "clog"]) { return "Shoes" }
            
            // 📚 Books
            if matches(label, ["book", "novel", "paperback", "hardcover", "textbook", "magazine", "comic", "album", "notebook"]) { return "Books" }
            
            // ⚽ Sports
            if matches(label, ["ball", "racket", "bat", "bicycle", "bike", "helmet", "glove", "skate", "board", "surf", "ski", "snowboard", "dumbell", "weight", "gym", "jersey"]) { return "Sports" }
            
            // 🏠 Home & Garden
            if matches(label, ["furniture", "chair", "sofa", "couch", "table", "desk", "lamp", "light", "plant", "flower", "vase", "pot", "tool", "drill", "hammer", "saw", "garden", "lawn", "kitchen", "pan", "pot", "knife", "appliance", "fridge", "microwave"]) { return "Home & Garden" }
            
            // 🧸 Collectibles
            if matches(label, ["toy", "figurine", "lego", "action figure", "doll", "plush", "card", "coin", "stamp", "antique", "memorabilia", "funko"]) { return "Collectibles" }
            
            // 🎮 Video Games (Specific)
            if matches(label, ["nintendo", "playstation", "xbox", "sega", "gameboy", "cartridge"]) { return "Video Games" }
        }
        
        return "Other" // Default fallback
    }
    
    // Helper to keep the code clean
    private static func matches(_ label: String, _ keywords: [String]) -> Bool {
        for keyword in keywords {
            if label.contains(keyword) { return true }
        }
        return false
    }
}
