import SwiftUI
import MapKit

struct ProductDetailView: View {
    let item: TradeItem
    @Environment(\.dismiss) var dismiss
    
    // Dependencies
    @ObservedObject var userManager = UserManager.shared
    
    // UI State
    @State private var showReportActionSheet = false
    @State private var showReportConfirmation = false
    @State private var showOfferSheet = false
    @State private var showShareSheet = false
    @State private var showChatAlert = false
    
    // Data State
    @State private var offerAlreadyPending = false
    @State private var ownerProfile: UserProfile?
    @State private var ownerRating: Double = 0.0
    @State private var isLoadingOwner = true
    
    // Force show analytics toggle (from settings)
    @AppStorage("dev_forceShowAnalytics") private var forceShowAnalytics = false
    
    var body: some View {
        ZStack(alignment: .bottom) {
            // 1. Global Background
            LiquidBackground()
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // 2. Compact Pinned Header
                headerBar
                
                // 3. Scrollable Content
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 24) {
                        
                        // ✨ NEW: Compact "Spec Sheet" Header (Thumbnail + Title + Trust)
                        specSheetHeader
                        
                        // ✨ NEW: Horizontal Hype Analytics
                        hypeAnalyticsRow
                        
                        // ✨ NEW: Structured Details Grid
                        structuredDetailsSection
                        
                        // Cleaned Description
                        descriptionSection
                        
                        // ✨ FIXED: Map with Scrolling Conflict Resolved
                        mapSection
                        
                        Spacer(minLength: 120) // Bottom bar clearance
                    }
                    .padding(.top, 16)
                }
            }
            
            // 4. Floating Bottom Action Bar
            floatingActionBar
        }
        .navigationBarHidden(true)
        // Sheets
        .sheet(isPresented: $showShareSheet) {
            ShareSheet(items: ["Check out this \(item.title) on Swappr!"])
                .presentationDetents([.medium])
                .presentationDragIndicator(.visible)
        }
        .confirmationDialog("Options", isPresented: $showReportActionSheet) {
            Button("Report Inappropriate Content", role: .destructive) { submitReport(reason: "Inappropriate") }
            Button("Report Spam or Scam", role: .destructive) { submitReport(reason: "Spam") }
            Button("Cancel", role: .cancel) { }
        }
        .alert("Report Received", isPresented: $showReportConfirmation) {
            Button("Done", role: .cancel) { }
        } message: {
            Text("Thank you for keeping our community safe. We will review this report shortly.")
        }
        .sheet(isPresented: $showOfferSheet) {
            QuickOfferSheet(wantedItem: item)
                .presentationDetents([.medium, .large])
                .presentationDragIndicator(.visible)
        }
        .alert("Coming Soon", isPresented: $showChatAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text("Direct messaging will be available in the next update. Please make an offer to start a trade conversation.")
        }
        .onAppear {
            loadData()
        }
    }
    
    // MARK: - Section Components
    
    private var headerBar: some View {
        HStack {
            Text("Details")
                .font(.system(size: 24, weight: .heavy, design: .rounded))
                .foregroundStyle(.white)
            
            Spacer()
            
            // ✨ NEW: Clean Ellipsis Menu (Combines Share & Report)
            Menu {
                Button(action: { showShareSheet = true }) {
                    Label("Share Item", systemImage: "square.and.arrow.up")
                }
                Button(role: .destructive, action: { showReportActionSheet = true }) {
                    Label("Report Listing", systemImage: "flag")
                }
            } label: {
                Image(systemName: "ellipsis.circle.fill")
                    .font(.system(size: 24))
                    .foregroundStyle(.white.opacity(0.8))
                    .frame(width: 40, height: 40)
            }
        }
        .padding(.horizontal, 24)
        .padding(.top, 24)
        .padding(.bottom, 8)
    }
    
    private var specSheetHeader: some View {
        HStack(alignment: .top, spacing: 16) {
            // Compact Thumbnail Image
            AsyncImageView(filename: item.imageUrl)
                .scaledToFill()
                .frame(width: 80, height: 80)
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.2), lineWidth: 1))
                .shadow(color: .black.opacity(0.3), radius: 8, y: 4)
            
            VStack(alignment: .leading, spacing: 6) {
                // Title & Price Row
                HStack(alignment: .top) {
                    Text(item.title)
                        .font(.system(size: 20, weight: .heavy, design: .rounded))
                        .foregroundStyle(.white)
                        .lineLimit(2)
                    
                    Spacer()
                    
                    Text("$\(Int(item.price ?? 0.0))")
                        .font(.title3).bold()
                        .foregroundStyle(.cyan)
                }
                
                // Compact Trust Badge
                HStack(spacing: 4) {
                    Image(systemName: "person.crop.circle.badge.checkmark")
                        .font(.caption2)
                        .foregroundStyle(ownerProfile?.isVerified == true ? .cyan : .white.opacity(0.5))
                    
                    Text("Listed by \(ownerProfile?.username ?? item.ownerUsername ?? "Seller")")
                        .font(.caption.bold())
                        .foregroundStyle(.white.opacity(0.8))
                    
                    Text("•")
                        .font(.caption2)
                        .foregroundStyle(.white.opacity(0.4))
                        .padding(.horizontal, 2)
                    
                    Image(systemName: "star.fill")
                        .font(.caption2)
                        .foregroundStyle(.yellow)
                    Text(String(format: "%.1f", ownerRating))
                        .font(.caption.bold())
                        .foregroundStyle(.white.opacity(0.8))
                }
                .padding(.top, 2)
            }
        }
        .padding(.horizontal, 24)
    }
    
    private var hypeAnalyticsRow: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                // Re-using the logic from the Feed, rendered horizontally
                if item.isRare || forceShowAnalytics {
                    LiquidAnalyticPill(icon: "sparkles", text: "Rare Find", gradientColors: [.purple, .indigo], isPulsing: true)
                } else if Date().timeIntervalSince(item.createdAt) < 3600 {
                    LiquidAnalyticPill(icon: "clock.fill", text: "Fresh Drop", gradientColors: [.mint, .teal], isPulsing: false)
                }
                
                if item.heatIndex > 50 || forceShowAnalytics {
                    LiquidAnalyticPill(icon: "flame.fill", text: item.heatIndex > 500 ? "On Fire!" : "Trending", gradientColors: [.yellow, .orange, .red], isPulsing: false)
                }
                
                if item.offerCount > 0 || forceShowAnalytics {
                    LiquidAnalyticPill(icon: "hand.raised.fill", text: "\(item.offerCount) Offers", gradientColors: [.cyan, .blue], isPulsing: false)
                }
                
                if item.liveViewers > 0 || forceShowAnalytics {
                    LiquidAnalyticPill(icon: "eye.fill", text: "\(item.liveViewers) viewing", gradientColors: [.green, .mint], isPulsing: true)
                }
            }
            .padding(.horizontal, 24)
        }
    }
    
    private var structuredDetailsSection: some View {
        VStack(spacing: 0) {
            SpecRow(icon: "tag.fill", title: "Category", value: item.category, tint: .purple)
            
            Divider().background(Color.white.opacity(0.1)).padding(.leading, 56)
            
            SpecRow(icon: "sparkles", title: "Condition", value: item.condition, tint: conditionColor(item.condition))
            
            Divider().background(Color.white.opacity(0.1)).padding(.leading, 56)
            
            SpecRow(icon: "location.fill", title: "Distance", value: item.displayLocation, tint: .blue)
        }
        .padding(.vertical, 4)
        .background(Color.black.opacity(0.2))
        .cornerRadius(20)
        .padding(.horizontal, 24)
    }
    
    private var descriptionSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("About this item")
                .font(.headline)
                .foregroundStyle(.white.opacity(0.8))
            
            Text(item.description)
                .font(.subheadline)
                .foregroundStyle(.white.opacity(0.9))
                .lineSpacing(6)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 24)
    }
    
    private var mapSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            if let lat = item.latitude, let lon = item.longitude {
                ZStack(alignment: .bottomTrailing) {
                    Map(coordinateRegion: .constant(MKCoordinateRegion(
                        center: CLLocationCoordinate2D(latitude: lat, longitude: lon),
                        span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
                    )))
                    .allowsHitTesting(false) // ✨ FIXED: Resolves ScrollView conflict
                    .overlay(Color.black.opacity(0.2))
                    
                    Button(action: { openInMaps() }) {
                        Image(systemName: "arrow.up.right.diamond.fill")
                            .font(.system(size: 20))
                            .foregroundStyle(.white)
                            .padding(12)
                            .background(.ultraThinMaterial)
                            .clipShape(Circle())
                            .overlay(Circle().stroke(Color.white.opacity(0.2), lineWidth: 1))
                    }
                    .padding(12)
                }
                .frame(height: 140)
                .cornerRadius(20)
                .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white.opacity(0.1), lineWidth: 1))
                .padding(.horizontal, 24)
            }
        }
    }
    
    // MARK: - Floating Bar
    
    private var floatingActionBar: some View {
        VStack {
            Spacer()
            HStack(spacing: 16) {
                // Chat Button
                Button(action: { showChatAlert = true }) {
                    Image(systemName: "bubble.left.fill")
                        .font(.system(size: 20))
                        .foregroundStyle(.white)
                        .frame(width: 56, height: 56)
                        .background(.ultraThinMaterial)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.white.opacity(0.15), lineWidth: 1))
                }
                
                // Make Offer Button
                Button(action: {
                    if !offerAlreadyPending {
                        Haptics.shared.playMedium()
                        showOfferSheet = true
                    }
                }) {
                    HStack {
                        if offerAlreadyPending {
                            Image(systemName: "checkmark.circle.fill")
                            Text("Offer Pending")
                        } else {
                            Text("Make an Offer")
                            Image(systemName: "arrow.right")
                        }
                    }
                    .font(.headline.bold())
                    .foregroundStyle(offerAlreadyPending ? .white.opacity(0.6) : .black)
                    .frame(maxWidth: .infinity)
                    .frame(height: 56)
                    .background(offerAlreadyPending ? Color.gray.opacity(0.3) : Color.cyan)
                    .clipShape(Capsule())
                    .shadow(color: offerAlreadyPending ? .clear : .cyan.opacity(0.4), radius: 10, y: 5)
                }
                .disabled(offerAlreadyPending)
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 34)
            .padding(.top, 20)
            .background(
                LiquidBackground()
                    .opacity(0.95)
                    .mask(LinearGradient(colors: [.black, .black.opacity(0)], startPoint: .bottom, endPoint: .top))
                    .blur(radius: 10)
            )
        }
    }
    
    // MARK: - Logic
    
    func loadData() {
        checkIfOfferPending()
        
        // Optimistic loading
        if let username = item.ownerUsername {
            self.ownerProfile = UserProfile(
                id: item.ownerId, username: username, bio: "", location: "",
                avatarUrl: nil, isoCategories: [], isVerified: item.ownerIsVerified ?? false, isPremium: item.ownerIsPremium ?? false
            )
            if let rating = item.ownerRating {
                self.ownerRating = rating
                self.isLoadingOwner = false
                return
            }
        }
        
        Task {
            isLoadingOwner = true
            do {
                async let profileTask = DatabaseService.shared.fetchProfile(userId: item.ownerId)
                async let ratingTask = DatabaseService.shared.fetchUserRating(userId: item.ownerId)
                let (profile, rating) = try await (profileTask, ratingTask)
                
                await MainActor.run {
                    self.ownerProfile = profile
                    self.ownerRating = rating
                    self.isLoadingOwner = false
                }
            } catch {
                await MainActor.run { isLoadingOwner = false }
            }
        }
    }
    
    func checkIfOfferPending() {
        Task {
            let exists = await TradeManager.shared.hasPendingOffer(for: item.id)
            await MainActor.run { withAnimation { self.offerAlreadyPending = exists } }
        }
    }
    
    func submitReport(reason: String) {
        guard let userId = userManager.currentUser?.id else { return }
        Task {
            try? await DatabaseService.shared.reportItem(itemId: item.id, userId: userId, reason: reason)
            await MainActor.run { self.showReportConfirmation = true }
        }
    }
    
    func openInMaps() {
        guard let lat = item.latitude, let lon = item.longitude else { return }
        let coordinate = CLLocationCoordinate2D(latitude: lat, longitude: lon)
        let mapItem = MKMapItem(placemark: MKPlacemark(coordinate: coordinate))
        mapItem.name = "Trade Location"
        mapItem.openInMaps(launchOptions: [MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeDriving])
    }
    
    func conditionColor(_ condition: String) -> Color {
        switch condition.lowercased() {
        case "new": return .green
        case "like new": return .mint
        case "good": return .blue
        case "fair": return .orange
        case "poor": return .red
        default: return .gray
        }
    }
}

// MARK: - Helpers

// ✨ NEW: Clean "Spec Row" component for Structured Details
struct SpecRow: View {
    let icon: String
    let title: String
    let value: String
    let tint: Color
    
    var body: some View {
        HStack(spacing: 16) {
            ZStack {
                Circle()
                    .fill(tint.opacity(0.2))
                    .frame(width: 32, height: 32)
                
                Image(systemName: icon)
                    .font(.system(size: 14, weight: .bold))
                    .foregroundStyle(tint)
            }
            
            Text(title)
                .font(.subheadline)
                .foregroundStyle(.white.opacity(0.6))
            
            Spacer()
            
            Text(value)
                .font(.subheadline.bold())
                .foregroundStyle(.white)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
    }
}

struct ShareSheet: UIViewControllerRepresentable {
    var items: [Any]
    var applicationActivities: [UIActivity]? = nil
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: applicationActivities)
    }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
