import SwiftUI

struct FeedView: View {
    @Environment(\.colorScheme) private var colorScheme
    
    // MARK: - Dependencies
    @ObservedObject var feedManager = FeedManager.shared
    @ObservedObject var tradeManager = TradeManager.shared
    @ObservedObject var userManager = UserManager.shared
    @ObservedObject var progressionManager = ProgressionManager.shared
    @ObservedObject var tabManager = TabBarManager.shared
    
    // MARK: - Settings Preference
    @AppStorage("showLikeButton") private var showLikeButton = false
    
    // MARK: - State: Navigation
    @State private var selectedDetailItem: TradeItem?
    @State private var itemForQuickOffer: TradeItem?
    @State private var selectedProfileSheet: ProfileSheetWrapper?
    @State private var showProgressionView = false
    @State private var showSavedItems = false
    @State private var showFriendsList = false
    
    // MARK: - State: Animations
    @State private var showHeartOverlay = false
    @State private var heartScale: CGFloat = 0.5
    @State private var heartRotation: Double = 0
    @State private var dragOffsetY: CGFloat = 0
    @State private var emptyStatePulse = false
    
    // MARK: - State: Gamification (XP & Combo)
    @State private var xpToasts: [FeedXPToast] = []
    @State private var showAchievementHint = false
    @State private var achievementHintType: AchievementType?
    @State private var comboCount: Int = 0
    @State private var comboScale: CGFloat = 1.0
    @State private var lastActionTime: Date = Date()
    @State private var showLevelUp = false
    @State private var previousLevel: Int = 1
    @State private var showConfetti = false
    
    // MARK: - Adaptive Colors
    private var primaryText: Color {
        colorScheme == .dark ? .white : .black
    }
    
    private var secondaryText: Color {
        colorScheme == .dark ? .white.opacity(0.7) : .black.opacity(0.6)
    }
    
    // MARK: - Computed Props
    var currentItem: TradeItem? {
        feedManager.items.last
    }
    
    var bottomBarPadding: CGFloat {
        tabManager.isVisible ? 100 : 16
    }
    
    // MARK: - Body
    var body: some View {
        NavigationStack {
            if #available(iOS 17.0, *) {
                ZStack {
                    // 1. Global Background
                    LiquidBackground().ignoresSafeArea()
                    
                    // 2. Main Content
                    if feedManager.isLoading && feedManager.items.isEmpty {
                        ProgressView()
                            .tint(primaryText)
                            .scaleEffect(1.5)
                    } else if feedManager.items.isEmpty {
                        emptyStateView
                    } else {
                        // Background Long Press Gesture for Saved Items (When Button is Hidden)
                        ZStack {
                            cardStackLayer
                        }
                        .contentShape(Rectangle())
                        .onLongPressGesture(minimumDuration: 0.5) {
                            if !showLikeButton {
                                Haptics.shared.playMedium()
                                showSavedItems = true
                            }
                        }
                    }
                    
                    // 3. UI Overlays & Feedback
                    if showHeartOverlay {
                        heartAnimationLayer
                    }
                    
                    ForEach(xpToasts) { toast in
                        FeedXPToastView(toast: toast)
                            .zIndex(110)
                    }
                    
                    if comboCount >= 2 {
                        comboIndicatorLayer
                    }
                    
                    // 4. Bottom Info Layer (Analytics + Bar)
                    if let item = currentItem {
                        bottomInfoLayer(item: item)
                    }
                    
                    // 5. Celebrations & Errors
                    if showConfetti {
                        ConfettiCannon(count: 50).zIndex(199)
                    }
                    
                    if showLevelUp {
                        LevelUpCelebration(level: userManager.currentLevel) {
                            withAnimation { showLevelUp = false }
                        }
                        .zIndex(200)
                    }
                    
                    if let newAchievement = progressionManager.newlyUnlockedAchievement {
                        AchievementCelebrationOverlay(type: newAchievement) {
                            progressionManager.dismissCelebration()
                        }
                        .zIndex(201)
                    }
                    
                    if let error = feedManager.error {
                        errorToast(error)
                    }
                }
                .onAppear {
                    TipManager.shared.showTip(.swipeLoop, delay: 1.5)
                    Task { await feedManager.fetchSavedItems() }
                }
                .task {
                    previousLevel = userManager.currentLevel.tier
                    showRandomAchievementHint()
                }
                .onChange(of: userManager.currentUser?.id, initial: true) { _, newValue in
                    if newValue != nil && feedManager.items.isEmpty {
                        Task {
                            feedManager.isLoading = true
                            await feedManager.fetchFeed()
                        }
                    }
                }
                .onChange(of: userManager.currentLevel.tier) { newValue in
                    if newValue > previousLevel { triggerBigCelebration() }
                    previousLevel = newValue
                }
                // MARK: - Sheets
                .sheet(item: $selectedDetailItem) { item in
                    NavigationStack { ProductDetailView(item: item) }
                        .presentationDetents([.large])
                        .presentationDragIndicator(.visible)
                }
                .sheet(item: $itemForQuickOffer) { item in
                    QuickOfferSheet(wantedItem: item)
                        .presentationDetents([.medium, .large])
                }
                .sheet(item: $selectedProfileSheet) { wrapper in
                    NavigationStack { PublicProfileView(userId: wrapper.id) }
                        .presentationDetents([.large])
                        .presentationDragIndicator(.visible)
                }
                .sheet(isPresented: $showProgressionView) {
                    NavigationStack { ProgressionView() }
                        .presentationDetents([.large])
                        .presentationDragIndicator(.visible)
                }
                .sheet(isPresented: $showSavedItems) {
                    SavedItemsSheet()
                        .presentationDetents([.medium, .large])
                        .presentationDragIndicator(.visible)
                }
                .sheet(isPresented: $showFriendsList) {
                    FriendsListView()
                        .presentationDetents([.medium, .large])
                        .presentationDragIndicator(.visible)
                }
            } else {
                // Fallback for earlier iOS versions
            }
        }
    }
    
    // MARK: - Sub-Views (Local)
    
    private var cardStackLayer: some View {
        ForEach(feedManager.items.suffix(2)) { item in
            let isTop = feedManager.items.last?.id == item.id
            
            FullScreenItemCard(item: item)
                .zIndex(isTop ? 2 : 1)
                .offset(y: isTop ? dragOffsetY : 0)
                .scaleEffect(isTop ? 1.0 : 0.95)
                .opacity(isTop ? 1.0 : (dragOffsetY < -50 ? 0.0 : 1.0))
                .onTapGesture(count: 2) { if isTop { handleDoubleTap(item: item) } }
                .onTapGesture(count: 1) { if isTop { selectedDetailItem = item } }
                .gesture(isTop ? makeDragGesture(for: item) : nil)
        }
    }
    
    private var heartAnimationLayer: some View {
        Image(systemName: "heart.fill")
            .font(.system(size: 90))
            .foregroundStyle(LinearGradient(colors: [.pink, .red], startPoint: .topLeading, endPoint: .bottomTrailing))
            .shadow(color: .red.opacity(0.5), radius: 18)
            .scaleEffect(heartScale)
            .rotationEffect(.degrees(heartRotation))
            .transition(.scale.combined(with: .opacity))
            .zIndex(100)
    }
    
    private var comboIndicatorLayer: some View {
        VStack {
            Spacer()
            ComboIndicator(count: comboCount)
                .scaleEffect(comboScale)
                .rotationEffect(.degrees(Double.random(in: -3...3)))
                .padding(.bottom, 200)
                .id("combo-\(comboCount)")
        }
        .transition(.scale.combined(with: .opacity))
        .zIndex(50)
    }
    
    private func bottomInfoLayer(item: TradeItem) -> some View {
        VStack(spacing: 0) {
            Spacer()
            
            if showAchievementHint, let hintType = achievementHintType {
                AchievementHintBanner(type: hintType, progress: progressionManager.progress(for: hintType))
                    .padding(.horizontal, 12)
                    .padding(.bottom, 6)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
            
            // ✨ NEW: Analytics Stack (Left) & Heart Button (Right)
            HStack(alignment: .bottom) {
                
                // 1. LEFT: The new Vertical Analytics Stack
                FeedAnalyticsStack(item: item)
                    .padding(.bottom, 12)
                    .padding(.leading, 8)
                    .transition(.move(edge: .leading).combined(with: .opacity))
                
                Spacer()
                
                // 2. RIGHT: Floating Heart Button (If Enabled)
                if showLikeButton {
                    ZStack(alignment: .topTrailing) {
                        // Glassy Button
                        ZStack {
                            Circle()
                                .fill(.ultraThinMaterial)
                                .overlay(Circle().stroke(Color.white.opacity(0.3), lineWidth: 1))
                                .shadow(color: .black.opacity(0.2), radius: 8, y: 4)
                            
                            Image(systemName: "heart.fill")
                                .font(.system(size: 24, weight: .bold))
                                .foregroundStyle(LinearGradient(colors: [.pink, .red], startPoint: .topLeading, endPoint: .bottomTrailing))
                                .shadow(color: .red.opacity(0.4), radius: 4)
                        }
                        .frame(width: 56, height: 56)
                        
                        // Badge Count
                        if !feedManager.savedItems.isEmpty {
                            Text("\(feedManager.savedItems.count)")
                                .font(.system(size: 10, weight: .bold))
                                .foregroundStyle(.white)
                                .padding(5)
                                .background(Color.red)
                                .clipShape(Circle())
                                .overlay(Circle().stroke(Color.white, lineWidth: 2))
                                .offset(x: 4, y: -4)
                        }
                    }
                    .onTapGesture {
                        handleDoubleTap(item: item)
                    }
                    .onLongPressGesture(minimumDuration: 0.5) {
                        Haptics.shared.playMedium()
                        showSavedItems = true
                    }
                    .padding(.trailing, 20)
                    .padding(.bottom, 12)
                    .transition(.scale.combined(with: .opacity))
                }
            }
            
            // 3. BOTTOM: The Main Info Bar
            FeedBottomBar(
                item: item,
                onQuickOffer: {
                    itemForQuickOffer = item
                    awardXP(amount: 15, reason: "Offer Started")
                },
                onShowProgression: { showProgressionView = true },
                onShowFriends: { showFriendsList = true }
            )
            .padding(.horizontal, 12)
            .padding(.bottom, bottomBarPadding)
            .animation(.spring(response: 0.5, dampingFraction: 0.8), value: tabManager.isVisible)
        }
        .zIndex(5)
    }
    
    private func errorToast(_ error: String) -> some View {
        VStack {
            Spacer()
            Text(error)
                .appFont(DS.Font.caption, weight: .bold)
                .foregroundStyle(.white)
                .padding(.horizontal, 14)
                .padding(.vertical, 10)
                .background(Color.red.opacity(0.8))
                .cornerRadius(8)
                .padding(.bottom, 110)
        }
        .transition(.move(edge: .bottom))
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                feedManager.error = nil
            }
        }
    }
    
    private var emptyStateView: some View {
        VStack(spacing: 16) {
            Image(systemName: "checkmark.circle.fill")
                .font(.system(size: 70))
                .foregroundStyle(.cyan)
                .scaleEffect(emptyStatePulse ? 1.1 : 1.0)
                .opacity(emptyStatePulse ? 1.0 : 0.8)
                .animation(
                    .easeInOut(duration: 1.2).repeatForever(autoreverses: true),
                    value: emptyStatePulse
                )
                .onAppear {
                    emptyStatePulse = true
                }
            
            Text("All Caught Up!")
                .appFont(DS.Font.screenTitle, weight: .heavy)
                .foregroundStyle(primaryText)
            
            Text("You've viewed all nearby items.")
                .appFont(DS.Font.body)
                .foregroundStyle(secondaryText)
            
            Button("Refresh Feed") {
                Haptics.shared.playMedium()
                Task {
                    await feedManager.fetchFeed()
                }
            }
            .buttonStyle(.borderedProminent)
            .tint(.white.opacity(0.2))
            .clipShape(Capsule())
        }
    }
    
    // MARK: - Logic & Gestures
    
    private func makeDragGesture(for item: TradeItem) -> some Gesture {
        DragGesture()
            .onChanged { value in
                if value.translation.height < 0 {
                    dragOffsetY = value.translation.height
                } else {
                    dragOffsetY = value.translation.height / 5
                }
            }
            .onEnded { value in
                let horizontalAmount = value.translation.width
                let verticalAmount = value.translation.height
                
                if abs(horizontalAmount) > abs(verticalAmount) {
                    if horizontalAmount < -50 {
                        openOwnerProfile(item: item)
                    } else if horizontalAmount > 50 {
                        openProductDetail(item: item)
                    }
                    withAnimation(.spring()) { dragOffsetY = 0 }
                } else {
                    if verticalAmount < -150 {
                        dismissItem(item)
                    } else {
                        withAnimation(.spring()) { dragOffsetY = 0 }
                    }
                }
            }
    }
    
    private func awardXP(amount: Int, reason: String) {
        userManager.awardXP(amount: amount)
        let toast = FeedXPToast(amount: amount, reason: reason)
        withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) {
            xpToasts.append(toast)
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            withAnimation { xpToasts.removeAll { $0.id == toast.id } }
        }
        updateCombo()
    }
    
    private func updateCombo() {
        let now = Date()
        let timeSinceLastAction = now.timeIntervalSince(lastActionTime)
        
        if timeSinceLastAction < 3.0 {
            comboCount += 1
            withAnimation(.spring(response: 0.3, dampingFraction: 0.5)) { comboScale = 1.3 }
            withAnimation(.spring(response: 0.3, dampingFraction: 0.5).delay(0.1)) { comboScale = 1.0 }
            
            if comboCount == 5 {
                awardXP(amount: 25, reason: "5x Streak!")
                Haptics.shared.playSuccess()
            } else if comboCount == 10 {
                awardXP(amount: 50, reason: "UNSTOPPABLE!")
                triggerConfetti()
                Haptics.shared.playSuccess()
            } else {
                Haptics.shared.playLight()
            }
        } else {
            comboCount = 1
        }
        lastActionTime = now
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
            if Date().timeIntervalSince(self.lastActionTime) >= 3.0 {
                withAnimation(.easeOut) { self.comboCount = 0 }
            }
        }
    }
    
    private func triggerBigCelebration() {
        withAnimation(.spring()) { showLevelUp = true }
        triggerConfetti()
        Haptics.shared.playSuccess()
    }
    
    private func triggerConfetti() {
        withAnimation { showConfetti = true }
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
            withAnimation { showConfetti = false }
        }
    }
    
    private func dismissItem(_ item: TradeItem) {
        awardXP(amount: 2, reason: "Browsing")
        withAnimation(.easeOut(duration: 0.2)) { dragOffsetY = -1000 }
        Haptics.shared.playLight()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
            feedManager.removeItem(item.id)
            dragOffsetY = 0
        }
    }
    
    private func openOwnerProfile(item: TradeItem) {
        Haptics.shared.playMedium()
        selectedProfileSheet = ProfileSheetWrapper(id: item.ownerId)
        awardXP(amount: 5, reason: "Scouting")
    }
    
    private func openProductDetail(item: TradeItem) {
        Haptics.shared.playMedium()
        selectedDetailItem = item
        awardXP(amount: 5, reason: "Interest")
    }
    
    private func handleDoubleTap(item: TradeItem) {
        heartScale = 0.5
        heartRotation = Double.random(in: -15...15)
        withAnimation(.spring(response: 0.3, dampingFraction: 0.5)) {
            showHeartOverlay = true
            heartScale = 1.2
        }
        Haptics.shared.playSuccess()
        awardXP(amount: 10, reason: "Liked!")
        Task { await tradeManager.markAsInterested(item: item) }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
            withAnimation(.easeOut(duration: 0.2)) {
                showHeartOverlay = false
                heartScale = 0.1
            }
            dismissItem(item)
        }
    }
    
    private func showRandomAchievementHint() {
        guard let nextAchievement = progressionManager.nextAchievementToUnlock else { return }
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
            if Bool.random() && !progressionManager.isUnlocked(nextAchievement) {
                achievementHintType = nextAchievement
                withAnimation(.spring()) { showAchievementHint = true }
                Haptics.shared.playLight()
                DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
                    withAnimation { showAchievementHint = false }
                }
            }
        }
    }
}

// MARK: - Saved Items Sheet (Preserved)

struct SavedItemsSheet: View {
    @Environment(\.dismiss) var dismiss
    @ObservedObject var feedManager = FeedManager.shared
    @State private var selectedItem: TradeItem?
    
    // Alert State for Deletion
    @State private var itemToDelete: TradeItem?
    @State private var showDeleteConfirmation = false
    
    var body: some View {
        ZStack {
            LiquidBackground()
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Header (Centered)
                ZStack {
                    Text("Saved Items")
                        .appFont(DS.Font.screenTitle, weight: .heavy)
                        .foregroundStyle(.white)
                }
                .frame(maxWidth: .infinity)
                .padding(DS.Spacing.edge)
                .padding(.top, 10)
                
                if feedManager.isLoadingSaved {
                    Spacer()
                    ProgressView().tint(.white)
                    Spacer()
                } else if feedManager.savedItems.isEmpty {
                    VStack(spacing: 16) {
                        Spacer()
                        Image(systemName: "heart.slash")
                            .font(.system(size: 60))
                            .foregroundStyle(.white.opacity(0.3))
                        Text("No saved items yet")
                            .appFont(DS.Font.sectionHeader, weight: .bold)
                            .foregroundStyle(.white.opacity(0.7))
                        Text("Swipe right on items to save them for later.")
                            .appFont(DS.Font.caption)
                            .foregroundStyle(.white.opacity(0.5))
                        Spacer()
                    }
                } else {
                    List {
                        ForEach(feedManager.savedItems) { item in
                            SavedItemRow(item: item)
                                .listRowBackground(Color.clear)
                                .listRowSeparator(.hidden)
                                .listRowInsets(EdgeInsets(top: 4, leading: 12, bottom: 4, trailing: 12))
                                .onTapGesture {
                                    selectedItem = item
                                }
                                .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                                    Button(role: .destructive) {
                                        itemToDelete = item
                                        showDeleteConfirmation = true
                                    } label: {
                                        Label("Delete", systemImage: "trash")
                                    }
                                }
                        }
                    }
                    .listStyle(.plain)
                    .refreshable {
                        await feedManager.fetchSavedItems()
                    }
                }
            }
        }
        .onAppear {
            Task { await feedManager.fetchSavedItems() }
        }
        .sheet(item: $selectedItem) { item in
            ProductDetailView(item: item)
        }
        .alert("Remove Item?", isPresented: $showDeleteConfirmation, presenting: itemToDelete) { item in
            Button("Cancel", role: .cancel) { itemToDelete = nil }
            Button("Remove", role: .destructive) {
                Task {
                    await feedManager.removeSavedItem(item)
                    itemToDelete = nil
                }
            }
        } message: { item in
            Text("Are you sure you want to remove '\(item.title)' from your saved items?")
        }
    }
}

// Helper Row
struct SavedItemRow: View {
    let item: TradeItem
    var body: some View {
        GlassCard {
            HStack(spacing: 12) {
                AsyncImageView(filename: item.imageUrl)
                    .scaledToFill()
                    .frame(width: 50, height: 50)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                
                VStack(alignment: .leading, spacing: 2) {
                    Text(item.title)
                        .appFont(DS.Font.cardTitle, weight: .bold)
                        .foregroundStyle(.white)
                    
                    Text(item.condition)
                        .appFont(DS.Font.caption, weight: .medium)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(Color.cyan.opacity(0.2))
                        .cornerRadius(4)
                        .foregroundStyle(.cyan)
                }
                Spacer()
                Image(systemName: "chevron.right").foregroundStyle(.white.opacity(0.3))
            }
        }.padding(.vertical, 2)
    }
}

// MARK: - Helpers

struct ProfileSheetWrapper: Identifiable {
    let id: UUID
}

struct FeedXPToast: Identifiable, Equatable {
    let id = UUID()
    let amount: Int
    let reason: String
}

struct FeedXPToastView: View {
    let toast: FeedXPToast
    var body: some View {
        HStack(spacing: 8) {
            Text("+\(toast.amount) XP").font(.headline).foregroundStyle(.yellow)
            Text(toast.reason).font(.subheadline).foregroundStyle(.white)
        }
        .padding()
        .background(Color.black.opacity(0.8))
        .clipShape(Capsule())
        .overlay(Capsule().stroke(Color.white.opacity(0.2), lineWidth: 1))
        .shadow(radius: 10)
    }
}

struct AchievementUnlockHint: View {
    let achievementType: AchievementType
    var body: some View {
        HStack {
            Image(systemName: "trophy.fill").foregroundStyle(.yellow)
            VStack(alignment: .leading) {
                Text("Next Achievement:").font(.caption).foregroundStyle(.white.opacity(0.8))
                Text(achievementType.rawValue).font(.headline).foregroundStyle(.white)
            }
        }
        .padding()
        .background(Material.ultraThin)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.yellow.opacity(0.5), lineWidth: 1))
    }
}

struct ConfettiView: View {
    @State private var animate = false
    var body: some View {
        ZStack {
            ForEach(0..<20) { _ in
                Circle().fill(Color.random).frame(width: 8, height: 8)
                    .offset(x: CGFloat.random(in: -150...150), y: animate ? 300 : -300)
                    .animation(Animation.linear(duration: Double.random(in: 2...4)).repeatForever(autoreverses: false), value: animate)
            }
        }.onAppear { animate = true }
    }
}

extension Color {
    static var random: Color {
        Color(red: .random(in: 0...1), green: .random(in: 0...1), blue: .random(in: 0...1))
    }
}
