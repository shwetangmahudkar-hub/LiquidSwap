import SwiftUI
import MapKit

// MARK: - Models

struct RecyclingPoint: Identifiable {
    let id = UUID()
    let name: String
    let type: RecyclingType
    let coordinate: CLLocationCoordinate2D
    let address: String
    let mapItem: MKMapItem
    
    enum RecyclingType: String, CaseIterable {
        case general = "General"
        case batteries = "Batteries"
        case electronics = "E-Waste"
        case clothing = "Textiles"
        case glass = "Glass"
        
        var icon: String {
            switch self {
            case .general: return "trash.slash.fill"
            case .batteries: return "bolt.batteryblock.fill"
            case .electronics: return "desktopcomputer"
            case .clothing: return "tshirt.fill"
            case .glass: return "wineglass.fill"
            }
        }
        
        var color: UIColor {
            switch self {
            case .general: return .systemGreen
            case .batteries: return .systemOrange
            case .electronics: return .systemBlue
            case .clothing: return .systemPink
            case .glass: return .systemTeal
            }
        }
    }
}

struct SafeZone: Identifiable {
    let id = UUID()
    let name: String
    let type: ZoneType
    let coordinate: CLLocationCoordinate2D
    let address: String
    let mapItem: MKMapItem
    
    enum ZoneType: String, CaseIterable {
        case police = "Police Station"
        case fire = "Fire Station"
        case bank = "Bank / ATM"
        case publicPlace = "Public Location"
        
        var icon: String {
            switch self {
            case .police: return "shield.lefthalf.filled"
            case .fire: return "flame.fill"
            case .bank: return "dollarsign.shield.fill"
            case .publicPlace: return "building.columns.fill"
            }
        }
        
        var color: UIColor {
            switch self {
            case .police: return .systemBlue
            case .fire: return .systemRed
            case .bank: return .systemGreen
            case .publicPlace: return .systemPurple
            }
        }
        
        var safetyBadge: String {
            switch self {
            case .police, .fire: return "HIGH SECURITY"
            case .bank: return "MONITORED AREA"
            case .publicPlace: return "PUBLIC AREA"
            }
        }
    }
}

struct RepairService: Identifiable {
    let id = UUID()
    let name: String
    let type: RepairType
    let coordinate: CLLocationCoordinate2D
    let address: String
    let mapItem: MKMapItem
    
    enum RepairType: String, CaseIterable {
        case tailor = "Tailor"
        case cobbler = "Shoe Repair"
        case electronics = "Tech Repair"
        case bike = "Bike Shop"
        case general = "General Fix"
        
        var icon: String {
            switch self {
            case .tailor: return "scissors"
            case .cobbler: return "shoeprints.fill"
            case .electronics: return "screwdriver.fill"
            case .bike: return "bicycle"
            case .general: return "wrench.and.screwdriver.fill"
            }
        }
        
        var color: UIColor {
            switch self {
            case .tailor: return .systemPurple
            case .cobbler: return .systemBrown
            case .electronics: return .systemIndigo
            case .bike: return .systemRed
            case .general: return .systemGray
            }
        }
    }
}

struct DiscoverView: View {
    @ObservedObject var feedManager = FeedManager.shared
    @StateObject var locationManager = LocationManager.shared
    @ObservedObject var tabManager = TabBarManager.shared
    
    // Navigation State
    @State private var selectedTradeCard: TradeItem? // ✨ NEW: Controls the floating card
    @State private var selectedDetailItem: TradeItem?
    @State private var itemForQuickOffer: TradeItem? // ✨ NEW: For floating card offer button
    @State private var selectedRecyclingPoint: RecyclingPoint?
    @State private var selectedSafeZone: SafeZone?
    @State private var selectedRepairService: RepairService?
    
    // Search State
    @State private var isSearching = false
    @State private var lastSearchedRegion: MKCoordinateRegion?
    @State private var searchTask: Task<Void, Never>?
    
    // Live Data Containers
    @State private var liveRecyclingPoints: [RecyclingPoint] = []
    @State private var liveSafeZones: [SafeZone] = []
    @State private var liveRepairServices: [RepairService] = []
    
    // Filter State
    enum MapMode { case trades, recycling, safety, repair }
    @State private var mapMode: MapMode = .trades
    @State private var activeRecyclingFilter: RecyclingPoint.RecyclingType? = nil
    @State private var activeRepairFilter: RepairService.RepairType? = nil
    
    // Computed Filtered Lists
    var visibleRecyclingPoints: [RecyclingPoint] {
        guard let filter = activeRecyclingFilter else { return liveRecyclingPoints }
        return liveRecyclingPoints.filter { $0.type == filter }
    }
    
    var visibleRepairServices: [RepairService] {
        guard let filter = activeRepairFilter else { return liveRepairServices }
        return liveRepairServices.filter { $0.type == filter }
    }
    
    var body: some View {
        NavigationStack {
            ZStack(alignment: .bottom) {
                
                // 1. MAP LAYER
                ClusteredMapView(
                    mapMode: mapMode,
                    items: feedManager.items,
                    recyclingPoints: visibleRecyclingPoints,
                    safeZones: liveSafeZones,
                    repairServices: visibleRepairServices,
                    onRegionChange: { region in
                        performSearch(region: region)
                    },
                    onSelectItem: { item in
                        withAnimation(.spring(response: 0.4, dampingFraction: 0.7)) {
                            selectedTradeCard = item
                        }
                    },
                    onDeselectItem: {
                        withAnimation(.spring(response: 0.4, dampingFraction: 0.7)) {
                            selectedTradeCard = nil
                        }
                    },
                    onSelectRecycling: { selectedRecyclingPoint = $0 },
                    onSelectSafeZone: { selectedSafeZone = $0 },
                    onSelectRepair: { selectedRepairService = $0 }
                )
                .ignoresSafeArea()
                
                // 2. SEARCH BUTTON
                if mapMode != .trades && !isSearching {
                    VStack {
                        Button(action: {
                            if let region = lastSearchedRegion { performSearch(region: region) }
                        }) {
                            Label("Search This Area", systemImage: "arrow.clockwise")
                                .font(.caption.bold())
                                .foregroundStyle(.white)
                                .padding(.vertical, 8)
                                .padding(.horizontal, 16)
                                .background(.ultraThinMaterial)
                                .clipShape(Capsule())
                                .overlay(Capsule().stroke(Color.white.opacity(0.2), lineWidth: 1))
                                .shadow(radius: 4)
                        }
                        .padding(.top, 60)
                        Spacer()
                    }
                    .transition(.move(edge: .top).combined(with: .opacity))
                    .zIndex(1)
                }
                
                // 3. BOTTOM UI LAYER (Card OR Discover Pill)
                VStack {
                    if let item = selectedTradeCard {
                        // ✨ NEW: Floating Glass Card
                        TradeFloatingCard(
                            item: item,
                            onClose: {
                                withAnimation { selectedTradeCard = nil }
                            },
                            onDetails: {
                                selectedDetailItem = item
                            },
                            onOffer: {
                                itemForQuickOffer = item
                            }
                        )
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                    } else {
                        // ORIGINAL: Discover Pill
                        discoverPill
                            .transition(.move(edge: .bottom).combined(with: .opacity))
                    }
                }
                .padding(.bottom, tabManager.isVisible ? 100 : 16)
                .animation(.spring(response: 0.5, dampingFraction: 0.8), value: tabManager.isVisible)
            }
            .navigationBarHidden(true)
            .onAppear {
                Task {
                    await feedManager.fetchFeed()
                }
            }
            // Sheets
            .sheet(item: $selectedDetailItem) { item in
                NavigationStack { ProductDetailView(item: item) }
            }
            .sheet(item: $itemForQuickOffer) { item in
                QuickOfferSheet(wantedItem: item).presentationDetents([.medium, .large])
            }
            .sheet(item: $selectedRecyclingPoint) { point in RecyclingDetailSheet(point: point).presentationDetents([.height(400), .large]).presentationDragIndicator(.visible) }
            .sheet(item: $selectedSafeZone) { zone in SafeZoneDetailSheet(zone: zone).presentationDetents([.height(400), .large]).presentationDragIndicator(.visible) }
            .sheet(item: $selectedRepairService) { service in RepairDetailSheet(service: service).presentationDetents([.height(400), .large]).presentationDragIndicator(.visible) }
        }
    }
    
    // MARK: - Discover Pill View
    private var discoverPill: some View {
        VStack(spacing: 8) {
            HStack(spacing: 10) {
                HStack(spacing: 5) {
                    if #available(iOS 17.0, *) {
                        Image(systemName: headerIcon)
                            .font(.subheadline.bold())
                            .foregroundStyle(.cyan)
                            .contentTransition(.symbolEffect(.replace))
                        Text(headerTitle)
                            .font(.subheadline.bold())
                            .foregroundStyle(.white)
                            .contentTransition(.numericText())
                    } else {
                        Image(systemName: headerIcon).font(.subheadline.bold()).foregroundStyle(.cyan)
                        Text(headerTitle).font(.subheadline.bold()).foregroundStyle(.white)
                    }
                }
                
                Spacer()
                
                if isSearching { ProgressView().tint(.white).scaleEffect(0.6) }
                
                Rectangle().fill(Color.white.opacity(0.2)).frame(width: 1, height: 18)
                
                HStack(spacing: 0) {
                    ModeButton(icon: "cube.box.fill", isSelected: mapMode == .trades) { withAnimation { mapMode = .trades; selectedTradeCard = nil } }
                    ModeButton(icon: "leaf.fill", isSelected: mapMode == .recycling) { withAnimation { mapMode = .recycling; selectedTradeCard = nil } }
                    ModeButton(icon: "wrench.and.screwdriver.fill", isSelected: mapMode == .repair) { withAnimation { mapMode = .repair; selectedTradeCard = nil } }
                    ModeButton(icon: "shield.fill", isSelected: mapMode == .safety) { withAnimation { mapMode = .safety; selectedTradeCard = nil } }
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(.ultraThinMaterial)
            .clipShape(Capsule())
            .shadow(color: .black.opacity(0.25), radius: 8, y: 4)
            .overlay(Capsule().stroke(Color.white.opacity(0.1), lineWidth: 1))
            
            if mapMode == .recycling || mapMode == .repair {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 6) {
                        if mapMode == .recycling {
                            FilterChip(title: "All", icon: "square.grid.2x2.fill", isSelected: activeRecyclingFilter == nil) { withAnimation { activeRecyclingFilter = nil } }
                            ForEach(RecyclingPoint.RecyclingType.allCases, id: \.self) { type in
                                FilterChip(title: type.rawValue, icon: type.icon, isSelected: activeRecyclingFilter == type) { withAnimation { activeRecyclingFilter = type } }
                            }
                        } else {
                            FilterChip(title: "All", icon: "square.grid.2x2.fill", isSelected: activeRepairFilter == nil) { withAnimation { activeRepairFilter = nil } }
                            ForEach(RepairService.RepairType.allCases, id: \.self) { type in
                                FilterChip(title: type.rawValue, icon: type.icon, isSelected: activeRepairFilter == type) { withAnimation { activeRepairFilter = type } }
                            }
                        }
                    }
                    .padding(.horizontal, 2)
                    .padding(.vertical, 2)
                }
                .padding(4)
                .background(.ultraThinMaterial)
                .clipShape(Capsule())
                .shadow(color: .black.opacity(0.2), radius: 4)
                .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .padding(.horizontal, 12)
    }
    
    // MARK: - LIVE SEARCH LOGIC (DEBOUNCED)
    func performSearch(region: MKCoordinateRegion) {
        guard mapMode != .trades else { return }
        searchTask?.cancel()
        lastSearchedRegion = region
        
        searchTask = Task {
            try? await Task.sleep(nanoseconds: 1_000_000_000)
            if Task.isCancelled { return }
            await MainActor.run { self.isSearching = true }
            
            var queries: [String] = []
            switch mapMode {
            case .recycling: queries = ["Recycling Center", "Clothing Donation", "Goodwill", "E-Waste Dropoff"]
            case .repair: queries = ["Tailor", "Shoe Repair", "Electronics Repair", "Bike Shop"]
            case .safety: queries = ["Police Station", "Fire Station", "Bank", "Public Library", "Community Centre"]
            default: break
            }
            
            var newItems: [MKMapItem] = []
            for query in queries {
                if Task.isCancelled { return }
                let request = MKLocalSearch.Request()
                request.naturalLanguageQuery = query
                request.region = region
                if let response = try? await MKLocalSearch(request: request).start() { newItems.append(contentsOf: response.mapItems) }
            }
            
            if Task.isCancelled { return }
            
            await MainActor.run {
                switch mapMode {
                case .recycling:
                    self.liveRecyclingPoints = newItems.prefix(20).map { item in
                        let name = item.name?.lowercased() ?? ""
                        var type: RecyclingPoint.RecyclingType = .general
                        if name.contains("clothing") || name.contains("goodwill") { type = .clothing }
                        else if name.contains("tech") || name.contains("computer") { type = .electronics }
                        else if name.contains("bottle") { type = .glass }
                        return RecyclingPoint(name: item.name ?? "Recycling", type: type, coordinate: item.placemark.coordinate, address: item.placemark.title ?? "", mapItem: item)
                    }
                case .repair:
                    self.liveRepairServices = newItems.prefix(20).map { item in
                        let name = item.name?.lowercased() ?? ""
                        var type: RepairService.RepairType = .general
                        if name.contains("tailor") || name.contains("sew") { type = .tailor }
                        else if name.contains("shoe") || name.contains("cobbler") { type = .cobbler }
                        else if name.contains("phone") || name.contains("computer") || name.contains("tech") { type = .electronics }
                        else if name.contains("bike") || name.contains("cycle") { type = .bike }
                        return RepairService(name: item.name ?? "Repair Shop", type: type, coordinate: item.placemark.coordinate, address: item.placemark.title ?? "", mapItem: item)
                    }
                case .safety:
                    self.liveSafeZones = newItems.prefix(15).map { item in
                        let name = item.name?.lowercased() ?? ""
                        var type: SafeZone.ZoneType = .publicPlace
                        if item.pointOfInterestCategory == .police || name.contains("police") { type = .police }
                        else if item.pointOfInterestCategory == .fireStation || name.contains("fire") { type = .fire }
                        else if item.pointOfInterestCategory == .bank || name.contains("bank") { type = .bank }
                        return SafeZone(name: item.name ?? "Suggested Spot", type: type, coordinate: item.placemark.coordinate, address: item.placemark.title ?? "", mapItem: item)
                    }
                default: break
                }
                self.isSearching = false
            }
        }
    }
    
    var headerTitle: String {
        switch mapMode { case .trades: return "Discover"; case .recycling: return "Recycle"; case .safety: return "Meetups"; case .repair: return "Repair" }
    }
    var headerIcon: String {
        switch mapMode { case .trades: return "map.fill"; case .recycling: return "leaf.fill"; case .safety: return "shield.fill"; case .repair: return "wrench.and.screwdriver.fill" }
    }
}

// MARK: - ✨ NEW: Floating Trade Card
struct TradeFloatingCard: View {
    let item: TradeItem
    let onClose: () -> Void
    let onDetails: () -> Void
    let onOffer: () -> Void
    
    var body: some View {
        VStack(spacing: 16) {
            // Header Row
            HStack(alignment: .top, spacing: 12) {
                AsyncImageView(filename: item.imageUrl)
                    .scaledToFill()
                    .frame(width: 60, height: 60)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.white.opacity(0.2), lineWidth: 1))
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(item.title)
                        .font(.headline)
                        .foregroundStyle(.white)
                        .lineLimit(1)
                    
                    Text("$\(Int(item.price ?? 0))")
                        .font(.subheadline.bold())
                        .foregroundStyle(.cyan)
                    
                    // Trust Badge
                    HStack(spacing: 4) {
                        Image(systemName: "person.crop.circle.badge.checkmark")
                            .foregroundStyle(.cyan)
                            .font(.caption2)
                        Text(item.ownerUsername ?? "Seller")
                            .font(.caption)
                            .foregroundStyle(.white.opacity(0.7))
                    }
                }
                Spacer()
                
                Button(action: onClose) {
                    Image(systemName: "xmark.circle.fill")
                        .font(.title3)
                        .foregroundStyle(.white.opacity(0.4))
                }
            }
            
            // Hype Row - ✨ FIXED: isExpanded set to true
            HStack {
                if item.offerCount > 0 {
                    LiquidAnalyticPill(icon: "hand.raised.fill", text: "\(item.offerCount) Offers", gradientColors: [.cyan, .blue], isPulsing: false, isExpanded: true)
                } else if item.heatIndex > 50 {
                    LiquidAnalyticPill(icon: "flame.fill", text: "Trending", gradientColors: [.yellow, .orange, .red], isPulsing: false, isExpanded: true)
                }
                Spacer()
            }
            
            // Action Buttons
            HStack(spacing: 12) {
                Button(action: onDetails) {
                    Text("Details")
                        .font(.subheadline.bold())
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(Color.white.opacity(0.1))
                        .clipShape(Capsule())
                }
                
                Button(action: onOffer) {
                    Text("Make Offer")
                        .font(.subheadline.bold())
                        .foregroundStyle(.black)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(Color.cyan)
                        .clipShape(Capsule())
                        .shadow(color: .cyan.opacity(0.3), radius: 5, y: 2)
                }
            }
        }
        .padding(16)
        .background(
            LiquidBackground().opacity(0.95)
                .clipShape(RoundedRectangle(cornerRadius: 24))
                .overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.white.opacity(0.2), lineWidth: 1))
                .shadow(color: .black.opacity(0.5), radius: 20, y: 10)
        )
        .padding(.horizontal, 12)
    }
}

// MARK: - Clustered Map View

struct ClusteredMapView: UIViewRepresentable {
    let mapMode: DiscoverView.MapMode
    let items: [TradeItem]
    let recyclingPoints: [RecyclingPoint]
    let safeZones: [SafeZone]
    let repairServices: [RepairService]
    
    let onRegionChange: (MKCoordinateRegion) -> Void
    let onSelectItem: (TradeItem) -> Void
    let onDeselectItem: () -> Void // ✨ NEW: For closing the card
    let onSelectRecycling: (RecyclingPoint) -> Void
    let onSelectSafeZone: (SafeZone) -> Void
    let onSelectRepair: (RepairService) -> Void
    
    func makeUIView(context: Context) -> MKMapView {
        let mapView = MKMapView()
        mapView.delegate = context.coordinator
        mapView.showsUserLocation = true
        mapView.showsCompass = false
        
        if #available(iOS 16.0, *) {
            mapView.preferredConfiguration = MKStandardMapConfiguration(elevationStyle: .realistic, emphasisStyle: .default)
        }
        
        // Register Annotation Views
        mapView.register(TradeAnnotationView.self, forAnnotationViewWithReuseIdentifier: "trade-image") // ✨ NEW: Custom Image Marker
        mapView.register(MKMarkerAnnotationView.self, forAnnotationViewWithReuseIdentifier: "recycling")
        mapView.register(MKMarkerAnnotationView.self, forAnnotationViewWithReuseIdentifier: "safety")
        mapView.register(MKMarkerAnnotationView.self, forAnnotationViewWithReuseIdentifier: "repair")
        
        // CINEMATIC 3D CAMERA
        if let userLoc = LocationManager.shared.userLocation {
            let camera = MKMapCamera(lookingAtCenter: userLoc.coordinate, fromDistance: 1500, pitch: 45, heading: 0)
            mapView.setCamera(camera, animated: false)
        } else {
            let fallbackLoc = CLLocationCoordinate2D(latitude: 43.6532, longitude: -79.3832)
            let camera = MKMapCamera(lookingAtCenter: fallbackLoc, fromDistance: 1500, pitch: 45, heading: 0)
            mapView.setCamera(camera, animated: false)
        }
        return mapView
    }
    
    func updateUIView(_ mapView: MKMapView, context: Context) {
        let currentAnnotations = mapView.annotations.compactMap { $0 as? UnifiedAnnotation }
        var newAnnotations: [UnifiedAnnotation] = []
        let newOverlays: [MKOverlay] = []
        
        if mapMode == .trades {
            newAnnotations = items.map { UnifiedAnnotation(item: $0) }
        } else if mapMode == .recycling {
            newAnnotations = recyclingPoints.map { UnifiedAnnotation(point: $0) }
        } else if mapMode == .safety {
            newAnnotations = safeZones.map { UnifiedAnnotation(zone: $0) }
        } else if mapMode == .repair {
            newAnnotations = repairServices.map { UnifiedAnnotation(service: $0) }
        }
        
        let currentIDs = Set(currentAnnotations.map { $0.id })
        let newIDs = Set(newAnnotations.map { $0.id })
        
        if currentIDs != newIDs {
            mapView.removeAnnotations(mapView.annotations)
            mapView.addAnnotations(newAnnotations)
            mapView.removeOverlays(mapView.overlays)
            if !newOverlays.isEmpty { mapView.addOverlays(newOverlays) }
        }
    }
    
    func makeCoordinator() -> Coordinator { Coordinator(parent: self) }
    
    class Coordinator: NSObject, MKMapViewDelegate {
        var parent: ClusteredMapView
        init(parent: ClusteredMapView) { self.parent = parent }
        
        func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
            guard let annotation = annotation as? UnifiedAnnotation else { return nil }
            
            // ✨ UPGRADED: Routing trades to the new custom image view
            if case .trade = annotation.type {
                let view = mapView.dequeueReusableAnnotationView(withIdentifier: "trade-image", for: annotation) as? TradeAnnotationView
                    ?? TradeAnnotationView(annotation: annotation, reuseIdentifier: "trade-image")
                view.annotation = annotation
                return view
            }
            
            // Standard MKMarkerAnnotationView for infrastructure
            var identifier = "generic"; var clusterID = "generic-cluster"; var glyphImage = "mappin"; var color = UIColor.gray
            switch annotation.type {
            case .recycling(let p): identifier = "recycling"; clusterID = "recycling-cluster"; glyphImage = p.type.icon; color = p.type.color
            case .safety(let z): identifier = "safety"; clusterID = "safety-cluster"; glyphImage = z.type.icon; color = z.type.color
            case .repair(let r): identifier = "repair"; clusterID = "repair-cluster"; glyphImage = r.type.icon; color = r.type.color
            default: break
            }
            
            let view = mapView.dequeueReusableAnnotationView(withIdentifier: identifier, for: annotation) as? MKMarkerAnnotationView
                ?? MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            view.annotation = annotation
            view.markerTintColor = color
            view.glyphImage = UIImage(systemName: glyphImage)
            view.clusteringIdentifier = clusterID
            view.displayPriority = .defaultHigh
            return view
        }
        
        func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
            guard let annotation = view.annotation as? UnifiedAnnotation else { return }
            
            if case .trade(let item) = annotation.type {
                // Do NOT deselect immediately for trades, we want the marker to stay "Popped"
                parent.onSelectItem(item)
            } else {
                mapView.deselectAnnotation(annotation, animated: true)
                switch annotation.type {
                case .recycling(let point): parent.onSelectRecycling(point)
                case .safety(let zone): parent.onSelectSafeZone(zone)
                case .repair(let service): parent.onSelectRepair(service)
                default: break
                }
            }
        }
        
        // ✨ NEW: Detects when the user taps away from the pin
        func mapView(_ mapView: MKMapView, didDeselect view: MKAnnotationView) {
            guard let annotation = view.annotation as? UnifiedAnnotation else { return }
            if case .trade = annotation.type {
                parent.onDeselectItem()
            }
        }
        
        func mapView(_ mapView: MKMapView, regionDidChangeAnimated animated: Bool) {
            parent.onRegionChange(mapView.region)
        }
    }
}

// MARK: - ✨ NEW: Custom Image Map Marker

class TradeAnnotationView: MKAnnotationView {
    private let imageView = UIImageView()
    private let borderView = UIView()
    // Lightweight cache to keep the map smooth
    static var imageCache = NSCache<NSString, UIImage>()
    
    override init(annotation: MKAnnotation?, reuseIdentifier: String?) {
        super.init(annotation: annotation, reuseIdentifier: reuseIdentifier)
        setup()
    }
    
    required init?(coder aDecoder: NSCoder) { fatalError() }
    
    private func setup() {
        frame = CGRect(x: 0, y: 0, width: 44, height: 44)
        centerOffset = CGPoint(x: 0, y: -22) // Anchor to bottom
        
        borderView.frame = bounds
        borderView.layer.cornerRadius = 22
        borderView.layer.borderWidth = 2.5
        borderView.layer.borderColor = UIColor.cyan.cgColor
        borderView.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        borderView.layer.shadowColor = UIColor.black.cgColor
        borderView.layer.shadowOpacity = 0.5
        borderView.layer.shadowRadius = 4
        borderView.layer.shadowOffset = CGSize(width: 0, height: 2)
        addSubview(borderView)
        
        imageView.frame = bounds.insetBy(dx: 2.5, dy: 2.5)
        imageView.layer.cornerRadius = 19.5
        imageView.clipsToBounds = true
        imageView.contentMode = .scaleAspectFill
        borderView.addSubview(imageView)
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        imageView.image = UIImage(systemName: "shippingbox.fill")
        imageView.tintColor = .white
        imageView.contentMode = .center
        transform = .identity
        borderView.layer.borderColor = UIColor.cyan.cgColor
    }
    
    override var annotation: MKAnnotation? {
        willSet {
            guard let unified = newValue as? UnifiedAnnotation,
                  case .trade(let item) = unified.type else { return }
            
            clusteringIdentifier = "trade-cluster"
            displayPriority = .defaultHigh
            
            // Set Placeholder
            imageView.image = UIImage(systemName: "shippingbox.fill")
            imageView.tintColor = .white
            imageView.contentMode = .center
            
            // Asynchronously load the real thumbnail
            if let urlString = item.imageUrl, let url = URL(string: urlString) {
                if let cached = TradeAnnotationView.imageCache.object(forKey: urlString as NSString) {
                    imageView.image = cached
                    imageView.contentMode = .scaleAspectFill
                } else {
                    URLSession.shared.dataTask(with: url) { [weak self] data, _, _ in
                        guard let data = data, let image = UIImage(data: data) else { return }
                        TradeAnnotationView.imageCache.setObject(image, forKey: urlString as NSString)
                        DispatchQueue.main.async {
                            // Ensure we are still showing the right pin (recycling views)
                            if self?.annotation === newValue {
                                self?.imageView.image = image
                                self?.imageView.contentMode = .scaleAspectFill
                            }
                        }
                    }.resume()
                }
            }
        }
    }
    
    // ✨ NEW: Animate map pin when tapped
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        let scale: CGFloat = selected ? 1.3 : 1.0
        let color: CGColor = selected ? UIColor.white.cgColor : UIColor.cyan.cgColor
        
        if animated {
            UIView.animate(withDuration: 0.4, delay: 0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.5) {
                self.transform = CGAffineTransform(scaleX: scale, y: scale)
                self.borderView.layer.borderColor = color
            }
        } else {
            self.transform = CGAffineTransform(scaleX: scale, y: scale)
            self.borderView.layer.borderColor = color
        }
    }
}

// MARK: - Annotation Wrapper
class UnifiedAnnotation: NSObject, MKAnnotation {
    let id: UUID; let coordinate: CLLocationCoordinate2D; let title: String?; let type: AnnotationType
    enum AnnotationType { case trade(TradeItem); case recycling(RecyclingPoint); case safety(SafeZone); case repair(RepairService) }
    init(item: TradeItem) { self.id = item.id; self.coordinate = CLLocationCoordinate2D(latitude: item.latitude ?? 0, longitude: item.longitude ?? 0); self.title = item.title; self.type = .trade(item) }
    init(point: RecyclingPoint) { self.id = point.id; self.coordinate = point.coordinate; self.title = point.name; self.type = .recycling(point) }
    init(zone: SafeZone) { self.id = zone.id; self.coordinate = zone.coordinate; self.title = zone.name; self.type = .safety(zone) }
    init(service: RepairService) { self.id = service.id; self.coordinate = service.coordinate; self.title = service.name; self.type = .repair(service) }
}

// MARK: - Subviews
struct ModeButton: View {
    let icon: String; let isSelected: Bool; let action: () -> Void
    var body: some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.caption)
                .padding(8)
                .background(isSelected ? Color.white : Color.clear)
                .foregroundStyle(isSelected ? .black : .white.opacity(0.6))
                .clipShape(Circle())
        }
    }
}

struct FilterChip: View {
    let title: String; let icon: String; let isSelected: Bool; let action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack(spacing: 3) {
                Image(systemName: icon)
                Text(title)
            }
            .font(.caption2.bold())
            .padding(.vertical, 5)
            .padding(.horizontal, 8)
            .background(isSelected ? Color.cyan : Color.white.opacity(0.1))
            .foregroundStyle(isSelected ? .black : .white)
            .clipShape(Capsule())
        }
    }
}

// MARK: - Look Around
struct SafeLookAroundView: View {
    let mapItem: MKMapItem?
    @State private var scene: MKLookAroundScene?
    @State private var hasLookAround: Bool = false
    @State private var isLoading: Bool = true
    
    var body: some View {
        Group {
            if isLoading {
                ZStack {
                    RoundedRectangle(cornerRadius: 14).fill(Color.black.opacity(0.2))
                    ProgressView()
                }
            } else if let scene = scene, hasLookAround {
                if #available(iOS 17.0, *) {
                    LookAroundPreview(initialScene: scene)
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                        .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.white.opacity(0.1), lineWidth: 1))
                } else {
                    LegacyLookAroundView(scene: scene)
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                }
            } else {
                ZStack {
                    RoundedRectangle(cornerRadius: 14).fill(Color.black.opacity(0.1))
                    VStack(spacing: 6) {
                        Image(systemName: "eye.slash.fill").font(.title2).foregroundStyle(.white.opacity(0.3))
                        Text("No Preview Available").font(.caption2).foregroundStyle(.white.opacity(0.5))
                    }
                }
            }
        }
        .task(id: mapItem) { await fetchScene() }
    }
    
    private func fetchScene() async {
        guard let mapItem = mapItem else { isLoading = false; return }
        let request = MKLookAroundSceneRequest(mapItem: mapItem)
        do {
            if let s = try await request.scene { self.scene = s; self.hasLookAround = true } else { self.hasLookAround = false }
        } catch { self.hasLookAround = false }
        withAnimation { self.isLoading = false }
    }
}

struct LegacyLookAroundView: UIViewControllerRepresentable {
    let scene: MKLookAroundScene
    func makeUIViewController(context: Context) -> MKLookAroundViewController { MKLookAroundViewController(scene: scene) }
    func updateUIViewController(_ uiViewController: MKLookAroundViewController, context: Context) { uiViewController.scene = scene }
}

// MARK: - Sheets

struct RecyclingDetailSheet: View {
    let point: RecyclingPoint
    var body: some View {
        StandardDetailLayout(icon: point.type.icon, color: Color(uiColor: point.type.color), title: point.name, badge: point.type.rawValue, address: point.address, mapItem: point.mapItem)
    }
}

struct SafeZoneDetailSheet: View {
    let zone: SafeZone
    var body: some View {
        StandardDetailLayout(icon: zone.type.icon, color: Color(uiColor: zone.type.color), title: zone.name, badge: zone.type.safetyBadge, address: zone.address, isVerified: false, mapItem: zone.mapItem)
    }
}

struct RepairDetailSheet: View {
    let service: RepairService
    var body: some View {
        StandardDetailLayout(icon: service.type.icon, color: Color(uiColor: service.type.color), title: service.name, badge: service.type.rawValue, address: service.address, mapItem: service.mapItem)
    }
}

struct StandardDetailLayout: View {
    @Environment(\.colorScheme) private var colorScheme
    let icon: String; let color: Color; let title: String; let badge: String; let address: String; var isVerified: Bool = false; let mapItem: MKMapItem?
    
    private var primaryText: Color { colorScheme == .dark ? .white : .black }
    private var secondaryText: Color { colorScheme == .dark ? .white.opacity(0.9) : .black.opacity(0.8) }
    
    var body: some View {
        ZStack {
            LiquidBackground().opacity(0.3)
            VStack(spacing: 0) {
                Capsule().fill(Color.white.opacity(0.2)).frame(width: 36, height: 4).padding(.top, 8).padding(.bottom, 14)
                SafeLookAroundView(mapItem: mapItem).frame(height: 130).padding(.horizontal, 12).padding(.bottom, 12)
                
                HStack(spacing: 12) {
                    ZStack { Circle().fill(color.opacity(0.2)).frame(width: 44, height: 44); Image(systemName: icon).font(.title3).foregroundStyle(color) }
                    VStack(alignment: .leading, spacing: 3) {
                        HStack { Text(title).font(.subheadline.bold()).foregroundStyle(primaryText).lineLimit(1); if isVerified { Image(systemName: "checkmark.seal.fill").foregroundStyle(.cyan) } }
                        Text(badge).font(.caption2.bold()).padding(.horizontal, 6).padding(.vertical, 2).background(color.opacity(0.2)).foregroundStyle(color).cornerRadius(4)
                    }
                    Spacer()
                }.padding(.horizontal, 16)
                
                Divider().background(Color.white.opacity(0.1)).padding(.vertical, 12)
                
                VStack(spacing: 10) {
                    HStack { Image(systemName: "mappin.and.ellipse").foregroundStyle(.gray).frame(width: 18); Text(address).font(.caption).foregroundStyle(secondaryText).lineLimit(1); Spacer() }
                    if let phone = mapItem?.phoneNumber { HStack { Image(systemName: "phone.fill").foregroundStyle(.gray).frame(width: 18); Text(phone).font(.caption).foregroundStyle(secondaryText); Spacer() } }
                    if let url = mapItem?.url { HStack { Image(systemName: "link").foregroundStyle(.gray).frame(width: 18); Text(url.host ?? "Website").font(.caption).foregroundStyle(.cyan).underline(); Spacer() } }
                }.padding(.horizontal, 16)
                Spacer()
                
                HStack(spacing: 10) {
                    Button(action: { mapItem?.openInMaps(launchOptions: [MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeDriving]) }) {
                        VStack(spacing: 4) { Image(systemName: "car.fill").font(.subheadline); Text("Go").font(.caption2.bold()) }.frame(maxWidth: .infinity).frame(height: 52).background(Color.blue).foregroundStyle(.white).cornerRadius(10)
                    }
                    if let phone = mapItem?.phoneNumber {
                        Button(action: { if let url = URL(string: "tel://\(phone.filter{!$0.isWhitespace})") { UIApplication.shared.open(url) } }) {
                            VStack(spacing: 4) { Image(systemName: "phone.fill").font(.subheadline); Text("Call").font(.caption2.bold()) }.frame(maxWidth: .infinity).frame(height: 52).background(Color.white.opacity(0.1)).foregroundStyle(.green).cornerRadius(10)
                        }
                    }
                    if let url = mapItem?.url {
                        Button(action: { UIApplication.shared.open(url) }) {
                            VStack(spacing: 4) { Image(systemName: "globe").font(.subheadline); Text("Web").font(.caption2.bold()) }.frame(maxWidth: .infinity).frame(height: 52).background(Color.white.opacity(0.1)).foregroundStyle(.cyan).cornerRadius(10)
                        }
                    }
                    Button(action: { mapItem?.openInMaps() }) {
                        VStack(spacing: 4) { Image(systemName: "info.circle").font(.subheadline); Text("More").font(.caption2.bold()) }.frame(maxWidth: .infinity).frame(height: 52).background(Color.white.opacity(0.1)).foregroundStyle(.gray).cornerRadius(10)
                    }
                }.padding(.horizontal, 12).padding(.bottom, 8)
            }
        }
    }
}
