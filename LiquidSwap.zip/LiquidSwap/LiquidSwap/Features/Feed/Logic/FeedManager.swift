import Foundation
import Combine
import SwiftUI
import CoreLocation
import Supabase

@MainActor
class FeedManager: ObservableObject {
    // Singleton Instance
    static let shared = FeedManager()
    
    // MARK: - Published State
    @Published var items: [TradeItem] = []
    @Published var savedItems: [TradeItem] = [] // Stores full items for "Saved" tab
    @Published var savedItemIds: Set<UUID> = [] // Helper for quick lookup
    
    @Published var isLoading = false
    @Published var isLoadingSaved = false
    @Published var error: String?
    @Published var debugInfo: String = "Initializing..."
    
    // MARK: - Pagination State
    private var currentPage = 0
    private let pageSize = 10
    private var canLoadMore = true
    private var isFetchingNextPage = false
    
    // Dependencies
    private let db = DatabaseService.shared
    private let client = SupabaseConfig.client
    private let locationManager = LocationManager.shared
    private var userManager: UserManager { UserManager.shared }
    
    private var cancellables = Set<AnyCancellable>()
    
    // Private init to enforce singleton usage
    private init() {
        // Reload feed when location changes significantly
        locationManager.$userLocation
            .debounce(for: .seconds(5), scheduler: RunLoop.main)
            .sink { _ in
                 // Location updates handled silently to avoid refreshing while swiping
            }
            .store(in: &cancellables)
    }
    
    // MARK: - Public Actions
    
    /// Called on App Launch or Pull-to-Refresh
    func fetchFeed() async {
        self.isLoading = true
        self.error = nil
        self.items = [] // Clear existing items
        self.currentPage = 0
        self.canLoadMore = true
        
        // 1. Load Saved IDs first (for filtering)
        await fetchSavedItems()
        
        // 2. Load First Batch
        await loadBatch()
        
        self.isLoading = false
    }
    
    /// Called when the card stack is getting low (Lazy Loading)
    func loadMoreIfNeeded() {
        guard !isLoading && !isFetchingNextPage && canLoadMore else { return }
        
        // Trigger if we have fewer than 3 items left
        if items.count < 3 {
            Task { await loadBatch() }
        }
    }
    
    // ✨ COMPATIBILITY: Required by Swipe Deck Logic
    func removeItem(_ id: UUID) {
        withAnimation {
            items.removeAll { $0.id == id }
        }
        loadMoreIfNeeded()
    }
    
    // Overload for object
    func removeItem(_ item: TradeItem) {
        removeItem(item.id)
    }
    
    // MARK: - Saved Items / Likes
    
    func fetchSavedItems() async {
        guard let userId = userManager.currentUser?.id else { return }
        self.isLoadingSaved = true
        
        do {
            let items = try await db.fetchLikedItems(userId: userId)
            self.savedItems = items
            self.savedItemIds = Set(items.map { $0.id })
        } catch {
            print("❌ Error fetching saved items: \(error)")
        }
        
        self.isLoadingSaved = false
    }
    
    func toggleSave(item: TradeItem) async {
        guard let userId = userManager.currentUser?.id else { return }
        
        let isSaved = savedItemIds.contains(item.id)
        
        // Optimistic UI Update
        if isSaved {
            savedItemIds.remove(item.id)
            savedItems.removeAll { $0.id == item.id }
        } else {
            savedItemIds.insert(item.id)
            savedItems.append(item)
            Haptics.shared.playSuccess()
        }
        
        // DB Operation
        do {
            if isSaved {
                try await db.deleteLike(userId: userId, itemId: item.id)
            } else {
                 try await client.from("likes").insert(["user_id": userId, "item_id": item.id]).execute()
            }
        } catch {
            print("❌ Failed to toggle save: \(error)")
            // Revert on error
            await fetchSavedItems()
        }
    }
    
    // ✨ COMPATIBILITY: Required by FeedView Saved Sheet
    func removeSavedItem(_ item: TradeItem) async {
        await toggleSave(item: item)
    }
    
    func isItemSaved(_ item: TradeItem) -> Bool {
        return savedItemIds.contains(item.id)
    }
    
    // MARK: - Core Loading Logic
    
    private func loadBatch() async {
        guard canLoadMore else { return }
        self.isFetchingNextPage = true
        self.debugInfo = "Loading Page \(currentPage)..."
        
        guard let userId = userManager.currentUser?.id else {
            self.debugInfo = "Wait: User not logged in"
            self.isFetchingNextPage = false
            return
        }
        
        // Context Data
        let userIsoCategories = userManager.currentUser?.isoCategories ?? []
        // ✨ PRIVACY CHECK 1: Get Blocked IDs
        let blockedIDs = userManager.blockedUserIds
        let currentUserLocation = locationManager.userLocation
        
        do {
            // 1. Fetch Raw Items
            let fetchedItems = try await db.fetchFeedItems(page: currentPage, pageSize: pageSize)
            
            if fetchedItems.count < pageSize {
                self.canLoadMore = false
            }
            self.currentPage += 1
            
            // 2. Pre-Filter (Mine, Blocked, Saved)
            let visibleItems = fetchedItems.filter { item in
                let isMine = item.ownerId == userId
                let isLiked = savedItemIds.contains(item.id)
                // ✨ PRIVACY CHECK 2: Filter Blocked Users
                let isBlocked = blockedIDs.contains(item.ownerId)
                return !isMine && !isLiked && !isBlocked
            }
            
            if visibleItems.isEmpty && canLoadMore {
                print("⚠️ Page empty after filtering. Fetching next...")
                self.isFetchingNextPage = false
                await loadBatch()
                return
            }
            
            // 3. Batch Hydration (Profiles)
            let ownerIds = Array(Set(visibleItems.map { $0.ownerId }))
            let profiles = try? await db.fetchProfiles(userIds: ownerIds)
            let profileMap = Dictionary(uniqueKeysWithValues: (profiles ?? []).map { ($0.id, $0) })
            
            var enrichedItems: [TradeItem] = []
            
            // 4. Enrich Items with Privacy Logic
            for item in visibleItems {
                var modifiedItem = item
                
                // Attach Profile
                if let profile = profileMap[item.ownerId] {
                    // ✨ PRIVACY CHECK 3: Ghost Mode
                    if profile.isGhostMode { continue }
                    
                    modifiedItem.ownerProfile = profile
                    modifiedItem.ownerUsername = profile.username
                    modifiedItem.ownerIsVerified = profile.isVerified
                    modifiedItem.ownerIsPremium = profile.isPremium
                    modifiedItem.ownerTradeCount = profile.completedTradeCount
                    
                    // ✨ PRIVACY CHECK 4: Location
                    if let userLoc = currentUserLocation,
                       let lat = item.latitude,
                       let lon = item.longitude {
                        
                        // Only calculate distance if user allows it
                        if profile.showExactLocation {
                            let itemLoc = CLLocation(latitude: lat, longitude: lon)
                            modifiedItem.distance = userLoc.distance(from: itemLoc) / 1000.0
                        } else {
                            modifiedItem.distance = nil // Hidden
                        }
                    }
                } else {
                    modifiedItem.ownerUsername = "Swappr User"
                }
                
                enrichedItems.append(modifiedItem)
            }
            
            // 5. Smart Sort (ISO Match > Distance)
            let sortedBatch = enrichedItems.sorted { item1, item2 in
                let isIso1 = userIsoCategories.contains(item1.category)
                let isIso2 = userIsoCategories.contains(item2.category)
                
                if isIso1 && !isIso2 { return true }
                if !isIso1 && isIso2 { return false }
                
                // Handle Optional Distance (Hidden locations go to bottom)
                let dist1 = item1.distance ?? 99999
                let dist2 = item2.distance ?? 99999
                return dist1 < dist2
            }
            
            self.items.append(contentsOf: sortedBatch)
            print("✅ Loaded \(sortedBatch.count) items.")
            
        } catch {
            print("❌ Feed Error: \(error)")
            self.error = error.localizedDescription
        }
        
        self.isFetchingNextPage = false
    }
}
