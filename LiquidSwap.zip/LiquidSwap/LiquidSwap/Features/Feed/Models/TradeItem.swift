import SwiftUI
import CoreLocation

struct TradeItem: Identifiable, Codable, Hashable {
    var id: UUID
    var ownerId: UUID
    var title: String
    var description: String
    var condition: String
    var category: String
    var imageUrl: String?
    var createdAt: Date
    
    // Value & Donation
    var price: Double?
    var isDonation: Bool
    
    // Coordinates (Stored in DB)
    var latitude: Double?
    var longitude: Double?
    
    // ✨ NEW: Engagement Analytics (Database Columns)
    // Converted to non-optional Ints for reliable math/sorting
    var viewCount: Int
    var saveCount: Int
    var offerCount: Int
    var liveViewers: Int
    var isRare: Bool
    
    // MARK: - UI-Only Properties (Hydrated by FeedManager)
    var distance: Double?
    
    var ownerRating: Double?
    var ownerReviewCount: Int?
    var ownerUsername: String?
    var ownerIsVerified: Bool?
    var ownerIsPremium: Bool?
    var ownerTradeCount: Int?
    
    // Full Profile access for filtering
    var ownerProfile: UserProfile?
    
    // Computed: Location Display
    var displayLocation: String {
        if let location = ownerProfile?.location, !location.isEmpty {
            return location
        }
        if let dist = distance {
             return String(format: "< %.1f km away", dist)
        }
        return "Unknown Location"
    }
    
    // ✨ NEW: Heat Index Calculation
    // Logic: Views + (Saves * 10) = Heat Score
    var heatIndex: Int {
        return viewCount + (saveCount * 10)
    }
    
    enum CodingKeys: String, CodingKey {
        case id
        case ownerId = "owner_id"
        case title
        case description
        case condition
        case category
        case imageUrl = "image_url"
        case createdAt = "created_at"
        case price
        case isDonation = "is_donation"
        case latitude
        case longitude
        // ✨ Analytics Keys
        case viewCount = "view_count"
        case saveCount = "save_count"
        case offerCount = "offer_count"
        case liveViewers = "live_viewers"
        case isRare = "is_rare"
    }
    
    // Custom Init
    init(
        id: UUID = UUID(),
        ownerId: UUID,
        title: String,
        description: String,
        condition: String,
        category: String,
        imageUrl: String?,
        createdAt: Date = Date(),
        price: Double?,
        isDonation: Bool,
        latitude: Double?,
        longitude: Double?,
        // ✨ Analytics Defaults (0/False)
        viewCount: Int = 0,
        saveCount: Int = 0,
        offerCount: Int = 0,
        liveViewers: Int = 0,
        isRare: Bool = false,
        // UI Defaults
        distance: Double? = nil,
        ownerRating: Double? = nil,
        ownerReviewCount: Int? = nil,
        ownerUsername: String? = nil,
        ownerIsVerified: Bool? = nil,
        ownerTradeCount: Int? = nil,
        ownerIsPremium: Bool? = nil,
        ownerProfile: UserProfile? = nil
    ) {
        
        self.id = id
        self.ownerId = ownerId
        self.title = title
        self.description = description
        self.condition = condition
        self.category = category
        self.imageUrl = imageUrl
        self.createdAt = createdAt
        self.price = price
        self.isDonation = isDonation
        self.latitude = latitude
        self.longitude = longitude
        
        // Analytics
        self.viewCount = viewCount
        self.saveCount = saveCount
        self.offerCount = offerCount
        self.liveViewers = liveViewers
        self.isRare = isRare
        
        // UI Properties
        self.distance = distance
        self.ownerRating = ownerRating
        self.ownerReviewCount = ownerReviewCount
        self.ownerUsername = ownerUsername
        self.ownerIsVerified = ownerIsVerified
        self.ownerTradeCount = ownerTradeCount
        self.ownerIsPremium = ownerIsPremium
        self.ownerProfile = ownerProfile
    }
    
    // Mock Data (Updated with Analytics)
    static func generateMockItems() -> [TradeItem] {
        return [
            TradeItem(
                ownerId: UUID(),
                title: "Vintage Leica M6",
                description: "Film camera in mint condition.",
                condition: "Like New",
                category: "Electronics",
                imageUrl: nil,
                createdAt: Date().addingTimeInterval(-120), // 2 mins ago (Fresh)
                price: 2500.0,
                isDonation: false,
                latitude: 43.6532,
                longitude: -79.3832,
                // ✨ MOCK ANALYTICS to test the UI
                viewCount: 1240,
                saveCount: 45,
                offerCount: 3,
                liveViewers: 12,
                isRare: true,
                // UI Props
                distance: 2.5,
                ownerRating: 4.8,
                ownerReviewCount: 42,
                ownerUsername: "CameraGuy",
                ownerIsVerified: true,
                ownerTradeCount: 15,
                ownerIsPremium: true,
                ownerProfile: nil
            )
        ]
    }
}
