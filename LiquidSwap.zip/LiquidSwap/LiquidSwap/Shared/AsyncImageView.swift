import SwiftUI

struct AsyncImageView: View {
    let filename: String?
    let contentMode: ContentMode
    
    // ✨ CONTINUITY: Keep the init compatible with your existing code
    // Added contentMode parameter with a default to 'fill' to match your previous hardcoded style
    init(filename: String?, contentMode: ContentMode = .fill) {
        self.filename = filename
        self.contentMode = contentMode
    }
    
    var body: some View {
        if let filename = filename, let url = URL(string: filename) {
            // ✨ IMPROVEMENT: Use native AsyncImage (Replaces DiskManager)
            AsyncImage(url: url) { phase in
                switch phase {
                case .empty:
                    ZStack {
                        Color.gray.opacity(0.1)
                        ProgressView()
                            .tint(.gray)
                    }
                case .success(let image):
                    image
                        .resizable()
                        .aspectRatio(contentMode: contentMode)
                        .transition(.opacity.animation(.easeOut(duration: 0.2))) // ✨ RESTORED: Your smooth fade-in
                case .failure:
                    ZStack {
                        Color.gray.opacity(0.2)
                        Image(systemName: "exclamationmark.triangle") // ✨ RESTORED: Your error icon
                            .foregroundStyle(.gray)
                    }
                @unknown default:
                    EmptyView()
                }
            }
        } else {
            // Fallback for nil URL
            ZStack {
                Color.gray.opacity(0.1)
                Image(systemName: "photo")
                    .foregroundStyle(.gray)
            }
        }
    }
}
