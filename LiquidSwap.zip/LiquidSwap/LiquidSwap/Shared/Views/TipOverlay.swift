//
//  TipOverlay.swift
//  LiquidSwap
//
//  Created by Shwetang Mahudkar on 2026-02-09.
//


import SwiftUI

struct TipOverlay: View {
    let type: TipType
    var onDismiss: () -> Void
    
    var body: some View {
        ZStack {
            // 1. Darken Background (Focus attention)
            Color.black.opacity(0.4)
                .ignoresSafeArea()
                .onTapGesture { onDismiss() }
            
            // 2. The Tip Bubble
            VStack(spacing: 16) {
                // Icon
                Circle()
                    .fill(Color.cyan.opacity(0.2))
                    .frame(width: 60, height: 60)
                    .overlay(
                        Image(systemName: iconName)
                            .font(.title)
                            .foregroundStyle(.cyan)
                    )
                    .overlay(
                        Circle().stroke(Color.cyan.opacity(0.5), lineWidth: 1)
                    )
                
                // Text
                VStack(spacing: 8) {
                    Text(title)
                        .font(.headline)
                        .foregroundStyle(.white)
                    
                    Text(message)
                        .font(.subheadline)
                        .foregroundStyle(.white.opacity(0.8))
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 16)
                }
                
                // Button
                Button(action: onDismiss) {
                    Text("Got it")
                        .font(.subheadline.bold())
                        .foregroundStyle(.black)
                        .padding(.horizontal, 24)
                        .padding(.vertical, 10)
                        .background(Color.cyan)
                        .clipShape(Capsule())
                }
            }
            .padding(32)
            .background(
                // Glassmorphism Card
                RoundedRectangle(cornerRadius: 24)
                    .fill(.ultraThinMaterial)
                    .overlay(
                        RoundedRectangle(cornerRadius: 24)
                            .stroke(Color.white.opacity(0.2), lineWidth: 1)
                    )
            )
            .padding(40)
            .transition(.scale.combined(with: .opacity))
        }
        .zIndex(100) // Always on top
    }
    
    // Content Logic
    var title: String {
        switch type {
        case .swipeLoop: return "How to Trade"
        case .trustScore: return "Build Trust"
        case .createTrade: return "Start Swapping"
        }
    }
    
    var message: String {
        switch type {
        case .swipeLoop: return "Swipe RIGHT to like an item, or LEFT to pass. Matches let you chat instantly!"
        case .trustScore: return "Verify your ID to earn the 'Verified' badge and boost your Trust Score."
        case .createTrade: return "Got cool stuff? Tap the + button to list your first item in seconds."
        }
    }
    
    var iconName: String {
        switch type {
        case .swipeLoop: return "hand.draw.fill"
        case .trustScore: return "checkmark.shield.fill"
        case .createTrade: return "plus.circle.fill"
        }
    }
}