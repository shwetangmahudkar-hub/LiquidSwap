import SwiftUI
import Combine

// 1. Define the Tip Types
enum TipType: String, Identifiable {
    case swipeLoop      // Teaches the Feed mechanic
    case trustScore     // Teaches Profile verification
    case createTrade    // Teaches how to add items
    
    var id: String { rawValue }
}

// 2. The Manager Class
class TipManager: ObservableObject {
    // Singleton Instance
    static let shared = TipManager()
    
    // Published state so Views can react
    @Published var activeTip: TipType? = nil
    
    // ✨ FIX: Explicit private initializer to satisfy the compiler
    private init() {}
    
    // MARK: - Actions
    
    func showTip(_ type: TipType, delay: Double = 0.5) {
        // Check if user has already seen this tip
        guard !hasSeen(type) else { return }
        
        // Slight delay to let screens transition first
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self] in
            withAnimation(.spring(response: 0.5, dampingFraction: 0.7)) {
                self?.activeTip = type
            }
        }
    }
    
    func dismiss() {
        guard let current = activeTip else { return }
        
        // Mark as seen permanently
        markAsSeen(current)
        
        withAnimation(.easeOut(duration: 0.2)) {
            self.activeTip = nil
        }
    }
    
    // MARK: - Persistence (UserDefaults)
    
    private func hasSeen(_ type: TipType) -> Bool {
        return UserDefaults.standard.bool(forKey: "tip_seen_\(type.rawValue)")
    }
    
    private func markAsSeen(_ type: TipType) {
        UserDefaults.standard.set(true, forKey: "tip_seen_\(type.rawValue)")
    }
    
    // Debug Helper: Reset all tips so you can see them again
    func resetTips() {
        let keys = [
            "tip_seen_\(TipType.swipeLoop.rawValue)",
            "tip_seen_\(TipType.trustScore.rawValue)",
            "tip_seen_\(TipType.createTrade.rawValue)"
        ]
        
        keys.forEach { key in
            UserDefaults.standard.removeObject(forKey: key)
        }
        print("🔄 Tips Reset")
    }
}
