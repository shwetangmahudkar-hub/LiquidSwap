import Foundation
import SwiftUI
import Combine
import Supabase
import CoreLocation

// MARK: - User Models

struct UserProfile: Codable, Identifiable, Hashable {
    var id: UUID
    var username: String
    var bio: String
    var location: String
    var avatarUrl: String?
    var isoCategories: [String] = []
    
    // Verification & Access Status
    var isVerified: Bool = false
    var isPremium: Bool = false
    
    // Privacy Settings
    var showExactLocation: Bool = true
    var isGhostMode: Bool = false
    var allowFriendRequests: Bool = true
    
    // ✨ NEW: Push Notification Token
    var pushToken: String?
    
    // Trade Count
    var completedTradeCount: Int = 0
    
    // Streak & XP Data
    var lastActiveDate: Date?
    var currentStreak: Int = 0
    var longestStreak: Int = 0
    var xp: Int = 0
    
    enum CodingKeys: String, CodingKey {
        case id
        case username
        case bio
        case location
        case avatarUrl = "avatar_url"
        case isoCategories = "iso_categories"
        case isVerified = "is_verified"
        case isPremium = "is_premium"
        case showExactLocation = "show_exact_location"
        case isGhostMode = "is_ghost_mode"
        case allowFriendRequests = "allow_friend_requests"
        case pushToken = "push_token" // ✨ NEW: Maps to the Supabase column
        case lastActiveDate = "last_active_date"
        case currentStreak = "current_streak"
        case longestStreak = "longest_streak"
        case xp
    }
    
    // Fallback init for decoding
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(UUID.self, forKey: .id)
        username = try container.decode(String.self, forKey: .username)
        bio = try container.decodeIfPresent(String.self, forKey: .bio) ?? ""
        location = try container.decodeIfPresent(String.self, forKey: .location) ?? "Unknown"
        avatarUrl = try container.decodeIfPresent(String.self, forKey: .avatarUrl)
        isoCategories = try container.decodeIfPresent([String].self, forKey: .isoCategories) ?? []
        isVerified = try container.decodeIfPresent(Bool.self, forKey: .isVerified) ?? false
        isPremium = try container.decodeIfPresent(Bool.self, forKey: .isPremium) ?? false
        showExactLocation = try container.decodeIfPresent(Bool.self, forKey: .showExactLocation) ?? true
        isGhostMode = try container.decodeIfPresent(Bool.self, forKey: .isGhostMode) ?? false
        allowFriendRequests = try container.decodeIfPresent(Bool.self, forKey: .allowFriendRequests) ?? true
        pushToken = try container.decodeIfPresent(String.self, forKey: .pushToken) // ✨ NEW: Decodes the token
        lastActiveDate = try container.decodeIfPresent(Date.self, forKey: .lastActiveDate)
        currentStreak = try container.decodeIfPresent(Int.self, forKey: .currentStreak) ?? 0
        longestStreak = try container.decodeIfPresent(Int.self, forKey: .longestStreak) ?? 0
        xp = try container.decodeIfPresent(Int.self, forKey: .xp) ?? 0
    }
    
    // Explicit Init
    init(id: UUID, username: String, bio: String, location: String, avatarUrl: String?, isoCategories: [String], isVerified: Bool = false, isPremium: Bool = false, showExactLocation: Bool = true, isGhostMode: Bool = false, allowFriendRequests: Bool = true, lastActiveDate: Date? = nil, currentStreak: Int = 0, longestStreak: Int = 0, xp: Int = 0, pushToken: String? = nil) {
        self.id = id
        self.username = username
        self.bio = bio
        self.location = location
        self.avatarUrl = avatarUrl
        self.isoCategories = isoCategories
        self.isVerified = isVerified
        self.isPremium = isPremium
        self.showExactLocation = showExactLocation
        self.isGhostMode = isGhostMode
        self.allowFriendRequests = allowFriendRequests
        self.lastActiveDate = lastActiveDate
        self.currentStreak = currentStreak
        self.longestStreak = longestStreak
        self.xp = xp
        self.pushToken = pushToken // ✨ NEW: Assigns the token
    }
}

// MARK: - Level Definition

struct UserLevel {
    let tier: Int
    let title: String
    let minTrades: Int
    let maxTrades: Int
    let icon: String
    let color: Color
    let perks: [String]
    
    static let all: [UserLevel] = [
        UserLevel(tier: 1, title: "Novice Swapper", minTrades: 0, maxTrades: 2, icon: "leaf", color: .gray, perks: ["Basic access", "List up to 20 items"]),
        UserLevel(tier: 2, title: "Eco Trader", minTrades: 3, maxTrades: 9, icon: "leaf.fill", color: .green, perks: ["Custom profile color", "Eco Trader badge"]),
        UserLevel(tier: 3, title: "Swap Savant", minTrades: 10, maxTrades: 24, icon: "star.fill", color: .cyan, perks: ["Priority in local feed", "Savant badge"]),
        UserLevel(tier: 4, title: "Circular Hero", minTrades: 25, maxTrades: 49, icon: "shield.fill", color: .purple, perks: ["Hero badge", "Extended item limit (30)"]),
        UserLevel(tier: 5, title: "Legendary Trader", minTrades: 50, maxTrades: Int.max, icon: "crown.fill", color: .yellow, perks: ["Legend flair", "Unlimited items", "Priority support"])
    ]
    
    static func forTradeCount(_ count: Int) -> UserLevel {
        return all.first { count >= $0.minTrades && count <= $0.maxTrades } ?? all[0]
    }
}

// MARK: - Trust Tier Definition

enum TrustTier: String, CaseIterable {
    case newcomer = "Newcomer"
    case bronze = "Bronze"
    case silver = "Silver"
    case gold = "Gold"
    case platinum = "Platinum"
    
    var icon: String {
        switch self {
        case .newcomer: return "person.crop.circle"
        case .bronze: return "shield"
        case .silver: return "shield.fill"
        case .gold: return "shield.lefthalf.filled"
        case .platinum: return "checkmark.shield.fill"
        }
    }
    
    var color: Color {
        switch self {
        case .newcomer: return .gray
        case .bronze: return .brown
        case .silver: return .gray
        case .gold: return .yellow
        case .platinum: return .cyan
        }
    }
    
    static func fromScore(_ score: Int) -> TrustTier {
        switch score {
        case 0..<50: return .newcomer
        case 50..<150: return .bronze
        case 150..<300: return .silver
        case 300..<600: return .gold
        default: return .platinum
        }
    }
}

// MARK: - User Manager

@MainActor
class UserManager: ObservableObject {
    static let shared = UserManager()
    
    // User Data
    @Published var currentUser: UserProfile?
    @Published var userItems: [TradeItem] = []
    
    // Rating Stats
    @Published var userRating: Double = 0.0
    @Published var userReviewCount: Int = 0
    @Published var completedTradeCount: Int = 0
    
    // Progression Stats
    @Published var reviewsGivenCount: Int = 0
    @Published var currentStreak: Int = 0
    @Published var longestStreak: Int = 0
    
    @Published var isLoading = false
    @Published var isAuthenticated = false
    
    // Blocked Users List
    @Published var blockedUserIds: [UUID] = []
    
    private let db = DatabaseService.shared
    private let client = SupabaseConfig.client
    
    // MARK: - Access Control
    
    var isPremium: Bool { currentUser?.isPremium ?? false }
    
    var canAddItem: Bool {
        if isPremium { return true }
        let level = currentLevel
        if level.tier >= 5 { return true }
        if level.tier >= 4 { return userItems.count < 30 }
        return userItems.count < 20
    }
    
    // MARK: - Level System
    
    var currentLevel: UserLevel { UserLevel.forTradeCount(completedTradeCount) }
    var currentLevelTitle: String { currentLevel.title }
    
    var levelProgress: Double {
        let level = currentLevel
        if level.tier == 5 { return 1.0 }
        let progressInLevel = completedTradeCount - level.minTrades
        let levelRange = level.maxTrades - level.minTrades + 1
        return Double(progressInLevel) / Double(levelRange)
    }
    
    var tradesToNextLevel: Int {
        let level = currentLevel
        if level.tier == 5 { return 0 }
        return (level.maxTrades + 1) - completedTradeCount
    }
    
    var nextLevel: UserLevel? {
        let current = currentLevel
        return UserLevel.all.first { $0.tier == current.tier + 1 }
    }
    
    // MARK: - Trust Score System
    
    var trustScore: Int {
        var score = 0
        score += completedTradeCount * 5
        score += Int(userRating * 10)
        score += userReviewCount * 2
        score += (currentUser?.isVerified == true) ? 50 : 0
        score += Int(Double(currentStreak) * 1.0)
        score += (currentUser?.xp ?? 0) / 10
        return score
    }
    
    var trustTier: TrustTier { TrustTier.fromScore(trustScore) }
    
    // MARK: - Impact Statistics
    
    var carbonSaved: Double { Double(completedTradeCount) * 2.5 }
    var carbonSavedFormatted: String {
        if carbonSaved >= 1000 { return String(format: "%.1f tons", carbonSaved / 1000) }
        return String(format: "%.1f kg", carbonSaved)
    }
    
    var itemsSavedFromLandfill: Int { completedTradeCount }
    var estimatedMoneySaved: Int { completedTradeCount * 25 }
    var moneySavedFormatted: String {
        let amount = estimatedMoneySaved
        if amount >= 1000 { return String(format: "$%.1fK", Double(amount) / 1000) }
        return "$\(amount)"
    }
    
    // MARK: - Streak Helpers
    
    var streakStatus: String {
        if currentStreak == 0 { return "Start your streak!" }
        else if currentStreak == 1 { return "1 day streak 🔥" }
        else { return "\(currentStreak) day streak 🔥" }
    }
    
    var isOnStreak: Bool { currentStreak > 0 }
    
    // MARK: - Init
    
    private init() {
        setupAuthListener()
    }
    
    // MARK: - Auto-Sync Logic
    
    private func setupAuthListener() {
        Task {
            for await state in client.auth.authStateChanges {
                if let _ = state.session {
                    print("👤 UserManager: Session detected. Loading data...")
                    await loadUserData()
                } else {
                    print("👤 UserManager: No session. Clearing data.")
                    clearData()
                }
            }
        }
    }
    
    func clearData() {
        self.currentUser = nil
        self.userItems = []
        self.userRating = 0.0
        self.userReviewCount = 0
        self.completedTradeCount = 0
        self.reviewsGivenCount = 0
        self.currentStreak = 0
        self.longestStreak = 0
        self.blockedUserIds = []
        self.isAuthenticated = false
        ProgressionManager.shared.clearData()
    }
    
    // MARK: - Data Loading
    
    func loadUserData() async {
        guard let session = try? await client.auth.session else {
            print("❌ UserManager: No active session")
            self.isAuthenticated = false
            return
        }
        let userId = session.user.id
        self.isLoading = true
        self.isAuthenticated = true
        
        do {
            async let items = db.fetchUserItems(userId: userId)
            async let rating = db.fetchUserRating(userId: userId)
            async let reviews = db.fetchReviewCount(userId: userId)
            async let blocked = db.fetchBlockedUsers(userId: userId)
            async let tradeCount = fetchRealCompletedTradeCount(userId: userId)
            async let givenReviews = db.fetchReviewsGivenCount(userId: userId)
            
            let profile = await getOrCreateProfile(userId: userId, email: session.user.email)
            let (fetchedItems, fetchedRating, fetchedReviews, fetchedBlocked, count, given) = try await (items, rating, reviews, blocked, tradeCount, givenReviews)
            
            self.userItems = fetchedItems
            self.userRating = fetchedRating
            self.userReviewCount = fetchedReviews
            self.blockedUserIds = fetchedBlocked
            self.completedTradeCount = count
            self.reviewsGivenCount = given
            self.currentUser = profile
            self.currentStreak = profile?.currentStreak ?? 0
            self.longestStreak = profile?.longestStreak ?? 0
            
            await updateLoginStreak()
            print("✅ User Data Loaded: \(profile?.username ?? "Unknown") | Trades: \(count)")
            
        } catch {
            print("❌ Error loading user data: \(error)")
        }
        
        self.isLoading = false
        await ProgressionManager.shared.onUserLogin()
    }
    
    private func fetchRealCompletedTradeCount(userId: UUID) async throws -> Int {
        let count = try await client
            .from("trades")
            .select("id", head: true, count: .exact)
            .or("sender_id.eq.\(userId),receiver_id.eq.\(userId)")
            .eq("status", value: "completed")
            .execute()
            .count
        return count ?? 0
    }
    
    // MARK: - Streak Management
    
    private func updateLoginStreak() async {
        guard var profile = currentUser else { return }
        
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: Date())
        
        if let lastActive = profile.lastActiveDate {
            let lastActiveDay = calendar.startOfDay(for: lastActive)
            let daysDifference = calendar.dateComponents([.day], from: lastActiveDay, to: today).day ?? 0
            
            if daysDifference == 0 {
                return
            } else if daysDifference == 1 {
                profile.currentStreak += 1
                if profile.currentStreak > profile.longestStreak {
                    profile.longestStreak = profile.currentStreak
                }
            } else {
                profile.currentStreak = 1
            }
        } else {
            profile.currentStreak = 1
            profile.longestStreak = 1
        }
        
        profile.lastActiveDate = today
        self.currentStreak = profile.currentStreak
        self.longestStreak = profile.longestStreak
        self.currentUser = profile
        
        do {
            try await db.updateStreak(
                userId: profile.id,
                currentStreak: profile.currentStreak,
                longestStreak: profile.longestStreak,
                lastActiveDate: today
            )
        } catch {
            print("❌ Failed to update streak: \(error)")
        }
    }
    
    // MARK: - XP Management
    
    func awardXP(amount: Int) {
        guard var profile = currentUser else { return }
        profile.xp += amount
        self.currentUser = profile
        print("⚡️ XP Awarded: +\(amount) | Total: \(profile.xp)")
        Task {
            try? await db.updateUserXP(userId: profile.id, xp: profile.xp)
        }
    }
    
    // MARK: - Profile Creation Helper
    
    private func getOrCreateProfile(userId: UUID, email: String?) async -> UserProfile? {
        do {
            let existingProfile = try await db.fetchProfile(userId: userId)
            return existingProfile
        } catch {
            print("👤 No profile found, creating new profile...")
        }
        
        let emailName = email?.components(separatedBy: "@").first ?? "Trader"
        let newProfile = UserProfile(
            id: userId,
            username: emailName,
            bio: "Ready to trade!",
            location: "Unknown",
            avatarUrl: nil,
            isoCategories: [],
            isVerified: false,
            isPremium: false,
            showExactLocation: true,
            isGhostMode: false,
            allowFriendRequests: true,
            lastActiveDate: Date(),
            currentStreak: 1,
            longestStreak: 1,
            xp: 0
        )
        
        do {
            try await db.upsertProfile(newProfile)
            print("✅ New profile created successfully for: \(newProfile.username)")
            return newProfile
        } catch {
            print("❌ CRITICAL: Failed to create profile: \(error)")
            return newProfile
        }
    }
    
    // MARK: - Inventory Actions
    
    func addItem(
        title: String,
        description: String,
        image: UIImage,
        category: String,
        condition: String,
        price: Double,
        isDonation: Bool,
        customLat: Double? = nil,
        customLon: Double? = nil
    ) async throws {
        guard canAddItem else {
            throw NSError(domain: "App", code: 400, userInfo: [NSLocalizedDescriptionKey: "Item limit reached. Upgrade to Premium for more slots!"])
        }
        
        self.isLoading = true
        defer { self.isLoading = false }
        
        guard let userId = currentUser?.id else { return }
        
        let location = LocationManager.shared.userLocation
        let finalLat = customLat ?? location?.coordinate.latitude
        let finalLon = customLon ?? location?.coordinate.longitude
        
        let imageUrl = try await db.uploadImage(image, bucket: "items")
        
        let newItem = TradeItem(
            id: UUID(),
            ownerId: userId,
            title: title,
            description: description,
            condition: condition,
            category: category,
            imageUrl: imageUrl,
            createdAt: Date(),
            
            // Fix: Re-ordered arguments based on your project's model
            price: price,
            isDonation: isDonation,
            latitude: finalLat,
            longitude: finalLon,
            distance: nil,
            
            // Owner Metadata
            ownerRating: userRating, ownerUsername: currentUser?.username,
            ownerIsVerified: currentUser?.isVerified,
            ownerTradeCount: completedTradeCount, ownerIsPremium: currentUser?.isPremium
        )
        
        try await db.createItem(item: newItem)
        
        // ✨ OPTIMISTIC UPDATE:
        // Update Local State Immediately so QuickOfferSheet sees it
        await MainActor.run {
            withAnimation {
                self.userItems.insert(newItem, at: 0)
                // Award XP locally first for instant feedback
                self.awardXP(amount: 50)
            }
        }
        
        await ProgressionManager.shared.onItemListed()
        // We can skip full loadUserData() here since we manually updated the list
    }
    
    func updateItem(_ item: TradeItem) async throws {
        self.isLoading = true
        try await db.updateItem(item)
        if let index = userItems.firstIndex(where: { $0.id == item.id }) {
            userItems[index] = item
        }
        self.isLoading = false
    }
    
    func deleteItem(item: TradeItem) async throws {
        self.isLoading = true
        defer { self.isLoading = false }
        do {
            try await db.deleteItem(id: item.id)
            // Optimistic Remove
            if let index = userItems.firstIndex(where: { $0.id == item.id }) {
                userItems.remove(at: index)
            }
            print("✅ Item deleted successfully")
        } catch {
            print("❌ Failed to delete item: \(error.localizedDescription)")
            throw error
        }
    }
    
    // MARK: - Profile Actions
    
    func updateProfile(username: String, bio: String, location: String, isoCategories: [String]) async {
        var userId: UUID?
        if let currentId = currentUser?.id {
            userId = currentId
        } else if let session = try? await client.auth.session {
            userId = session.user.id
        }
        
        guard let userId = userId else { return }
        
        var profile = currentUser ?? UserProfile(
            id: userId,
            username: username,
            bio: bio,
            location: location,
            avatarUrl: nil,
            isoCategories: isoCategories,
            isVerified: false,
            isPremium: false,
            xp: 0
        )
        
        profile.username = username
        profile.bio = bio
        profile.location = location
        profile.isoCategories = isoCategories
        
        self.currentUser = profile
        
        do {
            try await db.upsertProfile(profile)
            print("✅ Profile updated successfully")
        } catch {
            print("❌ Failed to update profile: \(error)")
        }
    }
    
    func updateAvatar(image: UIImage) async {
        guard var profile = currentUser else { return }
        
        do {
            if let url = try? await db.uploadImage(image, bucket: "avatars") {
                profile.avatarUrl = url
                self.currentUser = profile
                try await db.upsertProfile(profile)
            }
        } catch {
            print("❌ Failed to update avatar: \(error)")
        }
    }
    
    func updatePrivacySettings(showExactLocation: Bool, isGhostMode: Bool, allowFriendRequests: Bool) async {
        guard var profile = currentUser else { return }
        
        profile.showExactLocation = showExactLocation
        profile.isGhostMode = isGhostMode
        profile.allowFriendRequests = allowFriendRequests
        self.currentUser = profile
        
        do {
            try await db.upsertProfile(profile)
            print("✅ Privacy settings updated")
        } catch {
            print("❌ Failed to update privacy settings: \(error)")
        }
    }
    
    // ✨ NEW: Push Notifications Tracker
    func updatePushToken(_ token: String) async {
        guard var profile = currentUser else { return }
        
        // Avoid an extra network call if it hasn't changed
        if profile.pushToken == token { return }
        
        profile.pushToken = token
        self.currentUser = profile
        
        do {
            try await db.upsertProfile(profile)
            print("✅ Successfully saved APNs token to Supabase")
        } catch {
            print("❌ Failed to save APNs token: \(error)")
        }
    }
    
    func upgradeToPremium() async {
        guard var profile = currentUser else { return }
        profile.isPremium = true
        self.currentUser = profile
        try? await db.upsertProfile(profile)
    }
    
    func debugTogglePremium() {
        guard var profile = currentUser else { return }
        profile.isPremium.toggle()
        self.currentUser = profile
        Task { try? await db.upsertProfile(profile) }
    }
    
    func markAsVerified() async {
        guard var profile = currentUser else { return }
        profile.isVerified = true
        self.currentUser = profile
        Task { try? await db.upsertProfile(profile) }
    }
    
    func completeOnboarding(username: String, bio: String, image: UIImage?) async {
        var userId: UUID?
        if let currentId = currentUser?.id {
            userId = currentId
        } else if let session = try? await client.auth.session {
            userId = session.user.id
        }
        
        guard let userId = userId else { return }
        
        var profile = currentUser ?? UserProfile(
            id: userId,
            username: username,
            bio: bio,
            location: "Unknown",
            avatarUrl: nil,
            isoCategories: [],
            isVerified: false,
            isPremium: false,
            lastActiveDate: Date(),
            currentStreak: 1,
            longestStreak: 1,
            xp: 0
        )
        
        profile.username = username
        profile.bio = bio
        
        if let img = image {
            if let url = try? await db.uploadImage(img, bucket: "avatars") {
                profile.avatarUrl = url
            }
        }
        
        do {
            try await db.upsertProfile(profile)
            self.currentUser = profile
            awardXP(amount: 100)
        } catch {
            print("❌ Failed to save profile: \(error)")
            self.currentUser = profile
        }
    }
    
    // MARK: - Auth & Account Actions
    
    func signOut() async throws {
        try await client.auth.signOut()
        clearData()
    }
    
    func deleteAccount() async throws {
        guard (currentUser?.id) != nil else { return }
        try await client.auth.signOut()
        clearData()
    }
    
    func resetPassword(email: String) async throws {
        try await client.auth.resetPasswordForEmail(email)
    }
    
    func updateEmail(newEmail: String) async throws {
        let attributes = UserAttributes(email: newEmail)
        try await client.auth.update(user: attributes)
    }
    
    // MARK: - Blocking Actions
    
    func blockUser(userId: UUID) async {
        guard let myId = currentUser?.id else { return }
        if !blockedUserIds.contains(userId) { blockedUserIds.append(userId) }
        
        do {
            try await db.blockUser(blockerId: myId, blockedId: userId)
            await FeedManager.shared.fetchFeed()
        } catch {
            if let index = blockedUserIds.firstIndex(of: userId) { blockedUserIds.remove(at: index) }
        }
    }
    
    func unblockUser(userId: UUID) async {
        guard let myId = currentUser?.id else { return }
        if let index = blockedUserIds.firstIndex(of: userId) { blockedUserIds.remove(at: index) }
        
        do {
            try await db.unblockUser(blockerId: myId, blockedId: userId)
        } catch {
            if !blockedUserIds.contains(userId) { blockedUserIds.append(userId) }
        }
    }
}
