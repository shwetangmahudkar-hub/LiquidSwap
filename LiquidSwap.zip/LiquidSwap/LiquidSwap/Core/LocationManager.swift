import Foundation
import CoreLocation
import Combine

class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    static let shared = LocationManager()
    
    private let manager = CLLocationManager()
    private let geocoder = CLGeocoder() // ✨ NEW: For turning coords into City names
    
    @Published var userLocation: CLLocation?
    @Published var permissionStatus: CLAuthorizationStatus
    @Published var locationName: String? // ✨ NEW: Stores "City, Country"
    @Published var isLoadingLocationName = false
    
    override init() {
        self.permissionStatus = .notDetermined
        self.userLocation = nil
        
        super.init()
        
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        // We don't start updating immediately to save battery
        // We wait for a specific request or permission change
    }
    
    func requestPermission() {
        manager.requestWhenInUseAuthorization()
    }
    
    func refreshLocation() {
        manager.startUpdatingLocation()
    }
    
    // MARK: - ✨ NEW: Get Friendly City Name
    
    /// Fetches current location and reverse geocodes it to "City, Country"
    @MainActor
    func getCurrentCity() async -> String? {
        // 1. Check/Request Permissions
        if permissionStatus == .notDetermined {
            manager.requestWhenInUseAuthorization()
        }
        
        // 2. Ensure we have a location
        manager.startUpdatingLocation()
        
        // Wait briefly for location to warm up if nil
        if userLocation == nil {
            try? await Task.sleep(nanoseconds: 2 * 1_000_000_000) // 2 sec timeout
        }
        
        guard let location = userLocation else {
            return nil
        }
        
        // 3. Reverse Geocode
        isLoadingLocationName = true
        defer { isLoadingLocationName = false }
        
        do {
            let placemarks = try await geocoder.reverseGeocodeLocation(location)
            guard let place = placemarks.first else { return nil }
            
            // Format: "City, State" or "City, Country"
            let city = place.locality ?? place.subAdministrativeArea ?? ""
            let country = place.isoCountryCode ?? ""
            
            // Stop updating to save battery once we have the name
            manager.stopUpdatingLocation()
            
            if !city.isEmpty && !country.isEmpty {
                return "\(city), \(country)"
            } else if !city.isEmpty {
                return city
            } else {
                return "Unknown Location"
            }
        } catch {
            print("❌ Geocoding error: \(error)")
            return nil
        }
    }
    
    // MARK: - Delegate Methods
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        self.permissionStatus = status
        if status == .authorizedWhenInUse || status == .authorizedAlways {
            manager.startUpdatingLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else { return }
        self.userLocation = location
    }
    
    // MARK: - Helper Methods
    
    /// Calculate distance from user to a target coordinate (in km)
    func distanceFromUser(latitude: Double, longitude: Double) -> Double {
        guard let userLoc = userLocation else { return 0.0 }
        let targetLoc = CLLocation(latitude: latitude, longitude: longitude)
        return userLoc.distance(from: targetLoc) / 1000.0 // Convert meters to km
    }
}
