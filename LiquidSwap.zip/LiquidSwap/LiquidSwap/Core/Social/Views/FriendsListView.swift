import SwiftUI

struct FriendsListView: View {
    @Environment(\.dismiss) var dismiss
    @Environment(\.colorScheme) private var colorScheme
    @ObservedObject var friendManager = FriendManager.shared
    
    // UI State
    @State private var selectedSegment = 0 // 0: Friends, 1: Requests
    @State private var selectedProfileSheet: FriendProfileWrapper?
    
    var body: some View {
        NavigationStack {
            ZStack {
                // 1. Global Background
                LiquidBackground()
                    .ignoresSafeArea()
                
                VStack(spacing: 0) {
                    // 2. Standardized Header (UI Only)
                    HStack {
                        Text("My Circle")
                            .font(.system(size: 24, weight: .heavy, design: .rounded))
                            .foregroundStyle(.white)
                        
                        Spacer()
                    }
                    .padding(.horizontal, 24)
                    .padding(.top, 24)
                    .padding(.bottom, 16)
                    
                    // 3. Segmented Control
                    CustomSegmentedControl(selectedIndex: $selectedSegment, options: ["Friends", "Requests"])
                        .padding(.horizontal, 24)
                        .padding(.bottom, 20)
                    
                    // 4. Content (Preserving exact logic)
                    if selectedSegment == 0 {
                        friendsList
                    } else {
                        requestsList
                    }
                }
            }
            .onAppear {
                Task { await friendManager.fetchFriendData() }
            }
            .navigationBarHidden(true)
            // Sheet to view a friend's profile
            .sheet(item: $selectedProfileSheet) { wrapper in
                NavigationStack {
                    PublicProfileView(userId: wrapper.id)
                }
                .presentationDetents([.large])
                .presentationDragIndicator(.visible)
            }
        }
    }
    
    // MARK: - Friends List (Preserved Logic)
    
    private var friendsList: some View {
        Group {
            if friendManager.isLoading {
                Spacer()
                ProgressView().tint(.white)
                Spacer()
            } else if friendManager.friends.isEmpty {
                VStack(spacing: 16) {
                    Spacer()
                    Image(systemName: "person.2.slash.fill")
                        .font(.system(size: 60))
                        .foregroundStyle(.white.opacity(0.3))
                    Text("Your circle is empty")
                        .appFont(DS.Font.cardTitle, weight: .bold)
                        .foregroundStyle(.white.opacity(0.7))
                    Text("Add friends from the feed or after a trade.")
                        .appFont(DS.Font.caption)
                        .foregroundStyle(.white.opacity(0.5))
                        .multilineTextAlignment(.center)
                    Spacer()
                }
            } else {
                ScrollView {
                    LazyVStack(spacing: 12) {
                        ForEach(friendManager.friends, id: \.id) { friend in
                            FriendRow(user: friend)
                                .onTapGesture {
                                    selectedProfileSheet = FriendProfileWrapper(id: friend.id)
                                }
                        }
                    }
                    .padding(.horizontal, 24)
                    .padding(.bottom, 20)
                }
            }
        }
    }
    
    // MARK: - Requests List (Preserved Logic)
    
    private var requestsList: some View {
        Group {
            if friendManager.incomingRequests.isEmpty && friendManager.outgoingRequests.isEmpty {
                VStack(spacing: 16) {
                    Spacer()
                    Image(systemName: "tray.fill")
                        .font(.system(size: 60))
                        .foregroundStyle(.white.opacity(0.3))
                    Text("No pending requests")
                        .appFont(DS.Font.cardTitle, weight: .bold)
                        .foregroundStyle(.white.opacity(0.7))
                    Spacer()
                }
            } else {
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        // Incoming
                        if !friendManager.incomingRequests.isEmpty {
                            VStack(alignment: .leading, spacing: 10) {
                                Text("NEEDS RESPONSE")
                                    .font(.caption.bold())
                                    .foregroundStyle(.white.opacity(0.5))
                                    .padding(.horizontal, 4)
                                
                                ForEach(friendManager.incomingRequests) { request in
                                    IncomingRequestRow(request: request)
                                }
                            }
                        }
                        
                        // Outgoing
                        if !friendManager.outgoingRequests.isEmpty {
                            VStack(alignment: .leading, spacing: 10) {
                                Text("WAITING FOR RESPONSE")
                                    .font(.caption.bold())
                                    .foregroundStyle(.white.opacity(0.5))
                                    .padding(.horizontal, 4)
                                
                                ForEach(friendManager.outgoingRequests) { request in
                                    OutgoingRequestRow(request: request)
                                }
                            }
                        }
                    }
                    .padding(.horizontal, 24)
                }
            }
        }
    }
}

// MARK: - Subviews (Preserved Logic)

struct FriendRow: View {
    let user: UserProfile
    
    var body: some View {
        HStack(spacing: 12) {
            AsyncImageView(filename: user.avatarUrl)
                .scaledToFill()
                .frame(width: 50, height: 50)
                .clipShape(Circle())
            
            VStack(alignment: .leading, spacing: 4) {
                Text(user.username)
                    .appFont(16, weight: .bold)
                    .foregroundStyle(.white)
                Text(user.location)
                    .appFont(12)
                    .foregroundStyle(.white.opacity(0.6))
            }
            
            Spacer()
            
            Image(systemName: "chevron.right")
                .foregroundStyle(.white.opacity(0.3))
        }
        .padding(12)
        .background(.ultraThinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.1), lineWidth: 1))
    }
}

struct IncomingRequestRow: View {
    let request: FriendRequest
    @State private var isProcessing = false
    
    var body: some View {
        HStack(spacing: 12) {
            if let user = request.userProfile {
                AsyncImageView(filename: user.avatarUrl)
                    .scaledToFill()
                    .frame(width: 50, height: 50)
                    .clipShape(Circle())
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(user.username)
                        .appFont(16, weight: .bold)
                        .foregroundStyle(.white)
                    Text("Wants to connect")
                        .appFont(12)
                        .foregroundStyle(.cyan)
                }
            } else {
                ProgressView().tint(.white)
            }
            
            Spacer()
            
            if isProcessing {
                ProgressView().tint(.white)
            } else {
                HStack(spacing: 10) {
                    Button(action: { handleAction(accept: false) }) {
                        Image(systemName: "xmark")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundStyle(.white.opacity(0.6))
                            .padding(10)
                            .background(Color.white.opacity(0.1))
                            .clipShape(Circle())
                    }
                    
                    Button(action: { handleAction(accept: true) }) {
                        Image(systemName: "checkmark")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundStyle(.white)
                            .padding(10)
                            .background(Color.cyan)
                            .clipShape(Circle())
                    }
                }
            }
        }
        .padding(12)
        .background(.ultraThinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.cyan.opacity(0.3), lineWidth: 1))
    }
    
    func handleAction(accept: Bool) {
        isProcessing = true
        Task {
            if accept {
                await FriendManager.shared.acceptRequest(request)
            } else {
                await FriendManager.shared.removeFriendship(friendId: request.otherUserId)
            }
            isProcessing = false
        }
    }
}

struct OutgoingRequestRow: View {
    let request: FriendRequest
    
    var body: some View {
        HStack(spacing: 12) {
            if let user = request.userProfile {
                AsyncImageView(filename: user.avatarUrl)
                    .scaledToFill()
                    .frame(width: 40, height: 40)
                    .clipShape(Circle())
                    .opacity(0.6)
                
                Text(user.username)
                    .appFont(14, weight: .medium)
                    .foregroundStyle(.white.opacity(0.6))
            }
            
            Spacer()
            
            Button(action: {
                Task { await FriendManager.shared.removeFriendship(friendId: request.otherUserId) }
            }) {
                Text("Cancel")
                    .font(.caption.bold())
                    .foregroundStyle(.white.opacity(0.4))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(Color.white.opacity(0.05))
                    .clipShape(Capsule())
            }
        }
        .padding(12)
        .background(.ultraThinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }
}

struct CustomSegmentedControl: View {
    @Binding var selectedIndex: Int
    let options: [String]
    @Namespace private var namespace
    
    var body: some View {
        HStack(spacing: 0) {
            ForEach(options.indices, id: \.self) { index in
                Button(action: {
                    withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                        selectedIndex = index
                    }
                }) {
                    VStack(spacing: 6) {
                        Text(options[index])
                            .appFont(14, weight: selectedIndex == index ? .bold : .medium)
                            .foregroundStyle(selectedIndex == index ? .white : .white.opacity(0.5))
                        
                        if selectedIndex == index {
                            Capsule()
                                .fill(Color.cyan)
                                .frame(height: 3)
                                .matchedGeometryEffect(id: "segmentUnderline", in: namespace)
                        } else {
                            Capsule().fill(Color.clear).frame(height: 3)
                        }
                    }
                    .frame(maxWidth: .infinity)
                }
            }
        }
    }
}

// ✨ FIX: Helper structure restored to scope
struct FriendProfileWrapper: Identifiable {
    let id: UUID
}
