import Foundation
import Supabase
import Combine

@MainActor
class FriendManager: ObservableObject {
    static let shared = FriendManager()
    private let client = SupabaseConfig.client
    
    // State
    @Published var friends: [UserProfile] = []
    @Published var incomingRequests: [FriendRequest] = []
    @Published var outgoingRequests: [FriendRequest] = []
    @Published var isLoading = false
    
    private init() {}
    
    // MARK: - Actions
    
    /// Send a friend request to a user
    func sendFriendRequest(to userId: UUID) async -> Bool {
        guard let myId = client.auth.currentUser?.id else { return false }
        
        // Don't add yourself
        if userId == myId { return false }
        
        // Check if already friends or requested
        if isFriend(userId) || hasPendingRequest(for: userId) { return false }
        
        // ✨ PRIVACY CHECK: Check if the user accepts friend requests
        do {
            let targetProfile = try await DatabaseService.shared.fetchProfile(userId: userId)
            if !targetProfile.allowFriendRequests {
                print("🚫 Friend Request Blocked: User does not accept requests.")
                return false
            }
        } catch {
            print("⚠️ Failed to verify user privacy settings: \(error)")
            // Safe default: If we can't check, we might choose to fail or proceed.
            // Failing is safer for privacy.
            return false
        }
        
        struct RequestData: Encodable {
            let requester_id: UUID
            let receiver_id: UUID
            let status: String
        }
        
        do {
            try await client.from("friendships").insert(
                RequestData(requester_id: myId, receiver_id: userId, status: "pending")
            ).execute()
            
            // Optimistic Update
            await fetchFriendData()
            return true
        } catch {
            print("❌ Error sending friend request: \(error)")
            return false
        }
    }
    
    /// Accept a friend request
    func acceptRequest(_ request: FriendRequest) async {
        do {
            struct StatusUpdate: Encodable { let status: String }
            
            try await client.from("friendships")
                .update(StatusUpdate(status: "accepted"))
                .eq("id", value: request.id)
                .execute()
            
            // Refresh
            await fetchFriendData()
        } catch {
            print("❌ Error accepting request: \(error)")
        }
    }
    
    /// Remove a friend or cancel a request
    func removeFriendship(friendId: UUID) async {
        guard let myId = client.auth.currentUser?.id else { return }
        
        do {
            // Delete where I am sender OR receiver AND the other person is involved
            try await client.from("friendships")
                .delete()
                .or("and(requester_id.eq.\(myId),receiver_id.eq.\(friendId)),and(requester_id.eq.\(friendId),receiver_id.eq.\(myId))")
                .execute()
            
            await fetchFriendData()
        } catch {
            print("❌ Error removing friend: \(error)")
        }
    }
    
    // MARK: - Data Fetching
    
    func fetchFriendData() async {
        guard let myId = client.auth.currentUser?.id else { return }
        isLoading = true
        
        do {
            // 1. Fetch all rows where I am involved
            let rows: [FriendshipRow] = try await client.from("friendships")
                .select("*")
                .or("requester_id.eq.\(myId),receiver_id.eq.\(myId)")
                .execute()
                .value
            
            // 2. Process Relationships
            var confirmedFriendIds: [UUID] = []
            var incoming: [FriendRequest] = []
            var outgoing: [FriendRequest] = []
            
            // Collect IDs to fetch profiles for
            var allProfileIds: Set<UUID> = []
            
            for row in rows {
                let isMeRequester = (row.requester_id == myId)
                let otherId = isMeRequester ? row.receiver_id : row.requester_id
                allProfileIds.insert(otherId)
                
                if row.status == "accepted" {
                    confirmedFriendIds.append(otherId)
                } else if row.status == "pending" {
                    if isMeRequester {
                        // I sent it -> Outgoing
                        outgoing.append(FriendRequest(id: row.id, otherUserId: otherId, type: .outgoing, createdAt: row.created_at))
                    } else {
                        // They sent it -> Incoming
                        incoming.append(FriendRequest(id: row.id, otherUserId: otherId, type: .incoming, createdAt: row.created_at))
                    }
                }
            }
            
            // 3. Batch Fetch Profiles
            if !allProfileIds.isEmpty {
                let profiles = try await DatabaseService.shared.fetchProfiles(userIds: Array(allProfileIds))
                let profileMap = Dictionary(uniqueKeysWithValues: profiles.map { ($0.id, $0) })
                
                // Hydrate State
                self.friends = confirmedFriendIds.compactMap { profileMap[$0] }
                
                // Hydrate Requests
                self.incomingRequests = incoming.map { req in
                    var r = req
                    r.userProfile = profileMap[req.otherUserId]
                    return r
                }
                
                self.outgoingRequests = outgoing.map { req in
                    var r = req
                    r.userProfile = profileMap[req.otherUserId]
                    return r
                }
            } else {
                self.friends = []
                self.incomingRequests = []
                self.outgoingRequests = []
            }
            
        } catch {
            print("❌ Error fetching friends: \(error)")
        }
        
        isLoading = false
    }
    
    // MARK: - Helpers
    
    func isFriend(_ userId: UUID) -> Bool {
        return friends.contains(where: { $0.id == userId })
    }
    
    func hasPendingRequest(for userId: UUID) -> Bool {
        return incomingRequests.contains(where: { $0.otherUserId == userId }) ||
               outgoingRequests.contains(where: { $0.otherUserId == userId })
    }
}

// MARK: - Models

struct FriendshipRow: Decodable {
    let id: UUID
    let requester_id: UUID
    let receiver_id: UUID
    let status: String
    let created_at: Date
}

struct FriendRequest: Identifiable {
    let id: UUID
    let otherUserId: UUID
    let type: RequestType
    let createdAt: Date
    var userProfile: UserProfile?
    
    enum RequestType {
        case incoming // They want to add me
        case outgoing // I added them
    }
}
