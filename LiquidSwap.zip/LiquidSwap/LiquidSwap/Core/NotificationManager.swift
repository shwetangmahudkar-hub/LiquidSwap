import SwiftUI
import UserNotifications
import Combine

class NotificationManager: NSObject, ObservableObject, UNUserNotificationCenterDelegate {
    static let shared = NotificationManager()
    
    @Published var permissionStatus: UNAuthorizationStatus = .notDetermined
    
    // Store the device token locally
    @Published var apnsToken: String?
    
    // ✨ NEW: Tracks which trade to navigate to from a notification tap
    @Published var navigateToTradeId: UUID?
    
    override private init() { // Private init ensures it's a true Singleton
        super.init()
        UNUserNotificationCenter.current().delegate = self
    }
    
    // 1. Request Permission
    func requestPermission() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { granted, error in
            DispatchQueue.main.async {
                self.permissionStatus = granted ? .authorized : .denied
                print("🔔 Notification Permission: \(granted ? "Granted" : "Denied")")
                
                // Explicitly ask Apple for the Remote Push Token if granted
                if granted {
                    UIApplication.shared.registerForRemoteNotifications()
                }
            }
        }
    }
    
    // 2. Trigger a "Local" Push
    func sendLocalNotification(title: String, body: String, tradeId: UUID? = nil) {
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        content.sound = .default
        
        // ✨ NEW: Embed the trade_id so even local notifications can be tapped!
        if let tId = tradeId {
            content.userInfo = ["trade_id": tId.uuidString]
        }
        
        // Show immediately (0.1s delay)
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 0.1, repeats: false)
        let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)
        
        UNUserNotificationCenter.current().add(request)
    }
    
    // 3. Handle Foreground Notifications
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        // Return empty array [] to suppress banners while app is open.
        // The app's UI (ChatRoomView) already updates automatically via Realtime.
        completionHandler([])
    }
    
    // 4. Catch the APNs Token from AppDelegate
    func handlePushToken(_ token: String) {
        DispatchQueue.main.async {
            self.apnsToken = token
            print("📲 NotificationManager saved APNs Token.")
            
            // Hand it off to the UserManager to sync with Supabase
            Task {
                await UserManager.shared.updatePushToken(token)
            }
        }
    }
    
    // 5. ✨ NEW: Catch User Taps on the Notification (Background/Lock Screen)
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        let userInfo = response.notification.request.content.userInfo
        
        // Check if our backend (or local push) attached a trade_id to the payload
        if let tradeIdString = userInfo["trade_id"] as? String,
           let tradeId = UUID(uuidString: tradeIdString) {
            
            print("🔗 Deep Link Triggered for Trade: \(tradeIdString)")
            
            DispatchQueue.main.async {
                self.navigateToTradeId = tradeId
            }
        }
        
        completionHandler()
    }
}
