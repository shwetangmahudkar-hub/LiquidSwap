import SwiftUI

struct ContentView: View {
    // ✅ Restore your original AuthViewModel
    @StateObject var authVM = AuthViewModel()
    @State private var showSplash = true
    
    // ✨ Access the new ModalManager
    @EnvironmentObject var modalManager: ModalManager
    
    // ✨ NEW: TipManager Dependency (For Coach Marks)
    @ObservedObject var tipManager = TipManager.shared
    
    // ✨ Developer Control: Read the settings
    @AppStorage("dev_alwaysShowOnboarding") private var alwaysShowOnboarding = false
    @AppStorage("hasSeenOnboarding") private var hasSeenOnboarding = true
    
    var body: some View {
        ZStack {
            // 1. MAIN CONTENT (Base Layer)
            if !showSplash {
                Group {
                    if authVM.isAuthenticated {
                        if !hasSeenOnboarding || authVM.isOnboarding {
                            OnboardingView(authVM: authVM)
                                .transition(.move(edge: .bottom).combined(with: .opacity))
                                .zIndex(2)
                        } else {
                            MainTabView()
                                .environmentObject(authVM)
                                .transition(.opacity)
                                // ✨ THE DEEP GLASS EFFECT ✨
                                // When a modal is up, we push this view "back"
                                .scaleEffect(modalManager.isPresenting ? 0.92 : 1.0)
                                .blur(radius: modalManager.isPresenting ? 3 : 0)
                                .opacity(modalManager.isPresenting ? 0.8 : 1.0)
                                .animation(.spring(response: 0.5, dampingFraction: 0.8), value: modalManager.isPresenting)
                        }
                    } else {
                        AuthView()
                            .transition(.opacity)
                            .zIndex(1)
                    }
                }
            }
            
            // 2. SPLASH SCREEN (Top Layer)
            if showSplash {
                SplashScreen(showSplash: $showSplash)
                    .transition(.opacity)
                    .zIndex(3)
                    .onAppear {
                        // ✨ DEV TOGGLE: If "Always Show" is on, force the flag to false on launch
                        if alwaysShowOnboarding {
                            hasSeenOnboarding = false
                            authVM.isOnboarding = true // Sync VM if applicable
                        }
                    }
            }
            
            // 3. GLOBAL MODAL OVERLAY (High Layer)
            if modalManager.isPresenting {
                ZStack {
                    // Dimming Background
                    Color.black.opacity(0.3)
                        .ignoresSafeArea()
                        .onTapGesture {
                            modalManager.dismiss()
                        }
                        .transition(.opacity)
                    
                    // The Modal Sheet
                    VStack {
                        Spacer()
                        
                        // ✨ FIX: Safely unwrap to avoid "empty switch" errors
                        if let active = modalManager.activeModal {
                            switch active {
                            case .addItem:
                                AddItemView(isPresented: Binding(
                                    get: { modalManager.isPresenting },
                                    set: { if !$0 { modalManager.dismiss() } }
                                ))
                            case .settings:
                                SettingsView()
                            case .editProfile:
                                EditProfileView()
                            case .activityHub:
                                ActivityHubView()
                            }
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: UIScreen.main.bounds.height * 0.92) // 92% Height
                    .background(
                        RoundedRectangle(cornerRadius: 30)
                            .fill(.thinMaterial) // Second layer of glass
                            .shadow(color: .black.opacity(0.5), radius: 30, x: 0, y: 0)
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 30)
                            .stroke(Color.white.opacity(0.15), lineWidth: 1)
                    )
                    .padding(.bottom, -30) // Hide bottom corners
                    .transition(.move(edge: .bottom))
                    // Drag Gesture to dismiss
                    .gesture(
                        DragGesture()
                            .onEnded { value in
                                if value.translation.height > 100 {
                                    modalManager.dismiss()
                                }
                            }
                    )
                }
                .zIndex(5)
            }
            
            // 4. ✨ TIPS OVERLAY (Supreme Layer)
            // This sits on top of everything, including modals
            if let activeTip = tipManager.activeTip {
                TipOverlay(type: activeTip) {
                    tipManager.dismiss()
                }
                .zIndex(100)
            }
        }
    }
}
