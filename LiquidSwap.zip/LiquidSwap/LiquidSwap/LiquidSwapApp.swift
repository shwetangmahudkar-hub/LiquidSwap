import SwiftUI

// ✨ NEW: App Delegate to handle Apple's Push Notification lifecycle
class AppDelegate: NSObject, UIApplicationDelegate {
    
    // Successfully registered with Apple
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        // Convert the raw Data token into a readable Hex String
        let tokenParts = deviceToken.map { data in String(format: "%02.2hhx", data) }
        let token = tokenParts.joined()
        
        print("📱 APNs Device Token Received: \(token)")
        
        // Hand the token off to our NotificationManager to save/upload
        NotificationManager.shared.handlePushToken(token)
    }
    
    // Failed to register with Apple
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        print("❌ Failed to register for remote notifications: \(error.localizedDescription)")
    }
}

@main
struct LiquidSwapApp: App {
    
    // ✨ NEW: Inject the App Delegate into the SwiftUI lifecycle
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    
    // ✅ Read the dark mode preference from UserDefaults
    @AppStorage("isDarkMode") private var isDarkMode = true
    
    // Initialize the Global Modal Manager (Source of Truth)
    @StateObject private var modalManager = ModalManager()
    
    init() {
        print("⚡️ Supabase Client Initialized: \(SupabaseConfig.supabaseURL)")
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(modalManager)
                .onAppear {
                    NotificationManager.shared.requestPermission()
                }
                .preferredColorScheme(isDarkMode ? .dark : .light)
        }
    }
}
