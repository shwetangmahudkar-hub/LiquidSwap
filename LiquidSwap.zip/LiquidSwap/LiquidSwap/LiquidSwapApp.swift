import SwiftUI

@main
struct LiquidSwapApp: App {
    
    // ✅ Read the dark mode preference from UserDefaults
    @AppStorage("isDarkMode") private var isDarkMode = true
    
    // ✨ NEW: Initialize the Global Modal Manager (Source of Truth)
    @StateObject private var modalManager = ModalManager()
    
    init() {
        print("⚡️ Supabase Client Initialized: \(SupabaseConfig.supabaseURL)")
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                // ✨ NEW: Inject it so ContentView can access it
                .environmentObject(modalManager)
                .onAppear {
                    // ✅ FIX: Use the shared instance directly
                    NotificationManager.shared.requestPermission()
                }
                // ✅ Apply the color scheme based on user preference
                .preferredColorScheme(isDarkMode ? .dark : .light)
        }
    }
}
